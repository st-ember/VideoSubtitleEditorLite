import { containerController } from "ContainerController";
import Page from "Page";

export default abstract class ListPage extends Page {

    pageConditions?: HTMLDivElement;
    pageConditionForm?: HTMLFormElement;
    submitButton?: HTMLButtonElement;
    pageInput?: HTMLInputElement;
    pageSize?: HTMLInputElement;
    totalPageInput?: HTMLInputElement;
    orderColumnInput?: HTMLInputElement;
    descendingInput?: HTMLInputElement;
    pageSelector?: HTMLSelectElement;
    pageSizeInput?: HTMLInputElement;
    tableContainer?: HTMLDivElement;
    table?: HTMLTableElement;
    paginationContainer?: HTMLDivElement;

    disablePagination: boolean = false;

    async startAsync(): Promise<void> {
        this.pageContainer = <HTMLDivElement | undefined>document.querySelector(".page-container");
        this.titleContainer = <HTMLDivElement | undefined>document.querySelector(".title-container");
        this.sideMenuContainer = <HTMLDivElement | undefined>document.querySelector(".side-menu-container");
        this.pageConditions = <HTMLDivElement | undefined>document.querySelector(".page-conditions");

        this.pageConditionForm = <HTMLFormElement | undefined>document.getElementById("page-condition");
        if (this.pageConditionForm) {
            this.submitButton = <HTMLButtonElement | undefined>this.pageConditionForm.querySelector("button[type='submit']");
            this.pageInput = <HTMLInputElement | undefined>document.getElementById("page-input");
            this.pageSize = <HTMLInputElement | undefined>document.getElementById("page-size-input");
            this.totalPageInput = <HTMLInputElement | undefined>document.getElementById("total-page-input");
            this.orderColumnInput = <HTMLInputElement | undefined>document.getElementById("order-column-input");
            this.descendingInput = <HTMLInputElement | undefined>document.getElementById("descending-input");
        }

        this.tableContainer = <HTMLDivElement | undefined>document.querySelector(".table-container");
        this.table = <HTMLTableElement | undefined>this.tableContainer?.querySelector("table");
        this.paginationContainer = <HTMLDivElement | undefined>document.querySelector(".pagination-container");

        await this.loadAsync();

        this._initOrderableHeader();
        this.buildPageNav();

        this.updateTableContainerSize();
        containerController.onStageWidthChangeFuncs.push(() => this.updateTableContainerSize());

        this.buildSideMenu();
        this.processTitle();
    }

    reload(): void {
        this.submit();
    }

    submit(): void {
        if (this.pageConditionForm) {
            this.pageConditionForm.submit();
        } else {
            window.location.reload();
        }
    }

    toPage(page: number | string): void {
        if (this.pageInput) {
            this.pageInput.value = String(page);
            this.submit();
        }
    }

    protected updateTableContainerSize(): void {
        if (!this.tableContainer) { return; }

        let height = 0;

        if (this.pageConditions) {
            height += this.pageConditions.clientHeight;
        }

        if (this.paginationContainer) {
            height += this.paginationContainer.clientHeight + 40;
        }

        this.tableContainer.style.height = `calc(100% - ${height}px)`;
    }

    private _initOrderableHeader(): void {
        if (!this.tableContainer || !this.orderColumnInput || !this.descendingInput) { return; }

        const ths = this.tableContainer.querySelectorAll("th.sortable-th");
        for (let i = 0; i < ths.length; i++) {
            const th = ths.item(i);
            const targetName = th.getAttribute("data-order-target");
            if (targetName && this.orderColumnInput && this.descendingInput) {
                th.addEventListener("click", () => {
                    if (this.orderColumnInput!.value !== targetName) {
                        this.orderColumnInput!.value = targetName;
                    } else {
                        const descending = this.descendingInput!.value === "True";
                        this.descendingInput!.value = descending ? "False" : "True";
                    }
                    
                    this.reload();
                });
            }
        }
    }

    private _onPageSelectChange(): void {
        const option = <HTMLOptionElement>this.pageSelector?.querySelector("option:checked");
        this.toPage(option.value);
    }

    private _onPageSizeChange(): void {
        if (!this.pageSize) { return; }
        const value = this.pageSizeInput ? Number(this.pageSizeInput.value) : 0;
        const size = !isNaN(value) && value > 0 ? value : 10;
        this.pageSize.value = String(size);
        this.reload();
    }

    protected buildPageNav(): void {
        if (!this.tableContainer || !this.pageInput || !this.totalPageInput || this.disablePagination) {
            return;
        }

        const originalNav = this.tableContainer.querySelector("nav");
        if (originalNav) {
            originalNav.remove();
        }

        const page = Number(this.pageInput.value);
        const totalPage = Number(this.totalPageInput.value);

        const a = page - 4;
        const b = page + 5;
        const aa = a < 1 ? 1 - a : 0;
        const bb = b > totalPage ? totalPage - b : 0;
        const d = page + aa + bb;
        const start = d - 4;

        const prevClass = "page-button" + (page > 1 ? "" : " disabled");
        const nextClass = "page-button" + (totalPage > page ? "" : " disabled");

        const nav = document.createElement("nav");
        nav.setAttribute("aria-label", "navigation");
        nav.id = "list-nav-bar";

        const ul = document.createElement("ul");
        ul.className = "pagination";
        nav.appendChild(ul);

        if (totalPage > 10) {
            const firstLi = document.createElement("li");
            firstLi.className = prevClass;
            ul.appendChild(firstLi);

            const firstPageAnchor = document.createElement("a");
            firstPageAnchor.className = "page-link";
            firstPageAnchor.href = "javascript:void(0)";
            firstPageAnchor.innerHTML = "<span aria-hidden=\"true\">&laquo;</span><span class=\"button-text\">第一頁</span>";
            firstPageAnchor.addEventListener("click", () => this.toPage(1));
            firstLi.appendChild(firstPageAnchor);

            const prevLi = document.createElement("li");
            prevLi.className = prevClass;
            ul.appendChild(prevLi);

            const prevPageAnchor = document.createElement("a");
            prevPageAnchor.className = "page-link";
            prevPageAnchor.setAttribute("aria-label", "Previous");
            prevPageAnchor.href = "javascript:void(0)";
            prevPageAnchor.innerHTML = "<span aria-hidden=\"true\">&lsaquo;</span><span class=\"button-text\">上一頁</span>";
            prevPageAnchor.addEventListener("click", () => this.toPage(page - 1));
            prevLi.appendChild(prevPageAnchor);

            for (let i = start - 1; i < start + 9; i++) {
                const p = i + 1;
                const elemClass = "page-item" + (p !== page ? "" : " active");

                const li = document.createElement("li");
                li.className = elemClass;
                ul.appendChild(li);

                const anchor = document.createElement("a");
                anchor.className = "page-link";
                anchor.href = "javascript:void(0)";
                anchor.innerHTML = String(p);
                anchor.addEventListener("click", () => this.toPage(p));
                li.appendChild(anchor);
            }

            const nextLi = document.createElement("li");
            nextLi.className = nextClass;
            ul.appendChild(nextLi);

            const nextPageAnchor = document.createElement("a");
            nextPageAnchor.className = "page-link";
            nextPageAnchor.setAttribute("aria-label", "Next");
            nextPageAnchor.href = "javascript:void(0)";
            nextPageAnchor.innerHTML = "<span class=\"button-text\">下一頁</span><span aria-hidden=\"true\">&rsaquo;</span>";
            nextPageAnchor.addEventListener("click", () => this.toPage(page + 1));
            nextLi.appendChild(nextPageAnchor);

            const lastLi = document.createElement("li");
            lastLi.className = nextClass;
            ul.appendChild(lastLi);

            const lastPageAnchor = document.createElement("a");
            lastPageAnchor.className = "page-link";
            lastPageAnchor.href = "javascript:void(0)";
            lastPageAnchor.innerHTML = "<span class=\"button-text\">最末頁</span><span aria-hidden=\"true\">&raquo;</span>";
            lastPageAnchor.addEventListener("click", () => this.toPage(totalPage));
            lastLi.appendChild(lastPageAnchor);
        } else {
            const prevLi = document.createElement("li");
            prevLi.className = prevClass;
            ul.appendChild(prevLi);

            const prevPageAnchor = document.createElement("a");
            prevPageAnchor.className = "page-link";
            prevPageAnchor.setAttribute("aria-label", "Previous");
            prevPageAnchor.href = "javascript:void(0)";
            prevPageAnchor.innerHTML = "<span aria-hidden=\"true\">&lsaquo;</span><span class=\"button-text\">上一頁</span>";
            prevPageAnchor.addEventListener("click", () => this.toPage(page - 1));
            prevLi.appendChild(prevPageAnchor);

            for (let i = 0; i < totalPage; i++) {
                const p = i + 1;
                const elemClass = "page-item" + (p !== page ? "" : " active");

                const li = document.createElement("li");
                li.className = elemClass;
                ul.appendChild(li);

                const anchor = document.createElement("a");
                anchor.className = "page-link";
                anchor.href = "javascript:void(0)";
                anchor.innerHTML = String(p);
                anchor.addEventListener("click", () => this.toPage(p));
                li.appendChild(anchor);
            }

            const nextLi = document.createElement("li");
            nextLi.className = nextClass;
            ul.appendChild(nextLi);

            const nextPageAnchor = document.createElement("a");
            nextPageAnchor.className = "page-link";
            nextPageAnchor.setAttribute("aria-label", "Next");
            nextPageAnchor.href = "javascript:void(0)";
            nextPageAnchor.innerHTML = "<span class=\"button-text\">下一頁</span><span aria-hidden=\"true\">&rsaquo;</span>";
            nextPageAnchor.addEventListener("click", () => this.toPage(page + 1));
            nextLi.appendChild(nextPageAnchor);
        }

        if (totalPage > 1 && totalPage < 1000) {
            const selectLi = document.createElement("li");
            selectLi.className = "page-button";
            ul.appendChild(selectLi);

            const selectSpan = document.createElement("span");
            selectSpan.className = "page-selector-span";
            selectSpan.innerHTML = "<span class=\"button-text\">前往</span><span>第</span>";
            selectLi.appendChild(selectSpan);

            const selector = document.createElement("select");
            selector.addEventListener("change", () => this._onPageSelectChange());
            this.pageSelector = selector;
            selectSpan.appendChild(selector);

            for (let i = 0; i < totalPage; i++) {
                const p = i + 1;
                const option = document.createElement("option");
                option.value = String(p);
                option.innerHTML = String(p);
                option.selected = p === page;
                selector.appendChild(option);
            }

            const selectTail = document.createElement("span");
            selectTail.innerText = "頁";
            selectSpan.appendChild(selectTail);
        }

        if (this.pageSize) {
            const pageSizeLi = document.createElement("li");
            pageSizeLi.className = "page-button page-size-button";
            ul.appendChild(pageSizeLi);
    
            const pageSizeSpan = document.createElement("span");
            pageSizeSpan.className = "page-size-span";
            pageSizeSpan.innerHTML = "<span>每頁</span>";
            pageSizeLi.appendChild(pageSizeSpan);
    
            const pageSizeInput = document.createElement("input");
            pageSizeInput.type = "number";
            pageSizeInput.className = "page-size-input";
            pageSizeInput.min = "1";
            pageSizeInput.max = "65536";
            pageSizeInput.addEventListener("change", () => this._onPageSizeChange());
            this.pageSizeInput = pageSizeInput;
            this.pageSizeInput.value = this.pageSize.value;
            pageSizeSpan.appendChild(pageSizeInput);
    
            const pageSizeTail = document.createElement("span");
            pageSizeTail.innerText = "筆";
            pageSizeSpan.appendChild(pageSizeTail);
        }

        if (this.paginationContainer) {
            this.paginationContainer.appendChild(nav);
        } else if (this.tableContainer) {
            this.tableContainer.appendChild(nav);
        }
    }
}
