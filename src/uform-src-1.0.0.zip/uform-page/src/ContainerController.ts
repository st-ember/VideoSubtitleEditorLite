
export default class ContainerController {

    stageSize: "sm" | "md" | "lg" = "lg";

    stageSizeReduceTime: number = 20;
    lgThreshold: number = 1280;
    mdThreshold: number = 860;

    header?: HTMLElement;
    main?: HTMLElement;
    footer?: HTMLElement;

    onStageWidthStepChangeFuncs: (() => void)[] = [];
    onStageWidthChangeFuncs: (() => void)[] = [];

    protected timer?: number;
    protected count: number = 0;

    init(): void {
        this.header = <HTMLElement | undefined>document.querySelector("header");
        this.main = <HTMLElement | undefined>document.querySelector("body > .container");
        this.footer = <HTMLElement | undefined>document.querySelector("footer");
        this.updateStageSize(true);

        this.reduceStageSizeUpdate = this.reduceStageSizeUpdate.bind(this);
        window.addEventListener("resize", this.reduceStageSizeUpdate);
    }

    updateStageSize(force?: boolean): void {
        let targetStageSize: "sm" | "md" | "lg" = "sm";
        const windowSize = window.innerWidth;
        if (windowSize > this.lgThreshold) {
            targetStageSize = "lg";
        } else if (windowSize > this.mdThreshold) {
            targetStageSize = "md";
        }

        if (force || this.stageSize !== targetStageSize) {
            if (this.header) {
                this.header.classList.remove(this.stageSize);
                this.header.classList.add(targetStageSize);
            }

            if (this.main) {
                this.main.classList.remove(this.stageSize);
                this.main.classList.add(targetStageSize);
            }

            if (this.footer) {
                this.footer.classList.remove(this.stageSize);
                this.footer.classList.add(targetStageSize);
            }

            this.stageSize = targetStageSize;
            this.onStageWidthStepChangeFuncs.forEach(func => func());
        }
        
        this.onStageWidthChangeFuncs.forEach(func => func());
    }

    protected reduceStageSizeUpdate(): void {
        if (!this.timer) {
            this.timer = setInterval(() => {
                this.count++;
                if (this.count >= this.stageSizeReduceTime) {
                    clearInterval(this.timer);
                    this.timer = undefined;
                    this.count = 0;
                    this.updateStageSize();
                }
            }, 10);
        } else {
            this.count = 0;
        }
    }
}

export const containerController = new ContainerController();
(<any>window).containerController = containerController;
containerController.init();