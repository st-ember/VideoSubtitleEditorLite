import Page from "Page";

export default class PageController {

    pageMap: { [key: string]: () => Page } = {};
    currentPage?: Page;

    onIdleTickingFuncs: ((idleTick: number) => void)[] = [];
    idleTickLength: number = 60000;

    private pages: Page[] = [];
    private _idleTime: number = 0;

    async loadAsync(): Promise<void> {
        this.pages = Object.keys(this.pageMap).map(key => this.pageMap[key]());

        const matchs = this.pages.filter(page => page.paths.map(o => o.toLowerCase()).indexOf(this.getPath()) >= 0);
        if (matchs.length > 0) {
            this.currentPage = matchs[0];
            await this.currentPage.startAsync();
        }
    }

    getPath(): string {
        return window.location.pathname.toLowerCase();
    }

    initIdleDectect(): void {
        window.addEventListener("mousemove", () => this._idleTime = 0);
        window.addEventListener("keydown", () => this._idleTime = 0);

        setInterval(() => {
            this._idleTime++;
            if (this._idleTime > 1) {
                this.onIdleTickingFuncs.forEach(func => func(this._idleTime));
            }
        }, this.idleTickLength) // 1min
    }
}