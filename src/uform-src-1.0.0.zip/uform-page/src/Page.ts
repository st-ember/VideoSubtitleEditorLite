import { containerController } from "ContainerController";

export default abstract class Page {
    
    paths: string[] = [];

    pageContainer?: HTMLDivElement;
    titleContainer?: HTMLDivElement;
    sideMenuContainer?: HTMLDivElement;

    protected title?: HTMLSpanElement;
    protected originalTitleWidth: number = 0;

    protected siteMenuActived: boolean = false;
    protected sideMenuButton?: HTMLButtonElement;

    async startAsync(): Promise<void> {
        this.pageContainer = <HTMLDivElement | undefined>document.querySelector(".page-container");
        this.titleContainer = <HTMLDivElement | undefined>document.querySelector(".title-container");
        this.sideMenuContainer = <HTMLDivElement | undefined>document.querySelector(".side-menu-container");
        await this.loadAsync();

        this.buildSideMenu();
        this.processTitle();
    }

    protected abstract loadAsync(): Promise<void>;

    protected buildSideMenu(): void {
        if (!this.titleContainer || !this.sideMenuContainer) {
            return;
        }

        const sideMenuButton = document.createElement("button");
        sideMenuButton.className = "side-menu-button small-button";
        sideMenuButton.type = "button";
        sideMenuButton.title = "側邊欄";
        sideMenuButton.innerHTML = "<span></span><span></span><span></span>";
        this.sideMenuButton = sideMenuButton;

        const sideMenuBackground = document.createElement("div");
        sideMenuBackground.className = "side-menu-background";
        this.sideMenuContainer.appendChild(sideMenuBackground);

        if (this.titleContainer.firstChild) {
            this.titleContainer.insertBefore(sideMenuButton, this.titleContainer.firstChild);
        } else {
            this.titleContainer.appendChild(sideMenuButton);
        }

        sideMenuButton.addEventListener("click", () => this.activeSideMenu(!this.siteMenuActived));
        sideMenuBackground.addEventListener("click", () => this.activeSideMenu(!this.siteMenuActived));
    }

    protected activeSideMenu(active: boolean): void {
        if (!active) {
            this.siteMenuActived = false;
            this.sideMenuButton?.classList.remove("active");
            this.sideMenuContainer?.classList.remove("active");
        } else {
            this.siteMenuActived = true;
            this.sideMenuButton?.classList.add("active");
            this.sideMenuContainer?.classList.add("active");
        }
    }

    protected processTitle(): void {
        if (this.titleContainer) {
            this.title = <HTMLSpanElement | undefined>this.titleContainer.querySelector(".title");
        }
        
        if (this.title) {
            containerController.onStageWidthChangeFuncs.push(() => this.adjustTitleWidth());
            setTimeout(() => this.adjustTitleWidth(), 100);
        }
    }

    protected adjustTitleWidth(): void {
        if (!this.title || !this.titleContainer) { return; }

        if (!this.originalTitleWidth) {
            this.originalTitleWidth = this.title.clientWidth;
        }
        
        let otherElementsWidth = 0;
        for (let i = 0; i < this.titleContainer.children.length; i++) {
            const element = this.titleContainer.children.item(i)!;
            if (!element.isSameNode(this.title)) {
                otherElementsWidth += element.clientWidth;

                const stylies = window.getComputedStyle(element);
                const marginRight = Number(stylies.marginRight.replace("px", ""));
                const marginLeft = Number(stylies.marginLeft.replace("px", ""));
                if (!isNaN(marginRight)) {
                    otherElementsWidth += marginRight;
                }

                if (!isNaN(marginLeft)) {
                    otherElementsWidth += marginLeft;
                }
            }
        }

        const maxWidth = this.titleContainer.clientWidth - otherElementsWidth;
        if (this.originalTitleWidth > maxWidth) {
            this.title.style.transform = `scaleX(${maxWidth / this.originalTitleWidth})`;
        } else {
            this.title.style.transform = "scaleX(1)";
        }
    }

    reload(): void {
        window.location.reload();
    }
}