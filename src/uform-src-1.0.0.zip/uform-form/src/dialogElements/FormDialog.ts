import Form from "baseElements/Form";
import dialogController, { Dialog, DialogOptions } from "uform-dialog";
import Utility from "uform-utility";

export default class FormDialog {

    formDialogOptions: FormDialogOptions = { 
        name: String(Number(new Date)), 
        type: "info",
        width: "1200px",
        forms: [],
        actionBarButtons: []
    };

    dialog: Dialog = null!;
    dialogBody: HTMLDivElement = document.createElement("div");
    actionBarContainer: HTMLDivElement = document.createElement("div");
    bodyContainer: HTMLDivElement = document.createElement("div");
    buttons: FormDialogButton[] = [];
    forms: Form[] = [];
    loading?: HTMLDivElement;

    warningActionBar: HTMLDivElement = document.createElement("div");
    buttonActionBar: HTMLDivElement = document.createElement("div");
    otherActionBars: HTMLDivElement[] = [];

    protected scrollParent?: HTMLElement;
    protected actionBarStickyed: boolean = false;

    constructor(options?: FormDialogOptions) {
        if (options) {
            this.formDialogOptions = options;
        }
    }

    async initAsync(): Promise<void> {
        await this.beforeBuildAsync();
        this._buildDialogBody();
        this.dialog = (await dialogController.showAsync(this.formDialogOptions.name, this._buildDialogOptions()))!;
        this.showLoadingBox(true);
        await this._checkAndBuildFormsAsync();
        await this._processActionBar();
        await this.processFormsAsync();
        this.showLoadingBox(false);
    }

    private _buildDialogBody(): void {
        this.dialogBody.className = "form-dialog-body";

        this.actionBarContainer.className = "form-dialog-action-bar-container";
        this.dialogBody.appendChild(this.actionBarContainer);

        this.bodyContainer.className = "form-dialog-body-container";
        this.dialogBody.appendChild(this.bodyContainer);

        this._buildActionBars();
        this._buildActionBarButtons();

        this.formDialogOptions.forms.forEach(form => {
            if (form && form.element) {
                const formContainer = document.createElement("div");
                formContainer.className = "form-dialog-form-container";
                this.bodyContainer.appendChild(formContainer);

                formContainer.appendChild(form.element);
                this.forms.push(form);
            }
        });
    }

    private _buildActionBars(): void {
        this.warningActionBar.className = "form-dialog-action-bar form-theme-title form-theme-color  warning hide";
        this.warningActionBar.innerHTML = `<i class=\"fa fa-warning\"></i><span></span>`;
        this.actionBarContainer.appendChild(this.warningActionBar);

        this.buttonActionBar.className = "form-dialog-action-bar form-theme-title form-theme-color ";
        this.buttonActionBar.innerHTML = `<span class=\"title\">${this.formDialogOptions.actionBarTitle ?? ""}</span>`;
        this.actionBarContainer.appendChild(this.buttonActionBar);

        if (this.formDialogOptions.actionBars) {
            this.formDialogOptions.actionBars.forEach(actionBarOptions => {
                const element = document.createElement("div");
                element.className = `form-dialog-action-bar form-theme-title form-theme-color ${actionBarOptions.className ? ` ${actionBarOptions}` : ""}`;

                if (actionBarOptions.element) {
                    element.appendChild(actionBarOptions.element);
                } else {
                    element.innerHTML = `${actionBarOptions.icon ? `<i class=\"${actionBarOptions}\"></i>` : ""}<span class=\"title\">${actionBarOptions.text ? actionBarOptions.text : ""}</span>`
                }

                this.actionBarContainer.appendChild(element);
            });
        }
    }

    private _buildActionBarButtons(): void {
        if (this.formDialogOptions.actionBarButtons) {
            this.formDialogOptions.actionBarButtons.forEach(buttonOptions => {
                const element = document.createElement("button");
                element.type = "button";
                element.className = buttonOptions.className ? buttonOptions.className : "";
                element.innerHTML = `${buttonOptions.icon ? `<i class=\"${buttonOptions.icon}\"></i>` : ""}${buttonOptions.text}`;
                element.name = buttonOptions.name;
                element.addEventListener("click", () => buttonOptions.callback());
                this.buttonActionBar.appendChild(element);

                this.buttons.push({ name: buttonOptions.name, element });
            });
        }
    }

    private _buildDialogOptions(): DialogOptions {
        return {
            width: this.formDialogOptions?.width,
            closeAction: "delete",
            headerCloseButton: true,
            title: this.formDialogOptions?.title,
            type: this.formDialogOptions ? this.formDialogOptions.type : "info",
            icon: this.formDialogOptions?.icon,
            className: this.formDialogOptions?.className,
            bodyPadding: false,
            body: this.dialogBody,
            buttons: [],
            onBuildAsync: this.formDialogOptions?.onBuildAsync,
            onShowAsync: this.formDialogOptions?.onShowAsync,
            onCloseAsync: async () => {
                this.showLoadingBox(true);

                if (this.formDialogOptions && this.formDialogOptions.onCloseAsync) {
                    await this.formDialogOptions.onCloseAsync();
                }

                await Promise.all(this.forms.map(form => form.deleteAsync()));
            },
            keyboardClose: false,
            backdropClose: false
        };
    }

    private async _checkAndBuildFormsAsync(): Promise<void> {
        const unfinishedForms = this.forms.filter(form => form.state !== 2);
        if (unfinishedForms.length === 0) {
            return;
        }

        const tasks = unfinishedForms
            .map(form => {
                if (form.state === 1) {
                    return new Promise<void>(resolve => {
                        const timer = setInterval(() => {
                            if (form.state === 2) {
                                clearInterval(timer);
                                resolve();
                            }
                        }, 10);
                    });
                } else if (form.state === 0) {
                    return new Promise<void>(resolve => form.buildAsync().then(() => resolve()));
                } else {
                    return new Promise<void>(resolve => resolve());
                }
            });

        await Promise.all(tasks);
    }

    private async _processActionBar(): Promise<void> {
        this.scrollParent = Utility.getScrollParent(this.actionBarContainer);
        this._onScrollParentScroll = this._onScrollParentScroll.bind(this);
        this.scrollParent?.addEventListener("scroll", this._onScrollParentScroll);
    }

    private _updateStickyActionBar(): void {
        if (!this.scrollParent) {
            return;
        }

        const scrollParentRect = this.scrollParent.getBoundingClientRect();
        const elementRect = this.dialogBody.getBoundingClientRect();
        const headerRect = this.actionBarContainer.getBoundingClientRect();

        if (elementRect.bottom - scrollParentRect.top < headerRect.height * 2) {
            this.actionBarStickyed = false;
            this.actionBarContainer.classList.remove("sticky");
            this.actionBarContainer.style.width = "";
            this.actionBarContainer.style.left = "";
            this.actionBarContainer.style.top = "auto";
            this.actionBarContainer.style.bottom = "50px";
            this.dialogBody.style.paddingTop = "";
        } else if (!this.actionBarStickyed && elementRect.top - scrollParentRect.top < 0) {
            this.actionBarStickyed = true;
            this.actionBarContainer.classList.add("sticky");
            this.actionBarContainer.style.width = `${headerRect.width}px`;
            this.actionBarContainer.style.left = `${headerRect.x}`;
            this.actionBarContainer.style.top = `${scrollParentRect.top}px`;
            this.actionBarContainer.style.bottom = "";
            this.dialogBody.style.paddingTop = `${headerRect.height}px`;
        } else if (elementRect.top - scrollParentRect.top >= 0) {
            this.actionBarStickyed = false;
            this.actionBarContainer.classList.remove("sticky");
            this.actionBarContainer.style.width = "";
            this.actionBarContainer.style.left = "";
            this.actionBarContainer.style.top = "";
            this.actionBarContainer.style.bottom = "";
            this.dialogBody.style.paddingTop = "";
        }
    }

    private _onScrollParentScroll(): void {
        this._updateStickyActionBar();
    }

    /** 在開始建立 Dialog 前，會執行此 Function。 */
    protected async beforeBuildAsync(): Promise<void> { }

    /** 完成 Dialog 與所有表單的 Build 程序後，會執行此 Function。 */
    protected async processFormsAsync(): Promise<void> { }

    /** 驗證所有的表單是否有效。 */
    async validateAsync(): Promise<boolean> {
        this.showLoadingBox(true);
        const valid = (await Promise.all(this.forms.map(form => form.validateAsync()))).filter(o => !o).length === 0;
        this.showWarningMessage(!valid, "驗證表單資料時發生錯誤，請檢視並調整所有被標註為紅色的項目。");
        this.showLoadingBox(false);
        return valid;
    }

    /** 顯示/關閉警告訊息，或修改警告訊息的文字。 */
    showWarningMessage(show: boolean, message?: string): void {
        this.warningActionBar.innerHTML = `<i class=\"fa fa-warning\"></i><span>${message ? message : ""}</span>`;

        if (show) {
            this.warningActionBar.classList.remove("hide");
        } else {
            this.warningActionBar.classList.add("hide");
        }
    }

    showLoadingBox(show: boolean): void {
        if (show && !this.loading) {
            this.loading = document.createElement("div");
            this.loading.className = "loading-box";
            this.dialogBody.appendChild(this.loading);
        }

        if (show) {
            this.loading?.classList.remove("hide");
        } else {
            this.loading?.classList.add("hide");
        }
    }

    async closeAsync(): Promise<void> {
        await dialogController.closeAsync(this.dialog);
    }
}

export interface FormDialogOptions {
    name: string;
    width?: string | number;
    title?: string;
    type?: "info" | "success" | "warning" | "error";
    icon?: string;
    className?: string;
    onBuildAsync?: () => Promise<void>;
    onShowAsync?: () => Promise<void>;
    onCloseAsync?: () => Promise<void>;

    forms: Form[];
    actionBarTitle?: string;
    actionBarButtons?: FormDialogButtonOptions[];
    actionBars?: FormDialogActionBarOptions[];

    /** 自動在 Dialog 完成建立後檢查是否所有的 Form 已完成 Build，如未完成則執行 Build 並顯示載入訊息。 */
    autoBuildForm?: boolean;
}

export interface FormDialogButtonOptions {
    name: string;
    icon?: string;
    className?: string;
    text: string;
    callback: () => void;
}

export interface FormDialogActionBarOptions {
    className?: string;
    element?: HTMLElement;
    icon?: string;
    text?: string;
}

export interface FormDialogButton {
    name: string;
    element: HTMLButtonElement;
}