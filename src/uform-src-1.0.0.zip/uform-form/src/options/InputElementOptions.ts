import FormElementOptions from "./FormElementOptions";

export default interface InputElementOptions extends FormElementOptions {
    type?: string;
    placeholder?: string;
    autocomplete?: boolean;
    spellcheck?: boolean;
    minLength?: number;
    maxLength?: number;
    format?: "email" | "twId" | "twUniId" | "allTwId" | "phone";
    /** 是否在 Format 檢查失敗時顯示為錯誤並導致表單驗證失敗。預設為 True。 */
    formatError?: boolean;
    formatChecker?: (value: string) => Promise<{ valid: boolean, error?: string }>;
}
