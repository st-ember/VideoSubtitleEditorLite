import FormElement from "baseElements/FormElement";
import FormElementContainerOptions from "./FormElementContainerOptions";

export default interface ElementExpanderOptions<TRow extends FormElement> extends FormElementContainerOptions {

    /** 每個 Row 的建立 Function */
    formElementCreationFunc: () => TRow;

    /** 新增與刪除的按鈕放在每行的前面。 */
    buttonAhead?: boolean;

    /** 是否顯示新增與刪除按鈕。 */
    showExpandButtons?: boolean;

    /** 新增按鈕的 title 屬性值 */
    insertButtonTitle?: string;

    /** 刪除按鈕的 title 屬性值 */
    deleteButtonTitle?: string;

    /** 顯示在新增與刪除按鈕前的標題文字。 */
    title?: string;

    /** 以表格形式來呈現此元件的設定。在 columns 屬性內提供 head 的文字與欄位寬度。 */
    tableOptions?: ElementExpanderTableOptions;
}

export interface ElementExpanderTableOptions {
    columns: { head?: string, flex?: number, width?: string | number }[];
    hideHeader?: boolean;
}