import FormElementContainer from "baseElements/FormElementContainer";
import FormElementOptions from "./FormElementOptions";

export default interface FormElementContainerOptions extends FormElementOptions {
    buildChildrenFunc?: (formElementContainer: FormElementContainer) => Promise<void>;
    inline?: boolean;
    multipleLine?: boolean;
    border?: boolean;
    marge?: boolean;
}