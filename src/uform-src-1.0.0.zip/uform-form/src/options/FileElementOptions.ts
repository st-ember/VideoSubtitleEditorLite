import { Api } from "uform-api";
import FormElementOptions from "./FormElementOptions";

export default interface FileElementOptions extends FormElementOptions {
    showFilename?: boolean;
    /** 可上傳檔案時，如果沒有檔案被上傳時要顯示的文字訊息。 */
    emptyMessage?: string;
    /** 顯示在按鈕上的文字。 */
    uploadButtonText?: string;
    /** 已上傳過後，要額外顯示在按鈕的文字。 */
    uploadedText?: string;
    /** 是否允許上傳多個檔案。 */
    multiple?: boolean;
    /** 是否開啟唯讀模式。 */
    readonly?: boolean;
    /** 允許的副檔名。 */
    acceptedExtensions?: string[];
    /** 允許的最大檔案大小。 */
    maxUploadFileSize?: number;
    /** 上傳檔案所使用的 API 設定 */
    uploadApi?: Api;
    /** 是否允許人工刪除已經上傳的檔案，預設為是。 */
    deletable?: boolean;
    /** 是否允許下載已經上傳的檔案，預設為是。 */
    downloadable?: boolean;
    /** 是否在元件被刪除時自動刪除所有檔案，預設為否。 */
    autoDelete?: boolean;
    /** 是否在選擇檔案後立刻上傳，預設為是。 */
    autoUpload?: boolean;
    /** 當開始上傳時，一旦進度變更將會呼叫的方法。 */
    onProgress?: (progress: number) => void;
    /** 碰到沒有 Ticket 的檔案時是否顯示錯誤，預設為否。 */
    ignoreEmptyTicketError?: boolean;
}
