
export default interface FormElementOptions {
    /** 指定元件使用的 ID；如未指定，元件會自動獲得一個全域唯一 ID。 */
    id?: string;
    name?: string;
    /** 元件的寬度，可用數字代表 px 值，或是輸入 css 可接受的字串。 */
    width?: number | string;
    /** 元件在 Flex 模式下的寬度，只可提供數字。與 width 同時設定時會取代 width 的功能。 */
    flex?: number;
    /** 元件前方的標籤。 */
    label?: string;
    /** 元件預設的必要屬性。 */
    required?: boolean;
    /** 元件預設的停用屬性。 */
    disabled?: boolean;
    /** 元件預設的隱藏屬性。 */
    hide?: boolean;
    /** 當元件觸發 change 事件後會執行的 Function 清單。 */
    onChangeFuncs?: (((value?: any) => void) | ((value?: any) => Promise<void>))[];
    /** 強制隱藏元件必要時顯示在前方的紅色星號。 */
    hideReqiredIcon?: boolean;
    /** 元件的 title 屬性，通常是滑鼠置於元件上時要顯示的說明文字。 */
    title?: string;
}