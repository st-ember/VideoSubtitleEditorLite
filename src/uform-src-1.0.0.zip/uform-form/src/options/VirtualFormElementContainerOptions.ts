import FormElementContainer from "baseElements/FormElementContainer";
import FormElementOptions from "./FormElementOptions";
import VirtualFormElementContainer from "baseElements/VirtualFormElementContainer";

export default interface VirtualFormElementContainerOptions extends FormElementOptions {
    parent: FormElementContainer;
    buildChildrenFunc?: (formElementContainer: VirtualFormElementContainer) => Promise<void>;
}
