import PickerElementOptions from "./PickerElementOptions";

export default interface CheckboxGroupElementOptions extends PickerElementOptions {
    childWidth?: number | string;
    multipleLine?: boolean;
}
