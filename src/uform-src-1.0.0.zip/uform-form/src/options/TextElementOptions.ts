import FormElementOptions from "./FormElementOptions";

export default interface TextElementOptions extends FormElementOptions {
    text?: string;
    multipleLines?: boolean;
    color?: string;
    fontWeight?: string;
    fontSize?: string;
    textAlign?: string;
}