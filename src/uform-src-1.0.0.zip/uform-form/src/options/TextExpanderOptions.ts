import FormElementContainerOptions from "./FormElementContainerOptions";

export default interface TextExpanderOptions extends FormElementContainerOptions {
    allowDuplicated?: boolean;
    textWhenEmpty?: string;
    appendButtonText?: string;
    appendButtonTitle?: string;
}
