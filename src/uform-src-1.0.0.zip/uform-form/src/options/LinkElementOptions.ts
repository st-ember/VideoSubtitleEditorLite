import FormElementOptions from "./FormElementOptions";

export default interface LinkElementOptions extends FormElementOptions {
    icon?: string;
    text?: string;
    href?: string;
    onClick?: () => void;
}
