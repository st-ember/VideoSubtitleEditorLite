import FormElementOptions from "./FormElementOptions";

export default interface RadioElementOptions extends FormElementOptions {
    name: string;
    text?: string;
    value: string;
    /** 預設狀態是否為未選擇。預設為 False，元件完成建立後會自動選擇第一個項目。 */
    allowEmpty?: boolean;
}
