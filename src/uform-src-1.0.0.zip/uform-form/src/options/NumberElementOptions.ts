import FormElementOptions from "./FormElementOptions";

export default interface NumberElementOptions extends FormElementOptions {
    type?: string;
    max?: number;
    min?: number;
    step?: number;
    placeholder?: string;
    value?: number;
}
