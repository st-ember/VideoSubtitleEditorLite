import FormElementOptions from "./FormElementOptions";

export default interface TitleElementOptions extends FormElementOptions {
    text?: string;
}
