import FormElementOptions from "./FormElementOptions";

export default interface ButtonElementOptions extends FormElementOptions {
    icon?: string;
    text?: string;
    type?: "default" | "primary" | "success" | "warning" | "danger" | "dark";
    small?: boolean;
    onClick?: () => void;
}