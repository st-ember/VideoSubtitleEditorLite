import FormElementOptions from "./FormElementOptions";

export default interface IconElementOptions extends FormElementOptions {
    title?: string;
    text?: string;
    type?: "info" | "success" | "warning" | "danger";
}