import FormElementOptions from "./FormElementOptions";

export default interface TextAreaElementOptions extends FormElementOptions {
    rows?: number;
    placeholder?: string;
    autocomplete?: boolean;
}
