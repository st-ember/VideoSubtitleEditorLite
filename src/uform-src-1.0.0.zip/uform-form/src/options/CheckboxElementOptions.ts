import FormElementOptions from "./FormElementOptions";

export default interface CheckboxElementOptions extends FormElementOptions {
    text?: string;
}
