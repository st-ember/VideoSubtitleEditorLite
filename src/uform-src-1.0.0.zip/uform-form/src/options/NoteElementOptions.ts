import TextElementOptions from "./TextElementOptions";

export default interface NoteElementOptions extends TextElementOptions {
    type?: "info" | "success" | "warning" | "danger";
    inline?: boolean;
}
