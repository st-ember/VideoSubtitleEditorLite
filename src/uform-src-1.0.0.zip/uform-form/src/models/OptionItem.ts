
export default interface OptionItem {
    value?: string;
    text?: string;
    subText?: string;
}