export default interface CachedFile {
    /** Input 元件的 ID */
    elementId: string;
    /** 包含副檔名的檔案名稱 */
    filename: string;
    /** 來自 Input 元件的原始 File 物件 */
    file: File;
    /** Base64 格式的資料 */
    data: string;
    /** 檔案的 Ticket，擁有 Ticket 代表此檔案已經上傳。 */
    ticket?: string;
    /** 檔案大小(byte) */
    size?: number;
}
