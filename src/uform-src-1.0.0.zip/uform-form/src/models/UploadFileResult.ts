import FileData from "./FileData";

export default interface UploadFileResult {
    uploadedFiles: FileData[];
    success: boolean;
    message?: string;
}
