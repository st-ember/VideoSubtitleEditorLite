
export default interface FileData {
    filename: string;
    /** 檔案的 Ticket */
    ticket: string;
    /** 檔案大小(byte) */
    size?: number;
}