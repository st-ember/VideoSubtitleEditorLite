import FormElementContainer from "baseElements/FormElementContainer";
import RadioGroup from "misc/RadioGroup";

export default class FormController {

    private _currentElementId: number = 0;
    private _currentFormId: number = 0;

    forms: { [key: string]: FormElementContainer } = {};
    radioGroups: { [name: string]: RadioGroup } = {};

    getNewElementId(): number {
        return this._currentElementId++;
    }

    async appendAsync(formElement: FormElementContainer): Promise<void>;
    async appendAsync(formElement: Promise<FormElementContainer>): Promise<void>;
    async appendAsync(formElement: FormElementContainer | Promise<FormElementContainer>): Promise<void> {
        let element: FormElementContainer;
        if ("then" in formElement) {
            // Is Promise type.
            element = await formElement;
        } else {
            element = formElement;
        }

        if (!element.name) {
            element.name = `form-${this._currentFormId++}`;
        }

        this.forms[element.name] = element;
    }

    // async testAsync(): Promise<void> {
    //     const target = document.getElementById("test-form-0");
    //     if (target) {
    //         const testForm = new TestForm(target);
    //         await testForm.buildAsync();
    //         await this.appendAsync(testForm);

    //         await testForm.formExapnder.clearAsync();

    //         setTimeout(() => {
    //             const formDialog = new TestFormDialog();
    //             formDialog.initAsync();
    //         }, 100);
    //     }
    // }
}

export const formController = new FormController();
(<any>window).formController = formController;

// window.addEventListener("load", () => formController.testAsync());

// class TestForm extends FormGeneric<TestFormData> {

//     formExapnder: FormExpander<FormElementContainer, TestFormData>;

//     async buildChildrenAsync(): Promise<void> {

//         const typeaheadSource = [
//             { value: '128', text: '墨西哥1', subText: 'subtext' },
//             { value: '576', text: '智利1' },
//             { value: '1088', text: '哥倫比亞1' },
//             { value: '1648', text: '阿根廷2' },
//             { value: '2112', text: '委內瑞拉2' }
//         ];

//         const formExpander = await FormExpander.fromAsync<FormElementContainer, TestFormData>({
//             name: "test-form-expander",
//             required: true,
//             label: "測試 Form",
//             max: 30,
//             title: "測試 Form",
//             formCreationFunc: () => new FormElementContainer({
//                 multipleLine: true,
//                 buildChildrenFunc: async form => {

//                     const name = await InputElement.fromAsync({ name: "nameInput", label: "名稱" });
//                     await form.appendAsync(name);

//                     const search = await TypeaheadElement.fromAsync({
//                         required: true,
//                         name: "searchInput",
//                         label: "搜尋測試",
//                         directInput: true,
//                         searchFunc: async text => {
//                             await util.wait(500);
//                             return {
//                                 success: true,
//                                 items: typeaheadSource.filter(o => o.text.indexOf(text) >= 0)
//                             }
//                         }
//                     });
//                     await form.appendAsync(search);

//                     const issueDate = await DateElement.fromAsync({ 
//                         name: "issueDate", 
//                         label: "發證日期", 
//                         required: true,
//                         yearFormater: year => String(year - 1911),
//                         dateParser: text => {
//                             const array = text.split('/');
//                             return array.length === 3 ? new Date(`${Number(array[0]) + 1911}.${array[1]}.${array[2]}`) : undefined;
//                         }
//                     });
//                     await form.appendAsync(issueDate);
            
//                     const readonlyIssueDate = await ReadonlyDateElement.fromAsync({
//                         name: "issueDate", 
//                         label: "發證日期", 
//                         yearFormater: year => String(year - 1911),
//                         dateParser: text => {
//                             const array = text.split('/');
//                             return array.length === 3 ? new Date(`${Number(array[0]) + 1911}.${array[1]}.${array[2]}`) : undefined;
//                         }
//                     });
//                     await form.appendAsync(readonlyIssueDate);
            
//                     issueDate.addChangeFunc(value => readonlyIssueDate.setValueAsync(value));

//                     const length = await TimeSpanElement.fromAsync({ name: "length", label: "片長", required: true });
//                     await form.appendAsync(length);

//                     const readonlyLength = await ReadonlyInputElement.fromAsync({ name: "length", label: "片長" });
//                     await form.appendAsync(readonlyLength);
//                     length.addChangeFunc(async () => readonlyLength.setValueAsync(await length.getFormattedValue()));

//                     const sponsorMargeGroup = await FormElementContainer.fromAsync({
//                         label: "單位",
//                         marge: true,
//                         required: true,
//                         multipleLine: true,
//                         disabled: true,
//                         buildChildrenFunc: async group => {
//                             const distributors = await ElementExpander.fromAsync<TestSponsorElement, TestSponsor>({
//                                 name: "distributors",
//                                 required: true,
//                                 title: "出品單位",
//                                 formElementCreationFunc: () => new TestSponsorElement(),
//                                 tableOptions: {
//                                     columns: [{ head: "名稱", width: "200px" }, { head: "國家", width: "200px" }, { head: "統一編號", width: "200px" }]
//                                 }
//                             });
//                             await group.appendAsync(distributors);
                    
//                             const producers = await ElementExpander.fromAsync<TestSponsorElement, TestSponsor>({
//                                 name: "producers",
//                                 required: true,
//                                 title: "製作單位",
//                                 formElementCreationFunc: () => new TestSponsorElement(),
//                                 tableOptions: {
//                                     columns: [{ head: "", width: "200px" }, { head: "", width: "200px" }, { head: "", width: "200px" }],
//                                     hideHeader: true
//                                 }
//                             });
//                             await group.appendAsync(producers);
//                         }
//                     });
//                     await form.appendAsync(sponsorMargeGroup);

//                     const publishers = await ElementExpander.fromAsync<TestSponsorElement, TestSponsor>({
//                         name: "publishers",
//                         required: true,
//                         label: "發行單位",
//                         formElementCreationFunc: () => new TestSponsorElement(),
//                         tableOptions: {
//                             columns: [{ head: "名稱", width: "200px" }, { head: "國家", width: "200px" }, { head: "統一編號", width: "200px" }]
//                         }
//                     });
//                     await form.appendAsync(publishers);
//                 }
//             }),
//             rowTitleChangeHooker: async (form, updateTitle) => {
//                 form.getElement("nameInput").addChangeFunc(() => {
//                     form.getElement("nameInput").getValueAsync().then(value => updateTitle(value));
//                 });
//             }
//         });
//         await this.appendAsync(formExpander);
//         this.formExapnder = formExpander;
        
//         const formExpanderDistributor = await FormExpanderDistributor.fromDistributorOptionsAsync<FormElementContainer, TestFormData>({
//             formExpander
//         });
//         await this.appendAsync(formExpanderDistributor);
        
//         const issueDate = await DateElement.fromAsync({ 
//             name: "issueDate", 
//             label: "發證日期", 
//             required: true,
//             yearFormater: year => String(year - 1911),
//             dateParser: text => {
//                 const array = text.split('.');
//                 return array.length === 3 ? new Date(`${Number(array[0]) + 1911}.${array[1]}.${array[2]}`) : undefined;
//             }
//         });
//         await this.appendAsync(issueDate);

//         const readonlyIssueDate = await ReadonlyDateElement.fromAsync({
//             name: "issueDate", 
//             label: "發證日期", 
//             yearFormater: year => String(year - 1911),
//             dateParser: text => {
//                 const array = text.split('.');
//                 return array.length === 3 ? new Date(`${Number(array[0]) + 1911}.${array[1]}.${array[2]}`) : undefined;
//             }
//         });
//         await this.appendAsync(readonlyIssueDate);

//         issueDate.addChangeFunc(value => readonlyIssueDate.setValueAsync(value));

//         const margeGroup = await FormElementContainer.fromAsync({
//             label: "檔案合併",
//             required: true,
//             marge: true,
//             multipleLine: true,
//             buildChildrenFunc: async group => {
//                 const title = TitleElement.fromAsync({ text: "測試標題" });
//                 await group.appendAsync(title);

//                 const testFile0 = await FileElement.fromAsync({
//                     required: true,
//                     acceptedExtensions: ["docx", "xlsx"]
//                 });
//                 await group.appendAsync(testFile0);
        
//                 testFile0.setSingleValueAsync({
//                     filename: "分級證明字號.docx",
//                     ticket: "1"
//                 });
        
//                 const testFile1 = await FileElement.fromAsync({
//                     multiple: true,
//                     required: true,
//                     acceptedExtensions: ["docx", "xlsx"]
//                 });
//                 await group.appendAsync(testFile1);
        
//                 testFile1.setValueAsync([
//                     { filename: "您好，為辦理本系統更新作業，系統預計於111年6月9日(週四)18:00-22:00進行更新，屆時系統將暫時提供服務，造成不便，敬請見諒.docx", ticket: "1" }, 
//                     { filename: "分級證明字號2.docx", ticket: "2" }, { filename: "分級證明字號3.docx", ticket: "3" }, 
//                     { filename: "分級證明字號4.docx", ticket: "4" }, { filename: "分級證明字號5.docx", ticket: "5" }, { filename: "分級證明字號6.docx", ticket: "6" }
//                 ]);
        
//                 const testFile2 = await FileElement.fromAsync({
//                     required: true,
//                     acceptedExtensions: ["docx", "xlsx"]
//                 });
//                 await group.appendAsync(testFile2);
//             }
//         });
        
//         await this.appendAsync(margeGroup);

//         const testFile3 = await FileElement.fromAsync({
//             label: "電影片在影展中公開映演之證明文件（中文譯本）",
//             readonly: true,
//             required: true
//         });
//         await this.appendAsync(testFile3);

//         testFile3.setSingleValueAsync(<any>{
//             filename: "分級證明字號.docx",
//             ticket: undefined
//         });

//         const testFormText = await TextElement.fromAsync({ 
//             text: "電影片在影展中公開映演之證明文件（中文譯本）",
//             color: "#555",
//             fontWeight: "bold",
//             required: true
//         });
//         await this.appendAsync(testFormText);

//         const testFormAnchor = LinkElement.fromAsync({
//             text: "測試連結",
//             icon: "fa-regular fa-file-lines",
//             onClick: () => {
//                 console.log("test")
//             }
//         });
//         await this.appendAsync(testFormAnchor);

//         const radioGroup = FormElementContainer.fromAsync({
//             label: "測試 Radio",
//             border: true,
//             multipleLine: true,
//             buildChildrenFunc: async group => {
//                 const title = TitleElement.fromAsync({ text: "測試標題" });
//                 await group.appendAsync(title);

//                 const vGroup = FormElementContainer.fromAsync({
//                     buildChildrenFunc: async group => {
//                         const option0 = RadioElement.fromAsync({ name: `test-radio-${group.id}`, value: "0", text: "選項 0" });
//                         await group.appendAsync(option0);
        
//                         const option1 = RadioElement.fromAsync({ name: `test-radio-${group.id}`, value: "1", text: "選項 1" });
//                         await group.appendAsync(option1);
        
//                         const option2 = RadioElement.fromAsync({ name: `test-radio-${group.id}`, value: "2", text: "選項 2" });
//                         await group.appendAsync(option2);
//                     }
//                 });
//                 await group.appendAsync(vGroup);
//             }
//         });
//         await this.appendAsync(radioGroup);

//         // const certification = FormElementContainer.fromAsync({
//         //     label: "分級證明字號",
//         //     required: true,
//         //     buildChildrenFunc: async group => {
//         //         const certificationType = SelectElement.fromAsync({ 
//         //             name: "certificationType",
//         //             required: true,
//         //             options: [{ value: "A", text: "外" }]
//         //         });
//         //         await group.appendAsync(certificationType);

//         //         const certificationNumber = InputElement.fromAsync({
//         //             name: "certificationNumber",
//         //             required: true,
//         //             autocomplete: false
//         //         });
//         //         await group.appendAsync(certificationNumber);
//         //     }
//         // });
//         // await this.appendAsync(certification);

//         // const certificationPeriod = await DateRangeElement.fromAsync({
//         //     required: true,
//         //     label: "分級證明有效期間",
//         //     textBetween: "至",
//         //     allowEmpty: false,
//         //     yearFormater: year => String(year - 1911),
//         //     dateParser: text => {
//         //         const array = text.split('.');
//         //         return array.length === 3 ? new Date(`${Number(array[0]) + 1911}.${array[1]}.${array[2]}`) : undefined;
//         //     }
//         // });
//         // await this.appendAsync(certificationPeriod);

//         // const readonlyCertificationPeriod = await ReadonlyDateRangeElement.fromAsync({
//         //     label: "分級證明有效期間",
//         //     textBetween: "至",
//         //     yearFormater: year => String(year - 1911),
//         //     dateParser: text => {
//         //         const array = text.split('.');
//         //         return array.length === 3 ? new Date(`${Number(array[0]) + 1911}.${array[1]}.${array[2]}`) : undefined;
//         //     }
//         // });
//         // await this.appendAsync(readonlyCertificationPeriod);

//         // certificationPeriod.addChangeFunc(async () => await readonlyCertificationPeriod.setValueAsync(await certificationPeriod.getDateValueAsync()));

//         // const name = InputElement.fromAsync({ name: "name", label: "中文片名", required: true });
//         // await this.appendAsync(name);
        
//         // const originalName = InputElement.fromAsync({ name: "originalName", label: "外文片名", required: true });
//         // await this.appendAsync(originalName);

//         // const countries = SelectElement.fromAsync({ 
//         //     name: "countries", 
//         //     label: "國家", 
//         //     required: true,
//         //     options: [{ value: "-1", text: "請選擇" }]
//         // })
//         // await this.appendAsync(countries);
        
//         const langGroup = FormElementContainer.fromAsync({
//             label: "主語別",
//             required: true,
//             marge: true,
//             buildChildrenFunc: async group => {
//                 const testCheckbox = CheckboxElement.fromAsync({ name: "testcheckbox", text: "測試 Checkbox" });
//                 await group.appendAsync(testCheckbox)

//                 const lang = SelectElement.fromAsync({
//                     name: "lang",
//                     required: true,
//                     options: [{ value: "1", text: "國語" }, { value: "2", text: "台語" }, { value: "6", text: "其他" }]
//                 });
//                 await group.appendAsync(lang);

//                 const langOther = InputElement.fromAsync({ name: "langOther", autocomplete: false });
//                 await group.appendAsync(langOther);

//                 const testDate = DateRangeElement.fromAsync({ name: "testDate", allowEmpty: false, required: true, hideReqiredIcon: true });
//                 await group.appendAsync(testDate)

//                 const otherIcon = IconElement.fromAsync({ text: "其他 Icon" });
//                 await group.appendAsync(otherIcon);

//                 const published = await RadioButtonElement.fromAsync({
//                     name: "test-radio",
//                     options: [{ text: "公開", value: "1" }, { text: "不公開", value: "0" }]
//                 });
//                 await group.appendAsync(published);
//             }
//         });
//         await this.appendAsync(langGroup);

//         const length = await TimeSpanElement.fromAsync({ name: "length", label: "片長", required: true, disabled: true });
//         await this.appendAsync(length);

//         const readonlyLength = await ReadonlyInputElement.fromAsync({ name: "length", label: "片長" });
//         await this.appendAsync(readonlyLength);
//         length.addChangeFunc(async () => readonlyLength.setValueAsync(await length.getFormattedValue()));

//         const sponsorMargeGroup = await FormElementContainer.fromAsync({
//             label: "單位",
//             marge: true,
//             required: true,
//             multipleLine: true,
//             buildChildrenFunc: async group => {
//                 const distributors = await ElementExpander.fromAsync<TestSponsorElement, TestSponsor>({
//                     name: "distributors",
//                     required: true,
//                     title: "消費者對於電影片映演業禁止其攜帶外食之處理不願接受時，得要求全額退費，且電影片映演業不得拒絕及收取手續費或其他任何費用",
//                     formElementCreationFunc: () => new TestSponsorElement(),
//                     tableOptions: {
//                         columns: [{ head: "消費者對於電影片映演業禁止其攜帶外食之處理不願接受時，得要求全額退費，且電影片映演業不得拒絕及收取手續費或其他任何費用", width: "200px" }, { head: "國家", width: "200px" }, { head: "統一編號", width: "200px" }]
//                     }
//                 });
//                 await group.appendAsync(distributors);
        
//                 const producers = await ElementExpander.fromAsync<TestSponsorElement, TestSponsor>({
//                     name: "producers",
//                     required: true,
//                     title: "製作單位",
//                     formElementCreationFunc: () => new TestSponsorElement(),
//                     tableOptions: {
//                         columns: [{ head: "", width: "200px" }, { head: "", width: "200px" }, { head: "", width: "200px" }],
//                         hideHeader: true
//                     }
//                 });
//                 await group.appendAsync(producers);
//             }
//         });
//         await this.appendAsync(sponsorMargeGroup);

//         const publishers = await ElementExpander.fromAsync<TestSponsorElement, TestSponsor>({
//             name: "publishers",
//             label: "發行單位",
//             formElementCreationFunc: () => new TestSponsorElement(),
//             tableOptions: {
//                 columns: [{ head: "名稱", width: "200px" }, { head: "國家", width: "200px" }, { head: "統一編號", width: "200px" }]
//             }
//         });
//         await this.appendAsync(publishers);

//         const readonlyPublishers = await ElementExpander.fromAsync<TestSponsorElement, TestSponsor>({
//             name: "publishers",
//             label: "發行單位",
//             showExpandButtons: false,
//             formElementCreationFunc: () => {
//                 const elem = new TestSponsorElement();
//                 elem.readonly = true;
//                 return elem;
//             },
//             tableOptions: {
//                 columns: [{ head: "名稱", width: "200px" }, { head: "國家", width: "200px" }, { head: "統一編號", width: "200px" }]
//             }
//         });
//         await this.appendAsync(readonlyPublishers);

//         publishers.addChangeFunc(value => readonlyPublishers.setValueAsync(value));

//         const published = await RadioButtonElement.fromAsync({
//             name: "published",
//             label: "審議結論",
//             allowEmpty: true,
//             options: [{ text: "公開", value: "1" }, { text: "不公開", value: "0" }]
//         });
//         await this.appendAsync(published);

//         const readonlyPublished = await ReadonlyPickerElement.fromAsync({
//             name: "published",
//             label: "審議結論",
//             options: [{ text: "公開", value: "1" }, { text: "不公開", value: "0" }]
//         });
//         await this.appendAsync(readonlyPublished);

//         published.addChangeFunc(value => readonlyPublished.setValueAsync(value));
//         published.changeAsync();
        
//         const conclusion = await TextAreaElement.fromAsync({ name: "conclusion", label: "結論", required: true });
//         await this.appendAsync(conclusion);

//         const readonlyConclusion = await ReadonlyTextAreaElement.fromAsync({ name: "conclusion", label: "結論" });
//         await this.appendAsync(readonlyConclusion);

//         conclusion.addChangeFunc(value => readonlyConclusion.setValueAsync(value));

//         // const taxRelief = CheckboxElement.fromAsync({ name: "taxRelief", label: "娛樂稅減免", text: "娛樂稅減免", required: true });
//         // await this.appendAsync(taxRelief);

//         const filmClasses = await CheckboxGroupElement.fromAsync({
//             name: "filmClasses",
//             label: "電影類型",
//             childWidth: "200px",
//             multipleLine: true,
//             options: [
//                 { text: "影展", value: "影展" },
//                 { text: "預告", value: "預告" },
//                 { text: "喜劇", value: "喜劇" },
//                 { text: "戲劇", value: "戲劇" },
//                 { text: "動畫(卡通)", value: "動畫(卡通)" },
//                 { text: "倫理(家庭、親情)", value: "倫理(家庭、親情)" },
//                 { text: "愛情", value: "愛情" },
//                 { text: "勵志", value: "勵志" },
//                 { text: "教育", value: "教育" },
//                 { text: "宗教", value: "宗教" },
//                 { text: "歌舞(音樂)", value: "歌舞(音樂)" }
//             ]
//         });
//         await this.appendAsync(filmClasses);

//         const readonlyFilmClasses = await ReadonlyPickerElement.fromAsync({
//             name: "filmClasses",
//             label: "電影類型",
//             options: [
//                 { text: "影展", value: "影展" },
//                 { text: "預告", value: "預告" },
//                 { text: "喜劇", value: "喜劇" },
//                 { text: "戲劇", value: "戲劇" },
//                 { text: "動畫(卡通)", value: "動畫(卡通)" },
//                 { text: "倫理(家庭、親情)", value: "倫理(家庭、親情)" },
//                 { text: "愛情", value: "愛情" },
//                 { text: "勵志", value: "勵志" },
//                 { text: "教育", value: "教育" },
//                 { text: "宗教", value: "宗教" },
//                 { text: "歌舞(音樂)", value: "歌舞(音樂)" }
//             ]
//         });
//         await this.appendAsync(readonlyFilmClasses);

//         filmClasses.addChangeFunc(value => readonlyFilmClasses.setValueAsync(value));

//         // await this.appendAsync(IconElement.fromAsync({ label: "測試 Icon", type: "info", title: "Icon", text: "測試內文" }));

//         // await this.appendAsync(NoteElement.fromAsync({ label: "測試 Note", type: "info", text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum." }));

//         // await this.appendAsync(NoteElement.fromAsync({ label: "測試 Note 2", type: "info", inline: true, text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum." }));

//         // await this.appendAsync(TitleElement.fromAsync({ text: "測試標題" }));

//         // const examFacts = await ElementExpander.fromAsync<TestExamFactElement, TestMovieExamFact>({
//         //     name: "examFacts",
//         //     required: true,
//         //     formElementCreationFunc: () => new TestExamFactElement()
//         // });
//         // await this.appendAsync(examFacts);

//         const buttons = FormElementContainer.fromAsync({
//             buildChildrenFunc: async group => {
//                 await group.appendAsync(ButtonElement.fromAsync({ 
//                     text: "驗證", 
//                     type: "primary",
//                     onClick: () => {
//                         this.validateAsync();
//                     }
//                 }));
//             }
//         });
//         await this.appendAsync(buttons);

//         // setTimeout(() => {
//         //     const values = [];
//         //     for (let i = 0; i < 30; i++) {
//         //         values.push({ nameInput: `測試資料${i}` });
//         //     }
//         //     this.formExapnder.setValueAsync(values);
//         // }, 500);
//     }
// }

// class TestSponsorElement extends FormElementContainerGeneric<TestSponsor> {

//     nameInput: InputElement | ReadonlyInputElement;
//     countryInput: SelectElement | ReadonlyPickerElement;
//     uniformNumberInput: InputElement | ReadonlyInputElement;

//     readonly: boolean = false;

//     async buildChildrenAsync(): Promise<void> {
//         this.nameInput = await (!this.readonly ? InputElement : ReadonlyInputElement).fromAsync({ name: "name", required: true, hideReqiredIcon: true, autocomplete: false });
//         await this.appendAsync(this.nameInput);

//         this.countryInput = await (!this.readonly ? SelectElement : ReadonlyPickerElement).fromAsync({
//             name: "country",
//             allowEmpty: true,
//             options: [{ value: "-1", text: "請選擇" }, { value: "tw", text: "台灣" }]
//         });
//         await this.appendAsync(this.countryInput);

//         this.uniformNumberInput = await (!this.readonly ? InputElement : ReadonlyInputElement).fromAsync({ name: "uniformNumber", hideReqiredIcon: true, autocomplete: false });
//         await this.appendAsync(this.uniformNumberInput);

//         this.nameInput.addChangeFunc(() => this.changeAsync());
//         this.countryInput.addChangeFunc(() => this.changeAsync());
//         this.uniformNumberInput.addChangeFunc(() => this.changeAsync());
//     }

//     async getValueAsync(): Promise<TestSponsor> {
//         const country = await this.countryInput.getSingleValueAsync();
//         const uniformNumber = await this.uniformNumberInput.getValueAsync();
//         return {
//             name: await this.nameInput.getValueAsync(),
//             country: country && country !== "-1" ? country : undefined,
//             uniformNumber: uniformNumber ? uniformNumber : undefined
//         };
//     }

//     async setValueAsync(value: TestSponsor): Promise<void> {
//         await this.nameInput.setValueAsync(value.name);
//         await this.countryInput.setValueAsync(value.country);
//         await this.uniformNumberInput.setValueAsync(value.uniformNumber);
//     }
// }

// class TestExamFactElement extends FormElementContainerGeneric<TestMovieExamFact> {

//     multipleLine: boolean = true;

//     examinerInput: InputElement;
//     rateInput: SelectElement;
//     commentInput: TextAreaElement;

//     async buildChildrenAsync(): Promise<void> {
//         this.examinerInput = await InputElement.fromAsync({ 
//             name: "examiner", 
//             required: true, 
//             autocomplete: false,
//             hideReqiredIcon: true,
//             placeholder: "委員名稱"
//         });
//         await this.appendAsync(this.examinerInput);

//         this.rateInput = await SelectElement.fromAsync({
//             name: "rate",
//             required: true,
//             hideReqiredIcon: true,
//             options: [{ value: "-1", text: "請選擇" }]
//         });
//         await this.appendAsync(this.rateInput);

//         this.commentInput = await TextAreaElement.fromAsync({ 
//             name: "comment", 
//             width: "100%",
//             autocomplete: false,
//             hideReqiredIcon: true,
//             placeholder: "審查意見"
//         });
//         await this.appendAsync(this.commentInput);
//     }

//     async getValueAsync(): Promise<TestMovieExamFact> {
//         return {
//             examiner: await this.examinerInput.getValueAsync(),
//             rate: await this.rateInput.getSingleValueAsync(),
//             comment: await this.commentInput.getValueAsync()
//         };
//     }

//     async setValueAsync(value: TestMovieExamFact): Promise<void> {
//         await this.examinerInput.setValueAsync(value.examiner);
//         await this.rateInput.setValueAsync(value.rate);
//         await this.commentInput.setValueAsync(value.comment);
//     }
// }

// interface TestFormData {
//     issueDate: string;
//     certificationType: number;
//     certificationNumber: string;
//     certificationStart: string;
//     certificationEnd: string;
//     name: string;
//     originalName?: string;
//     countries: string[];
//     lang: string;
//     langOther?: string;
//     length: string;
//     media: string;
//     specification: string;
//     distributors: TestSponsor[];
//     publishers: TestSponsor[];
//     examType: string;
//     movieExams: TestMovieExam[];
//     published: boolean;
//     finalRate: string;
//     conclusion: string;
//     taxRelief: boolean;
//     taxReliefStart?: string;
//     taxReliefEnd?: string;
//     filmClasses: string[];
// }

// interface TestSponsor {
//     name: string;
//     country?: string;
//     uniformNumber?: string;
// }

// interface TestMovieExam {
//     examType: string;
//     date: string;
//     facts: TestMovieExamFact[];
// }

// interface TestMovieExamFact {
//     examiner: string;
//     rate: string;
//     comment: string;
// }

// class TestFormDialog extends FormDialog {
    
//     protected async _beforeBuildAsync(): Promise<void> {
//         this.formDialogOptions.forms.push(new TestForm());

//         this.formDialogOptions.title = "測試 FormDialog";
//         this.formDialogOptions.actionBarTitle = "測試 Title";

//         this.formDialogOptions.actionBarButtons.push({
//             name: "test",
//             text: "驗證",
//             className: "primary",
//             callback: async () => {
//                 await this.validateAsync();
//             }
//         });

//         this.formDialogOptions.actionBarButtons.push({
//             name: "close",
//             text: "關閉",
//             callback: () => this.closeAsync()
//         });
//     }
// }