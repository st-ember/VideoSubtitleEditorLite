import { fileOptionApiMap } from "contexts/FileOptionApiMap";
import CachedFile from "models/CachedFile";
import FileData from "models/FileData";
import UploadFileResult from "models/UploadFileResult";
import apiController, { Api } from "uform-api";
import dialogController from "uform-dialog";

export default class FileController {

    cachedFiles: { [elementId: string]: CachedFile[] } = {};

    uploadAsync(api: Api, files: File, onProgress?: (progress: number) => void): Promise<UploadFileResult>;
    uploadAsync(api: Api, files: File[], onProgress?: (progress: number) => void): Promise<UploadFileResult>;
    uploadAsync(api: Api, fileArg: File | File[], onProgress?: (progress: number) => void): Promise<UploadFileResult> {
        const files = fileArg instanceof Array ? fileArg : [fileArg];
        if (!files || files.length === 0) {
            return new Promise<UploadFileResult>(resolve => resolve({ success: false, message: "沒有檔案！", uploadedFiles: [] }));
        }

        const formData = new FormData();
        files.forEach(file => formData.append("file", file, file.name));

        return new Promise(resolve => {
            const request = new XMLHttpRequest();
            request.onreadystatechange = async () => {
                if (request.readyState === 4) {
                    try {
                        const response = JSON.parse(request.response);
                        if (response.success && response.data && response.data instanceof Array && response.data.length > 0) {
                            const uploadedFiles: FileData[] = [];
    
                            response.data.forEach((ticket: string, index: number) => {
                                if (ticket) {
                                    const file = files[index];
                                    uploadedFiles.push({ filename: file.name, ticket, size: file.size });
                                }
                            });
    
                            resolve({ success: true, uploadedFiles });
                        } else {
                            const message = `傳輸時發生錯誤：${response && response.message ? response.message : "要求失敗"}`;
                            resolve({ success: false, message, uploadedFiles: [] });
                        }
                    } catch (error) {
                        const message = `傳輸時發生錯誤：${error ? error : "傳輸失敗"}`;
                        resolve({ success: false, message, uploadedFiles: [] });
                    }
                }
            };

            request.upload.addEventListener("progress", (event: ProgressEvent<XMLHttpRequestEventTarget>) => {
                if (event.lengthComputable && onProgress) {
                    onProgress(event.loaded / event.total);
                }
            }, false);

            request.open(api.method, api.url);
            request.send(formData);
        });
    }

    download(api: Api, ticket: string, filename: string, deleteAfterDownload?: boolean): void {
        window.location.href = `${api.url}?ticket=${ticket}${filename ? `&filename=${encodeURIComponent(filename)}` : ""}${deleteAfterDownload ? `&deleteAfterDownload=True` : ""}`;
    }

    async deleteFileAsync(api: Api, ticket: string): Promise<void> {
        await apiController.queryAsync(api, { ticket });
    }

    /**
     * 產出文件
     * @param api 產出文件的 API
     * @param data 產出文件時需要的資料
     * @param filename 產出文件後，下載的檔名。
     */
    async generateFileAsync(api: Api, data: any, filename: string): Promise<void> {
        const loading = await dialogController.showLoadingAsync("產生中", "文件正在產生中，請稍後...");
        const response = await apiController.queryAsync(api, data);
        await dialogController.closeAsync(loading);
        if (response.success && response.data) {
            this.download(fileOptionApiMap.DownloadFromCache, response.data, filename, true);
        } else {
            await dialogController.showErrorAsync("錯誤", "嘗試建立文件時發生錯誤，訊息：" + response.message);
        }
    }

}

export const fileController = new FileController();
(<any>window).fileController = fileController;