import OptionItem from "models/OptionItem";
import apiController, { Api } from "uform-api";

export default class DataSourceController {

    apiMap: { [key: string]: Api } = {};
    optionMap: { [key: string]: OptionItem[] } = {};

    async getSelectOptionsAsync(api: Api, defaultOptionText?: string, force?: boolean): Promise<OptionItem[]>;
    async getSelectOptionsAsync(name: string, defaultOptionText?: string, force?: boolean): Promise<OptionItem[]>;
    async getSelectOptionsAsync(arg0: Api | string, defaultOptionText?: string, force?: boolean): Promise<OptionItem[]> {
        let key: string;
        let api: Api | undefined;
        if (!arg0) {
            return [];
        }

        if (typeof arg0 === "string") {
            key = `${arg0}${defaultOptionText ? `-${defaultOptionText}` : ""}`;
            api = this.apiMap ? { 
                url: this.apiMap.GetOptions.url.replace("{OptionName}", arg0), 
                method: this.apiMap.GetOptions.method
            } : undefined;
        } else {
            key = `${arg0.url}${defaultOptionText ? `-${defaultOptionText}` : ""}`;
            api = arg0;
        }

        if (!api || !api.url || !api.method) {
            return [];
        }

        if (!this.optionMap[key] || force) {
            const response = await apiController.queryAsync(api, { defaultOptionText: defaultOptionText ? defaultOptionText : "" });
            if (response.success) {
                this.optionMap[key] = response.data;
            }
        }

        const result = this.optionMap[key];
        return result && result instanceof Array ? result : [];
    }
}

export const dataSourceController = new DataSourceController();
(<any>window).dataSourceController = dataSourceController;