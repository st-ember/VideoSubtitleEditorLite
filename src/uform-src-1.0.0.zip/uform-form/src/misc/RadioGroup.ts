import RadioElement from "formElements/RadioElement";
import { Popover } from "uform-popover";

export default class RadioGroup {

    name: string;
    /** 元件預設的必要屬性。 */
    required?: boolean = false;
    /** 元件預設的停用屬性。 */
    disabled?: boolean = false;
    /** 元件預設的隱藏屬性。 */
    hide?: boolean = false;
    /** 當 Change 行為發生後，要執行的 Funcion 清單。 */
    onChangeFuncs: (((value?: any) => void) | ((value?: any) => Promise<void>))[] = [];
    /** 預設狀態是否為未選擇。預設為 False，元件完成建立後會自動選擇第一個項目。 */
    allowEmpty?: boolean = false;

    /** 此元件的值是否已經人工修改過。 */
    edited: boolean = false;

    radioElements: RadioElement[] = [];

    /** 是否已經驗證過或是已經包含初始預設值。如果是的話應該要在變更後直接再驗證一次並於驗證失敗時立刻顯示錯誤訊息。 */
    protected validated: boolean = false;
    protected applyingData: boolean = false;

    constructor(name: string) {
        this.name = name;
    }

    async deleteAsync(): Promise<void> {
        await Promise.all(this.radioElements.map(child => child.deleteAsync()));
    }

    async validateAsync(): Promise<boolean> {
        const valid = !this.needToCheckRequire() || !!(await this.getValueAsync());
        this.validated = true;
        await this.showInvalidEffectAsync(!valid, "您必須選擇一個項目！");

        return valid;
    }

    protected needToCheckRequire(): boolean {
        return this.required === true && !this.hide && !this.disabled;
    }

    protected applyToAllChildren(func: (child: RadioElement) => void): void {
        this.radioElements.forEach(child => func(child));
    }

    protected async applyToAllChildrenAsync(func: (child: RadioElement) => Promise<void>): Promise<void> {
        await Promise.all(this.radioElements.map(child => func(child)));
    }

    protected getFirstChild(): RadioElement | undefined {
        return this.radioElements.length > 0 ? this.radioElements[0] : undefined;
    }

    hideAsync(): Promise<void> {
        this.hide = true;
        return this.applyToAllChildrenAsync(child => child.hideAsync());
    }

    showAsync(): Promise<void> {
        this.hide = false;
        return this.applyToAllChildrenAsync(child => child.showAsync());
    }

    setDisableAsync(disable?: boolean): Promise<void> {
        this.disabled = disable !== false;
        return this.applyToAllChildrenAsync(child => child.setDisableAsync(disable));
    }

    /** 修改此元件的必填狀態。 */
    setRequiredAsync(required?: boolean): Promise<void> {
        this.required = required !== false;
        return this.applyToAllChildrenAsync(child => child.setRequiredAsync(required));
    }

    async clearAsync(): Promise<void> {
        const selectedItems = this.radioElements.filter(child => child.element.checked);
        this.applyingData = true;
        if (this.allowEmpty) {
            await Promise.all(selectedItems.map(child => {
                child.element.checked = false;
                return child.changeAsync();
            }));
        } else {
            await Promise.all(this.radioElements.map(async (child, index) => {
                const needChange = child.element.checked === true;
                child.element.checked = index === 0;
                
                if (needChange) {
                    await child.changeAsync();
                }
            }));
        }

        this.applyingData = false;
        await this.changeAsync();
    }

    async getValueAsync(): Promise<string | undefined> {
        const checkedChildren = this.radioElements.filter(child => child.element.checked);
        return checkedChildren.length > 0 ? checkedChildren[0].value : undefined;
    }

    async setValueAsync(value: string | number): Promise<void> {
        const adoptedValue = typeof value === "string" ? (!!value ? value : "") : (value !== undefined ? String(value) : "");
        const matchs = this.radioElements.filter(child => child.value === adoptedValue);
        if (matchs.length > 0) {
            this.applyingData = true;
            await Promise.all(this.radioElements.map(async child => {
                const isMatch = child.value === adoptedValue;
                const needChange = child.element.checked !== isMatch;
                child.element.checked = isMatch;
                if (needChange) {
                    await child.changeAsync();
                }
            }));
            this.applyingData = false;
            await this.changeAsync();
        } else {
            await this.clearAsync();
        }
    }

    /** 觸發此元件的 change 事件，會導致必填元件進行驗證，並執行 change 後對應的 Function 清單。*/
    async changeAsync(): Promise<void> {
        this.edited = true;
        if (this.validated) {
            await this.validateAsync();
        }

        const value = await this.getValueAsync();
        await Promise.all(this.onChangeFuncs.map(func => {
            const result = func(value);
            return result && "then" in result ? result : new Promise<void>(resolve => resolve());
        }));
    }

    /**
     * 於元件上彈出一段訊息。
     * @param html 訊息內容，HTML 格式。
     * @returns 彈出所用的 Popover 物件。
     */
    async showMessageAsync(html: string): Promise<Popover | undefined> {
        const first = this.getFirstChild();
        if (first) {
            return await first.showMessageAsync(html);
        }
    }

    /** 移除原件上彈出的 Popover。 */
    async removeMessageAsync(): Promise<void> {
        const first = this.getFirstChild();
        if (first) {
            await first.removeMessageAsync();
        }
    }

    /**
     * 於元件上彈出一段警告訊息。
     * @param text 訊息內容，HTML 格式。
     * @returns 彈出所用的 Popover 物件。
     */
    async showWarningAsync(text: string): Promise<Popover | undefined> {
        const first = this.getFirstChild();
        if (first) {
            return await first.showWarningAsync(text);
        }
    }

    /**
     * 於元件上彈出一段錯誤訊息。
     * @param text 訊息內容，HTML 格式。
     * @returns 彈出所用的 Popover 物件。
     */
     async showErrorAsync(text: string): Promise<Popover | undefined> {
        const first = this.getFirstChild();
        if (first) {
            return await first.showErrorAsync(text);
        }
    }

    /** 將元件設定為 highlight 模式，會在 container 上顯示黃色的背景。 */
    async showHighlightEffectAsync(show?: boolean): Promise<void> {
        const first = this.getFirstChild();
        if (first) {
            return await first.showHighlightEffectAsync(show);
        }
    }

    /**
     * 將元件設定為警告模式，會在元件輸入框上顯示黃色框線，並彈出警告訊息。
     * @param show 是否啟動警告模式。
     * @param message 要顯示的警告訊息。
     */
    async showWarningEffectAsync(show?: boolean, message?: string): Promise<void> {
        const first = this.getFirstChild();
        if (first) {
            return await first.showWarningEffectAsync(show, message);
        }
    }

    /**
     * 將元件設定為驗證失敗模式，會在元件輸入框上顯示黃色框線，並彈出驗證失敗訊息。
     * @param show 是否啟動驗證失敗模式。
     * @param message 要顯示的驗證失敗訊息。
     */
    async showInvalidEffectAsync(show?: boolean, message?: string): Promise<void> {
        const first = this.getFirstChild();
        if (first) {
            return await first.showInvalidEffectAsync(show, message);
        }
    }

    addChangeFunc(func: ((value?: any) => void) | ((value?: any) => Promise<void>)): void {
        if (!this.onChangeFuncs) {
            this.onChangeFuncs = [];
        }

        this.onChangeFuncs.push(func);
    }

    addRadioElement(radioElement: RadioElement): void {
        if (!radioElement.value) {
            throw new Error("嘗試加入無效 value (undefined, null 或空字串) 的 RadioElement");
        }

        const duplicateds = this.radioElements.filter(o => o.value === radioElement.value);
        if (duplicateds.length === 0) {
            this.radioElements.push(radioElement);
        } else {
            throw new Error(`嘗試加入重複 value (${radioElement.value}) 的 RadioElement`);
        }
    }
}