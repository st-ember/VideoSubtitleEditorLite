import FormElementGeneric from "baseElements/FormElementGeneric";
import NumberElementOptions from "options/NumberElementOptions";

export default class NumberElement extends FormElementGeneric<number | undefined> implements NumberElementOptions {

    type: string = "number";
    max?: number;
    min?: number;
    step?: number;
    placeholder?: string;
    value?: number;

    element: HTMLInputElement = document.createElement("input");
    
    constructor(options?: NumberElementOptions) {
        super(options);
        this.bindOptions(options);
    }

    static fromAsync(options: NumberElementOptions): Promise<NumberElement> {
        return <Promise<NumberElement>>(new NumberElement(options).buildAsync());
    }

    protected async buildElementAsync(): Promise<void> {
        if (this.name) {
            this.element.name = this.name;
        }
        
        this.element.id = this.id;
        this.element.type = !!this.type ? this.type : "number";
        this.element.max = this.max !== undefined ? String(this.max) : "";
        this.element.min = this.min !== undefined ? String(this.min) : "";
        this.element.step = this.step !== undefined ? String(this.step) : "";
        this.element.placeholder = this.placeholder ? this.placeholder : "";
        this.element.autocomplete = "off";
        this.element.className = "form-theme-input form-theme-color form-theme-placeholder";

        if (this.title) {
            this.element.title = this.title;
        }

        if (this.value !== undefined && this.value !== null && !isNaN(this.value)) {
            this.element.value = String(this.value);
        }
        
        this.element.addEventListener("change", () => this.changeAsync());
        this.container.appendChild(this.element);

        this.messageAnchor = this.element;
    }

    rebuildAsync(): Promise<void> {
        this.element.type = !!this.type ? this.type : "number";
        this.element.max = this.max !== undefined ? String(this.max) : "";
        this.element.min = this.min !== undefined ? String(this.min) : "";
        this.element.step = this.step !== undefined ? String(this.step) : "";
        this.element.placeholder = this.placeholder ? this.placeholder : "";
        this.element.autocomplete = "off" ;

        if (this.title) {
            this.element.title = this.title;
        }

        return this.clearAsync();
    }

    async deleteAsync(): Promise<void> {
        await this.removeMessageAsync();
        this.container.remove();
    }

    async setDisableAsync(disable?: boolean): Promise<void> {
        this.disabled = disable !== false;
        this.element.disabled = this.disabled;
    }

    async clearAsync(): Promise<void> {
        if (this.value !== undefined && this.value !== null && !isNaN(this.value)) {
            this.element.value = String(this.value);
        } else {
            this.element.value = "";
        }
    }

    async getValueAsync(): Promise<number | undefined> {
        const value = Number(this.element.value);
        return this.element.value !== "" && !isNaN(value) ? value : undefined;
    }

    async setValueAsync(value: string | number | undefined): Promise<void> {
        this.element.value = typeof value === "string" ? (!!value ? value : "") : (value !== undefined && value !== null ? String(value) : "");
        await this.changeAsync();
    }
}