import FormElementGeneric from "baseElements/FormElementGeneric";
import { fileOptionApiMap } from "contexts/FileOptionApiMap";
import { formFontawesomeIcons } from "contexts/FormIcons";
import { fileController } from "controllers/FileController";
import FileData from "models/FileData";
import FileElementOptions from "options/FileElementOptions";
import { Api } from "uform-api";
import dialogController from "uform-dialog";
import popoverController, { Popover } from "uform-popover";

export default class FileElement extends FormElementGeneric<FileData[]> implements FileElementOptions {

    showFilename?: boolean = true;
    emptyMessage: string = "選擇檔案並上傳";
    uploadButtonText: string = "上傳檔案";
    uploadedText?: string = "(已上傳)";
    multiple?: boolean = false;
    /** 是否開啟唯讀模式。 */
    readonly?: boolean = false;
    /** 允許的副檔名。 */
    acceptedExtensions?: string[];
    /** 允許的最大檔案大小。 */
    maxUploadFileSize?: number;
    /** 下載檔案所使用的 API 設定 */
    downloadApi?: Api = fileOptionApiMap.Download;
    /** 上傳檔案所使用的 API 設定 */
    uploadApi?: Api = fileOptionApiMap.Upload;
    /** 刪除檔案所使用的 API 設定 */
    deleteApi?: Api = fileOptionApiMap.Delete;
    /** 是否允許刪除已經上傳的檔案 */
    deletable?: boolean = true;
    /** 是否允許下載已經上傳的檔案 */
    downloadable?: boolean = true;
    /** 是否在元件被刪除時自動刪除所有檔案 */
    autoDelete?: boolean = false;
    /** 是否在選擇檔案後立刻上傳 */
    autoUpload?: boolean = true;
    /** 當開始上傳時，一旦進度變更將會呼叫的方法。 */
    onProgress?: (progress: number) => void = undefined;
    /** 碰到沒有 Ticket 的檔案時是否顯示錯誤，預設為否。 */
    ignoreEmptyTicketError?: boolean;

    files: FileData[] = [];
    rawFiles: File[] = [];

    element: HTMLInputElement = undefined!;
    fileContainer: HTMLDivElement = undefined!;
    filenameGroup: HTMLDivElement = undefined!;
    extensionIconAnchor: HTMLDivElement = undefined!;
    uploadButton: HTMLLabelElement = undefined!;
    extensionPopover?: Popover;

    private _fileItems?: { item: HTMLSpanElement, deleteButton?: HTMLButtonElement, downloadButton?: HTMLButtonElement }[];
    
    constructor(options?: FileElementOptions) {
        super(options);
        this.bindOptions(options);
    }

    static fromAsync(options: FileElementOptions): Promise<FileElement> {
        return <Promise<FileElement>>(new FileElement(options).buildAsync());
    }

    protected async buildElementAsync(): Promise<void> {
        if (this.readonly) {
            this.container.classList.add("readonly");
        }

        this.fileContainer = document.createElement("div");
        this.fileContainer.className = "file-container form-theme-input";
        this.container.appendChild(this.fileContainer);

        await this.buildFileInputAsync();
        this.buildExtendsionIconAnchor();
        this.buildUploadButton();
        this.buildFilenameGroup();
        this.updateUploadButton(this.uploadButtonText, this.disabled === true);
    }

    protected async buildFileInputAsync(): Promise<void> {
        const input = document.createElement("input");
        input.type = "file";

        if (this.acceptedExtensions && this.acceptedExtensions.length > 0) {
            input.accept = this.acceptedExtensions.map(item => "." + item).join(", ");
        }

        if (this.multiple) {
            input.multiple = true;
        }

        if (!this.readonly) {
            input.id = this.id;

            if (this.name) {
                input.name = this.name;
            }
            
            input.addEventListener("change", event => this.onFileChangeAsync(event));
        }

        if (this.element) {
            this.element.remove();
        }

        this.element = input;
        this.element.disabled = this.disabled === true;
        this.fileContainer.appendChild(this.element);
    }

    protected buildExtendsionIconAnchor(): void {
        this.extensionIconAnchor = document.createElement("div");
        this.extensionIconAnchor.className = "form-icon info";

        if (this.acceptedExtensions && this.acceptedExtensions.length > 0) {
            const iconElement = document.createElement("i");
            iconElement.className = formFontawesomeIcons["info"];
            this.extensionIconAnchor.appendChild(iconElement);

            popoverController.buildAsync({
                target: this.extensionIconAnchor,
                content: `允許的副檔名：${this.acceptedExtensions.join("、")}`,
                onlyTriggerByClick: false
            }).then(popovers => {
                this.extensionPopover = popovers[0];
            });
        } else {
            this.extensionIconAnchor.classList.add("hide");
        }
    }

    protected buildUploadButton(): void {
        const uploadButton = document.createElement("label");
        uploadButton.className = "button primary small-button upload-button";
        uploadButton.setAttribute("for", this.id);
        this.uploadButton = uploadButton;

        if (!this.readonly) {
            uploadButton.setAttribute("for", this.id);
        }
    }

    protected buildFilenameGroup(): void {
        const filenameGroup = document.createElement("div");
        filenameGroup.className = "filename-group form-theme-color";
        this.fileContainer.appendChild(filenameGroup);
        this.filenameGroup = filenameGroup;
        this.messageAnchor = this.filenameGroup;

        if (!this.showFilename) {
            this.filenameGroup.classList.add("hide");
        }

        if (this.files.length > 0) {
            filenameGroup.classList.remove("empty");
            filenameGroup.innerHTML = "";

            const fileItems = document.createElement("div");
            fileItems.className = "file-items";
            filenameGroup.appendChild(fileItems);

            this._fileItems = this.files.map((file, index) => {
                const filename = file.filename && (file.ticket || this.ignoreEmptyTicketError) ? file.filename : "檔案錯誤";
                const item = document.createElement("span");
                item.className = `file-item ${!file.filename || !(file.ticket || this.ignoreEmptyTicketError) ? " file-error" : "form-theme-color-light"}`;
                item.title = filename;
                item.innerHTML = `<i class=\"fa-regular fa-file-lines\"></i><span class=\"filename-text\">${filename}</span>`;

                let downloadButton: HTMLButtonElement | undefined;
                if (this.downloadable && file.ticket) {
                    downloadButton = document.createElement("button");
                    downloadButton.type = "button";
                    downloadButton.title = "下載檔案";
                    downloadButton.className = "mini-button default";
                    downloadButton.innerHTML = "<i class=\"fa fa-arrow-down\"></i>";
                    downloadButton.addEventListener("click", () => fileController.download(this.downloadApi ? this.downloadApi : fileOptionApiMap.Download, file.ticket, file.filename));
                    item.appendChild(downloadButton);
                }

                let deleteButton: HTMLButtonElement | undefined;
                if (this.deletable && !this.readonly) {
                    deleteButton = document.createElement("button");
                    deleteButton.type = "button";
                    deleteButton.title = "刪除這個檔案";
                    deleteButton.className = "mini-button warning";
                    deleteButton.innerHTML = "<i class=\"fa fa-times\"></i>";
                    deleteButton.disabled = this.disabled === true;
                    deleteButton.addEventListener("click", async () => {
                        if (await dialogController.confirmWarningAsync("確認", `您確定要刪除文件「${file.filename}」嗎？`)) {
                            this.deleteFileByIndex(index);
                        }
                    });
                    item.appendChild(deleteButton);
                }

                fileItems.appendChild(item);

                return { item, deleteButton, downloadButton };
            });

        } else {
            filenameGroup.classList.add("empty");
            filenameGroup.innerHTML = !this.readonly ? `<label class="empty-message" for=\"${this.id}\">${this.emptyMessage}</label>` : `<label>無檔案</label>`;
        }

        filenameGroup.appendChild(this.extensionIconAnchor);
        filenameGroup.appendChild(this.uploadButton);
    }

    protected updateUploadButton(text: string, disabled: boolean, uploading: boolean = false): void {
        const buttonText = (text ? text : this.uploadButtonText) + (this.files.length > 0 ? (this.uploadedText ? this.uploadedText : "") : "");
        this.uploadButton.title = !uploading ? (this.files.length > 0 ? "已上傳，點選以重新上傳。" : this.emptyMessage) : "上傳中";
        this.uploadButton.innerHTML = (!uploading ? "<i class=\"fa fa-upload\"></i>" : "<i class=\"fa fa-cop fa-spin\"></i>") + buttonText;

        if (disabled) {
            this.uploadButton.classList.add("disabled");
            this.filenameGroup.classList.add("disabled");
        } else {
            this.uploadButton.classList.remove("disabled");
            this.filenameGroup.classList.remove("disabled");
        }

        if (!disabled && !this.readonly) {
            this.uploadButton.setAttribute("for", this.id);
        } else {
            this.uploadButton.removeAttribute("for");
        }
    }

    async rebuildAsync(): Promise<void> {
        if (this.extensionPopover) {
            await popoverController.removeAsync(this.extensionPopover.id);
        }

        this.filenameGroup.remove();
        this.uploadButton.remove();
        this.extensionIconAnchor.remove();
        await this.buildFileInputAsync();
        this.buildExtendsionIconAnchor();
        this.buildUploadButton();
        this.buildFilenameGroup();
        this.updateUploadButton(this.uploadButtonText, this.disabled === true);
    }

    async deleteAsync(): Promise<void> {
        await this.removeMessageAsync();
        this.container.remove();

        if (this.autoDelete && this.files.length > 0) {
            const deleteApi = this.deleteApi ? this.deleteApi : fileOptionApiMap.Delete;
            await Promise.all(this.files.map(file => fileController.deleteFileAsync(deleteApi, file.ticket)));
        }
    }

    async validateAsync(): Promise<boolean> {
        this.validated = true;
        const valid = !this.needToCheckRequire() || this.readonly || this.files.length > 0;
        await this.showInvalidEffectAsync(!valid, "您必須至少上傳一筆檔案！");
        return valid;
    }

    async setDisableAsync(disable?: boolean): Promise<void> {
        this.disabled = disable !== false;
        this.element.disabled = this.disabled;
        if (this.disabled) {
            this.uploadButton.classList.add("disabled");
            this.filenameGroup.classList.add("disabled");
        } else {
            this.uploadButton.classList.remove("disabled");
            this.filenameGroup.classList.remove("disabled");
        }

        if (this._fileItems) {
            this._fileItems.filter(o => !!o.deleteButton).forEach(o => o.deleteButton!.disabled = this.disabled === true);
        }
    }

    async clearAsync(): Promise<void> {
        this.files = [];
        await this.rebuildAsync();
    }

    hasValue(): boolean {
        return this.files && this.files.length > 0;
    }

    async getValueAsync(): Promise<FileData[]> {
        return this.files;
    }

    async getSingleValueAsync(): Promise<FileData | undefined> {
        return this.files.length > 0 ? this.files[0] : undefined;
    }

    async setValueAsync(value: FileData[]): Promise<void> {
        if (value && value instanceof Array) {
            this.files = value.filter(file => !!file);
        } else {
            this.files = [];
        }

        await this.rebuildAsync();
        await this.changeAsync();
    }

    async setSingleValueAsync(value: FileData): Promise<void> {
        this.files = value ? [value] : [];
        await this.rebuildAsync();
    }

    async deleteFileByIndex(index: number): Promise<void> {
        if (!this.files || this.files.length <= index) {
            return;
        }

        if (this.rawFiles.length === this.files.length) {
            this.rawFiles.splice(index, 1);
        }

        this.files.splice(index, 1);

        await this.rebuildAsync();
        await this.changeAsync();
    }

    async onFileChangeAsync(event: Event): Promise<void> {
        if (!(<any>event.target).files || (<any>event.target).files.length === 0) { return; }
        if (this.disabled || this.readonly) {
            await this.rebuildAsync();
            return;
        }

        this.updateUploadButton("檢查中..", true);
        const files: File[] = [];
        for (let i = 0; i < (this.multiple ? (<any>event.target).files.length : 1); i++) {
            files.push((<any>event.target).files[i]);
        }

        if (this.acceptedExtensions && this.acceptedExtensions.length > 0) {
            const extensions = files.map(file => {
                const splitteds = file.name.split(".");
                return splitteds.length > 1 ? splitteds[splitteds.length - 1] : "";
            });

            const invalidExtensions = extensions.filter(ext => 
                !ext || this.acceptedExtensions && this.acceptedExtensions.filter(accepted => ext.toLowerCase() === accepted).length === 0
            );

            if (invalidExtensions.length > 0) {
                await this.showInvalidEffectAsync(true, "選擇的檔案包含錯誤的附檔名！");
                await this.clearAsync();
                await this.rebuildAsync();
                return;
            }
        }

        this.rawFiles = files;
        
        if (this.autoUpload) {
            await this.uploadAsync(files);
        } else {
            const pendingFiles = files.map(file => {
                return {
                    filename: file.name,
                    ticket: "",
                    size: file.size
                };
            });

            this.updateUploadButton(this.uploadButtonText, <any>this.disabled === true, false);
            await this.setValueAsync(pendingFiles);
            await this.changeAsync();
        }
    }

    async uploadAsync(files: File[]): Promise<boolean> {
        if (!files || files.length === 0) {
            await this.clearAsync();
            await this.rebuildAsync();
            return false;
        }

        this.updateUploadButton("上傳中..", true);

        const uploadResult = await fileController.uploadAsync(this.uploadApi ? this.uploadApi : fileOptionApiMap.Upload, files, 
            progress => {
                if (this.onProgress) {
                    this.onProgress(progress);
                }
                
                this.updateUploadButton(`上傳中 (${Math.ceil(progress * 100)}%)`, true, true);
            });
        
        if (uploadResult.success) {
            await this.setValueAsync(uploadResult.uploadedFiles);
            await this.changeAsync();
            return true;
        } else {
            await this.clearAsync();
            await this.showErrorAsync("檔案上傳失敗！");
            await this.changeAsync();
            return false;
        }
    }
}