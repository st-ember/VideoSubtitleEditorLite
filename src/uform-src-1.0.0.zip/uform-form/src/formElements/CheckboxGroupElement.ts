import PickerElementGeneric from "baseElements/PickerElementGeneric";
import OptionItem from "models/OptionItem";
import CheckboxGroupElementOptions from "options/CheckboxGroupElementOptions";

export default class CheckboxGroupElement extends PickerElementGeneric<(string | undefined)[]> implements CheckboxGroupElementOptions {

    childWidth?: number | string;
    multipleLine?: boolean;

    checkboxOptionElements: { value?: string; group: HTMLDivElement, element: HTMLInputElement; label: HTMLLabelElement; }[] = [];

    constructor(options?: CheckboxGroupElementOptions) {
        super(options);
        this.bindOptions(options);
    }

    static fromAsync(options: CheckboxGroupElementOptions): Promise<CheckboxGroupElement> {
        return <Promise<CheckboxGroupElement>>(new CheckboxGroupElement(options).buildAsync());
    }

    protected async buildElementAsync(): Promise<void> {
        this.element = document.createElement("div");
        this.element.className = "form-element-container";
        this.container.appendChild(this.element);

        if (this.multipleLine) {
            this.element.classList.add("multiple-lines");
        } else {
            this.element.classList.remove("multiple-lines");
        }

        await this.getOptionsAsync();
        this.options.forEach(option => this.buildOption(option));
    }

    protected buildOption(option: OptionItem): void {
        const checkboxElementGroup = document.createElement("div");
        checkboxElementGroup.className = "checkbox-element-group";
        this.element.appendChild(checkboxElementGroup);

        if (this.childWidth) {
            checkboxElementGroup.style.width = typeof this.childWidth === "number" ? `${this.childWidth}px` : this.childWidth;
        }

        const element = document.createElement("input");
        element.type = "checkbox";
        element.name = this.name + "-" + option.value;
        element.id = this.id + "-" + option.value;
        element.addEventListener("change", () => this.changeAsync());
        checkboxElementGroup.appendChild(element);

        const label = document.createElement("label");
        label.innerText = option.text ?? "";
        label.setAttribute("for", element.id);
        checkboxElementGroup.appendChild(label);

        this.checkboxOptionElements.push({
            value: option.value,
            group: checkboxElementGroup,
            element: element,
            label: label
        });
    }

    async rebuildAsync(): Promise<void> {
        this.checkboxOptionElements.forEach(o => {
            o.group.remove();
            o.element.remove();
            o.label.remove();
        });

        this.checkboxOptionElements = [];

        await this.getOptionsAsync();
        this.options.forEach(option => this.buildOption(option));

        await this.clearAsync();
    }

    async deleteAsync(): Promise<void> {
        await this.removeMessageAsync();
        this.container.remove();
    }

    async validateAsync(): Promise<boolean> {
        this.validated = true;
        const valid = !this.needToCheckRequire() || this.checkboxOptionElements.filter(o => o.element.checked).length > 0;
        await this.showInvalidEffectAsync(!valid, "您必須至少勾選一個項目！");
        return valid;
    }

    async setDisableAsync(disable?: boolean): Promise<void> {
        this.disabled = disable !== false;
        this.checkboxOptionElements.forEach(o => o.element.disabled = this.disabled === true);
    }

    async clearAsync(): Promise<void> {
        if (this.options && this.options.length > 0) {
            await this.setValueAsync([]);
        }
    }

    async getValueAsync(): Promise<(string | undefined)[]> {
        return this.checkboxOptionElements.length > 0 ?
            this.checkboxOptionElements
                .filter(o => o.element.checked)
                .map(o => o.value) : [];
    }

    async getNumberValueAsync(): Promise<number[]> {
        const value = await this.getValueAsync();
        return value.map(o => Number(o)).filter(o => !isNaN(o));
    }

    async setValueAsync(value: (string | undefined)[]): Promise<void>;
    async setValueAsync(value: (number | undefined)[]): Promise<void>;
    async setValueAsync(value: any[]): Promise<void> {
        const newValue = value.map((valueItem: number | string | undefined) => valueItem !== undefined ? String(valueItem) : undefined);
        this.checkboxOptionElements.forEach(o => o.element.checked = newValue.filter(v => v === o.value).length > 0);
        await this.changeAsync();
    }
}