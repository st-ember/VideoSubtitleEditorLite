import StaticFormElement from "baseElements/StaticFormElement";
import TitleElementOptions from "options/TitleElementOptions";

export default class TitleElement extends StaticFormElement implements TitleElementOptions {

    element: HTMLDivElement = document.createElement("div");
    text: string = "";

    constructor(options?: TitleElementOptions) {
        super(options);
        this.bindOptions(options);
    }

    static fromAsync(text: string): Promise<TitleElement>;
    static fromAsync(options: TitleElementOptions): Promise<TitleElement>;
    static fromAsync(arg: TitleElementOptions | string): Promise<TitleElement> {
        return <Promise<TitleElement>>(new TitleElement(typeof arg === "string" ? { text: arg } : arg).buildAsync());
    }

    protected async buildElementAsync(): Promise<void> {
        this.element.className = "form-title form-theme-title form-theme-color-light";
        this.element.innerHTML = this.text ? this.text : "";
        if (this.title) {
            this.element.title = this.title;
        }
        this.container.appendChild(this.element);
    }

    rebuildAsync(): Promise<void> {
        this.element.innerHTML = this.text ? this.text : "";
        if (this.title) {
            this.element.title = this.title;
        }
        return this.clearAsync();
    }
}