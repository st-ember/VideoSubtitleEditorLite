import StaticFormElement from "baseElements/StaticFormElement";
import ButtonElementOptions from "options/ButtonElementOptions";

export default class ButtonElement extends StaticFormElement implements ButtonElementOptions {

    element: HTMLButtonElement = document.createElement("button");

    icon?: string;
    text?: string = "";
    type?: "default" | "primary" | "success" | "warning" | "danger" | "dark";
    small: boolean = false;
    onClick?: () => void;

    options: ButtonElementOptions = undefined!;

    constructor(options?: ButtonElementOptions) {
        super(options);
        this.bindOptions(options);
    }

    static fromAsync(options: ButtonElementOptions): Promise<ButtonElement> {
        return <Promise<ButtonElement>>(new ButtonElement(options).buildAsync());
    }

    protected async buildElementAsync(): Promise<void> {
        this.element.type = "button";
        this.container.appendChild(this.element);
        this.element.addEventListener("click", () => {
            if (this.onClick) {
                this.onClick();
            }
        });

        if (this.title) {
            this.element.title = this.title;
        }

        await this.updateElementAsync();
    }

    async rebuildAsync(): Promise<void> {
        await this.updateElementAsync();
        await this.clearAsync();
    }

    protected async updateElementAsync(): Promise<void> {
        this.element.className = `${this.type ? this.type : ""}${this.small ? " small-button" : ""}`;
        this.element.innerHTML = this.icon ? `${this.icon ? `<i class=\"${this.icon}\"></i>` : ""}<span>${this.text}</span>` : `<span>${this.text}</span>`;

        if (this.title) {
            this.element.title = this.title;
        }
    }

    async setDisableAsync(disable?: boolean): Promise<void> {
        this.disabled = disable !== false;
        this.element.disabled = this.disabled;
    }
}