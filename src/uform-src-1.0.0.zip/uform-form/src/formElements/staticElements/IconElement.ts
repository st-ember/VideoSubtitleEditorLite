import StaticFormElement from "baseElements/StaticFormElement";
import { formFontawesomeIcons } from "contexts/FormIcons";
import IconElementOptions from "options/IconElementOptions";
import popoverController from "uform-popover";

export default class IconElement extends StaticFormElement implements IconElementOptions {

    element: HTMLSpanElement = document.createElement("span");
    iconElement?: HTMLElement;

    title?: string;
    text?: string;
    type?: "info" | "success" | "warning" | "danger" = "info";

    constructor(options?: IconElementOptions) {
        super(options);
        this.bindOptions(options);
    }

    static fromAsync(options: IconElementOptions): Promise<IconElement> {
        return <Promise<IconElement>>(new IconElement(options).buildAsync());
    }

    protected async buildElementAsync(): Promise<void> {
        this.element = document.createElement("span");
        this.element.className = `form-icon form-theme-color-light ${this.type}`;
        this.container.appendChild(this.element);

        await this.updateElementAsync();
    }

    async rebuildAsync(): Promise<void> {
        await this.updateElementAsync();
        await this.clearAsync();
    }

    protected async updateElementAsync(): Promise<void> {
        if (this.iconElement) {
            await popoverController.removeAsync(this.iconElement);
            this.iconElement.remove();
        }

        this.iconElement = document.createElement("i");
        this.iconElement.className = formFontawesomeIcons[this.type ? this.type : "info"];
        this.element.appendChild(this.iconElement);

        this.popover = (await popoverController.buildAsync({
            target: this.iconElement,
            title: this.title,
            content: this.text,
            onlyTriggerByClick: false
        }))[0];
    }
}