import { formFontawesomeIcons } from "contexts/FormIcons";
import NoteElementOptions from "options/NoteElementOptions";
import TextElement from "./TextElement";

export default class NoteElement extends TextElement implements NoteElementOptions {

    element: HTMLSpanElement = document.createElement("span");
    protected iconElement: HTMLSpanElement = document.createElement("span");
    protected textElement: HTMLSpanElement = document.createElement("span");

    type: "info" | "success" | "warning" | "danger" = "info";
    inline: boolean = false;

    constructor(options?: NoteElementOptions) {
        super(options);
        this.bindOptions(options);
    }

    static fromAsync(options: NoteElementOptions): Promise<NoteElement> {
        return <Promise<NoteElement>>(new NoteElement(options).buildAsync());
    }

    protected async buildElementAsync(): Promise<void> {
        this.element = document.createElement("span");
        this.element.className = "form-note form-theme-color-light";
        this.container.appendChild(this.element);

        this.iconElement = document.createElement("span");
        this.iconElement.className = "form-icon form-note-icon";
        this.element.appendChild(this.iconElement);

        this.textElement = document.createElement("span");
        this.textElement.className = "form-note-text";
        this.element.appendChild(this.textElement);

        if (this.title) {
            this.element.title = this.title;
        }

        this.updateElement();
    }

    protected updateElement(): void {
        if (this.multipleLines) {
            this.element.classList.add("multiple-lines");
        } else {
            this.element.classList.remove("multiple-lines");
        }

        if (this.title) {
            this.element.title = this.title;
        }

        const type = this.type ? this.type : "info";
        this.element.className = `form-note ${type}${this.inline ? " inline" : ""} form-theme-color`;

        this.iconElement.innerHTML = `<i class=\"${formFontawesomeIcons[type]}\"></i>`;
        this.iconElement.className = `form-icon form-note-icon ${type}`;

        this.textElement.innerHTML = this.text ?? "";
    }
}