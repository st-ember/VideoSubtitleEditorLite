import StaticFormElement from "baseElements/StaticFormElement";
import LinkElementOptions from "options/LinkElementOptions";

export default class LinkElement extends StaticFormElement implements LinkElementOptions {

    element: HTMLAnchorElement = document.createElement("a");

    icon?: string;
    text?: string = "";
    href?: string = "";
    onClick?: () => void;

    options: LinkElementOptions = undefined!;

    constructor(options?: LinkElementOptions) {
        super(options);
        this.bindOptions(options);
    }

    static fromAsync(options: LinkElementOptions): Promise<LinkElement> {
        return <Promise<LinkElement>>(new LinkElement(options).buildAsync());
    }

    protected async buildElementAsync(): Promise<void> {
        this.element.className = "form-anchor form-theme-color-link";
        this.container.appendChild(this.element);

        if (this.title) {
            this.element.title = this.title;
        }

        this.element.addEventListener("click", () => {
            if (this.onClick) {
                this.onClick();
            }
        });

        await this.updateElementAsync();
    }

    async rebuildAsync(): Promise<void> {
        await this.updateElementAsync();
        await this.clearAsync();
    }

    protected async updateElementAsync(): Promise<void> {
        this.element.href = this.href ?? "";
        this.element.innerHTML = this.icon ? `${this.icon ? `<i class=\"${this.icon}\"></i>` : ""}<span>${this.text}</span>` : `<span>${this.text}</span>`;
        if (this.title) {
            this.element.title = this.title;
        }
    }

    async setDisableAsync(disable?: boolean): Promise<void> {
        this.disabled = disable !== false;
        if (this.disabled) {
            this.element.classList.add("disabled");
        } else {
            this.element.classList.remove("disabled");
        }
    }
}