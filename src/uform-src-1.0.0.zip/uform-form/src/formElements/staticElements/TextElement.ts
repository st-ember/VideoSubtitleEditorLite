import StaticFormElement from "baseElements/StaticFormElement";
import TextElementOptions from "options/TextElementOptions";

export default class TextElement extends StaticFormElement implements TextElementOptions {

    element: HTMLSpanElement = document.createElement("span");

    text?: string;
    multipleLines?: boolean;
    color?: string;
    fontWeight?: string;
    fontSize?: string;
    textAlign?: string;

    constructor(options?: TextElementOptions) {
        super(options);
        this.bindOptions(options);
    }

    static fromAsync(options: TextElementOptions): Promise<TextElement> {
        return <Promise<TextElement>>(new TextElement(options).buildAsync());
    }

    protected async buildElementAsync(): Promise<void> {
        this.element.className = "form-text form-theme-color";
        this.container.appendChild(this.element);

        if (this.title) {
            this.element.title = this.title;
        }

        this.updateElement();
    }

    rebuildAsync(): Promise<void> {
        this.updateElement();
        return this.clearAsync();
    }

    async setValueAsync(value: string | number | undefined): Promise<void> {
        this.text = typeof value === "string" ? value : (typeof value === "number" ? String(value) : "");
        await this.rebuildAsync();
    }

    protected updateElement(): void {
        if (this.multipleLines) {
            this.element.classList.add("multiple-lines");
        } else {
            this.element.classList.remove("multiple-lines");
        }

        this.element.innerHTML = this.text ? this.text : "";

        if (this.title) {
            this.element.title = this.title;
        }

        this.element.style.color = this.color ? this.color : "";
        this.element.style.fontWeight = this.fontWeight ? this.fontWeight : "";
        this.element.style.fontSize = this.fontSize ? this.fontSize : "";
        this.element.style.textAlign = this.textAlign ? this.textAlign : "";
    }
}