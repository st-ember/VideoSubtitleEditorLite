import FormElementGeneric from "baseElements/FormElementGeneric";
import CheckboxElementOptions from "options/CheckboxElementOptions";

export default class CheckboxElement extends FormElementGeneric<boolean> implements CheckboxElementOptions {

    text?: string;
    element: HTMLInputElement = document.createElement("input");
    textElement: HTMLLabelElement = document.createElement("label");

    constructor(options?: CheckboxElementOptions) {
        super(options);
        this.bindOptions(options);
    }

    static fromAsync(options: CheckboxElementOptions): Promise<CheckboxElement> {
        return <Promise<CheckboxElement>>(new CheckboxElement(options).buildAsync());
    }

    protected async buildElementAsync(): Promise<void> {
        if (this.name) {
            this.element.name = this.name;
        }
        
        this.element.id = this.id;
        this.element.type = "checkbox";
        this.element.addEventListener("change", () => this.changeAsync());
        this.container.appendChild(this.element);

        if (this.title) {
            this.element.title = this.title;
            this.textElement.title = this.title;
        }

        this.textElement.setAttribute("for", this.id);
        this.textElement.innerHTML = this.text ? this.text : "";
        this.container.appendChild(this.textElement);

        this.messageAnchor = this.text ? this.textElement : this.element;
    }

    rebuildAsync(): Promise<void> {
        this.textElement.innerHTML = this.text ? this.text : "";
        if (this.title) {
            this.element.title = this.title;
            this.textElement.title = this.title;
        }
        return this.clearAsync();
    }

    async deleteAsync(): Promise<void> {
        await this.removeMessageAsync();
        this.container.remove();
    }

    async validateAsync(): Promise<boolean> {
        this.validated = true;
        const valid = !this.needToCheckRequire() || this.element.checked;
        await this.showInvalidEffectAsync(!valid, "您必須勾選此項目！");
        return valid;
    }

    async setDisableAsync(disable?: boolean): Promise<void> {
        this.disabled = disable !== false;
        this.element.disabled = this.disabled;
    }

    async clearAsync(): Promise<void> {
        this.element.checked = false;
    }

    async getValueAsync(): Promise<boolean> {
        return this.element.checked;
    }

    async setValueAsync(value: boolean): Promise<void> {
        this.element.checked = value;
        await this.changeAsync();
    }
}
