import FormElementGeneric from "baseElements/FormElementGeneric";
import TextAreaElementOptions from "options/TextAreaElementOptions";

export default class TextAreaElement extends FormElementGeneric<string> implements TextAreaElementOptions {

    rows: number = 4;
    placeholder: string = "";
    autocomplete: boolean = false;

    element: HTMLTextAreaElement = document.createElement("textarea");
    
    constructor(options?: TextAreaElementOptions) {
        super(options);
        this.bindOptions(options);
    }

    static fromAsync(options: TextAreaElementOptions): Promise<TextAreaElement> {
        return <Promise<TextAreaElement>>(new TextAreaElement(options).buildAsync());
    }

    protected async buildElementAsync(): Promise<void> {
        if (this.name) {
            this.element.name = this.name;
        }
        
        this.element.id = this.id;
        this.element.placeholder = this.placeholder;
        this.element.rows = !!this.rows ? this.rows : 4;
        this.element.autocomplete = !this.autocomplete ? "off" : "on";
        this.element.className = "form-theme-input form-theme-color form-theme-placeholder";

        if (this.title) {
            this.element.title = this.title;
        }
        
        this.element.addEventListener("change", () => this.changeAsync());
        this.container.appendChild(this.element);

        this.messageAnchor = this.element;
    }

    rebuildAsync(): Promise<void> {
        this.element.placeholder = this.placeholder;
        this.element.rows = !!this.rows ? this.rows : 4;
        this.element.autocomplete = !this.autocomplete ? "off" : "on";

        if (this.title) {
            this.element.title = this.title;
        }

        return this.clearAsync();
    }

    async deleteAsync(): Promise<void> {
        await this.removeMessageAsync();
        this.container.remove();
    }

    async setDisableAsync(disable?: boolean): Promise<void> {
        this.disabled = disable !== false;
        this.element.disabled = this.disabled;
    }

    async clearAsync(): Promise<void> {
        this.element.value = "";
        this.element.innerHTML = "";
    }

    async getValueAsync(): Promise<string> {
        return this.element.value;
    }

    async setValueAsync(value: string | undefined): Promise<void> {
        const newValue = !!value ? value : "";
        this.element.value = newValue;
        this.element.innerHTML = newValue;
        await this.changeAsync();
    }
}
