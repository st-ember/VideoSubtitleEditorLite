import FormElementGeneric from "baseElements/FormElementGeneric";
import { formController } from "controllers/FormController";
import RadioGroup from "misc/RadioGroup";
import RadioElementOptions from "options/RadioElementOptions";

export default class RadioElement extends FormElementGeneric<string | undefined> implements RadioElementOptions {

    name: string = "";
    text?: string = "";
    value: string = "";
    /** 預設狀態是否為未選擇。預設為 False，元件完成建立後會自動選擇第一個項目。 */
    allowEmpty?: boolean = false;

    element: HTMLInputElement = document.createElement("input");
    radioLabel: HTMLLabelElement = document.createElement("label");

    radioGroup: RadioGroup;

    protected isFirst: boolean = false;

    constructor(options?: RadioElementOptions) {
        super(options);
        this.bindOptions(options);

        if (!formController.radioGroups[this.name]) {
            formController.radioGroups[this.name] = new RadioGroup(this.name);
            formController.radioGroups[this.name].allowEmpty = this.allowEmpty;
            this.isFirst = true;
        }

        this.radioGroup = formController.radioGroups[this.name];
        this.radioGroup.addRadioElement(this);
    }

    static fromAsync(options: RadioElementOptions): Promise<RadioElement> {
        return <Promise<RadioElement>>(new RadioElement(options).buildAsync());
    }

    protected async buildElementAsync(): Promise<void> {
        this.element.className = "form-radio";
        this.element.name = this.name;
        this.element.id = this.id;
        this.element.type = "radio";
        this.element.value = this.value;
        this.element.addEventListener("change", () => this.changeAsync());
        this.container.appendChild(this.element);

        if (this.title) {
            this.element.title = this.title;
            this.radioLabel.title = this.title;
        }

        this.radioLabel.setAttribute("for", this.id);
        this.radioLabel.innerHTML = this.text ?? "";
        this.container.appendChild(this.radioLabel);

        this.messageAnchor = this.radioLabel;

        if (this.isFirst && !this.allowEmpty) {
            this.element.checked = true;
        }
    }

    rebuildAsync(): Promise<void> {
        this.radioLabel.innerHTML = this.text ?? "";
        if (this.title) {
            this.element.title = this.title;
            this.radioLabel.title = this.title;
        }
        return this.clearAsync();
    }

    async deleteAsync(): Promise<void> {
        await this.removeMessageAsync();
        this.container.remove();

        if (formController.radioGroups[this.name]) {
            delete formController.radioGroups[this.name];
        }
    }

    async validateAsync(): Promise<boolean> {
        return true;
    }

    async setDisableAsync(disable?: boolean): Promise<void> {
        this.disabled = disable !== false;
        this.element.disabled = this.disabled;
    }

    async clearAsync(): Promise<void> {
        this.element.checked = false;
    }

    async getValueAsync(): Promise<string> {
        return this.element.value;
    }

    async setValueAsync(value: string | number | undefined): Promise<void> {
        this.element.value = typeof value === "string" ? (!!value ? value : "") : (!!value ? String(value) : "");
        await this.changeAsync();
    }

    /** 觸發此元件的 change 事件，會導致必填元件進行驗證，並執行 change 後對應的 Function 清單。*/
    async changeAsync(): Promise<void> {
        this.edited = true;

        const value = await this.getValueAsync();
        await Promise.all(this.onChangeFuncs.map(func => {
            const result = func(value);
            return result && "then" in result ? result : new Promise<void>(resolve => resolve());
        }));

        await this.radioGroup.changeAsync();
    }
}

