import FormElementGeneric from "baseElements/FormElementGeneric";
import InputElementOptions from "options/InputElementOptions";

export default class InputElement extends FormElementGeneric<string | undefined> implements InputElementOptions {

    type: string = "text";
    placeholder?: string;
    autocomplete?: boolean = true;
    spellcheck?: boolean = false;
    minLength?: number;
    maxLength?: number;
    format?: "email" | "twId" | "twUniId" | "allTwId" | "phone";
    /** 是否在 Format 檢查失敗時顯示為錯誤並導致表單驗證失敗。預設為 True。 */
    formatError: boolean = true;
    formatChecker?: (value: string) => Promise<{ valid: boolean, error?: string }>;

    element: HTMLInputElement = document.createElement("input");
    
    constructor(options?: InputElementOptions) {
        super(options);
        this.bindOptions(options);
    }

    static fromAsync(options: InputElementOptions): Promise<InputElement> {
        return <Promise<InputElement>>(new InputElement(options).buildAsync());
    }

    protected async buildElementAsync(): Promise<void> {
        this.element.id = this.id;
        this.element.type = !!this.type ? this.type : "text";
        this.element.placeholder = this.placeholder ? this.placeholder : "";
        this.element.autocomplete = !this.autocomplete ? "off" : "on";
        this.element.className = "form-theme-input form-theme-color form-theme-placeholder";

        if (this.name) {
            this.element.name = this.name;
        }

        if (this.title) {
            this.element.title = this.title;
        }

        if (this.spellcheck) {
            this.element.spellcheck = this.spellcheck;
        }

        if (this.maxLength !== null && this.maxLength !== undefined && !isNaN(this.maxLength) && this.maxLength > 0) {
            this.element.maxLength = this.maxLength;
        }

        this.element.addEventListener("change", () => this.changeAsync());
        this.container.appendChild(this.element);

        this.messageAnchor = this.element;
    }

    rebuildAsync(): Promise<void> {
        this.element.type = !!this.type ? this.type : "text";
        this.element.placeholder = this.placeholder ? this.placeholder : "";
        this.element.autocomplete = !this.autocomplete ? "off" : "on";

        if (this.maxLength !== null && this.maxLength !== undefined && !isNaN(this.maxLength) && this.maxLength > 0) {
            this.element.maxLength = this.maxLength;
        }

        if (this.title) {
            this.element.title = this.title;
        }

        return this.clearAsync();
    }

    async deleteAsync(): Promise<void> {
        await this.removeMessageAsync();
        this.container.remove();
    }

    async validateAsync(): Promise<boolean> {
        let valid = false;
        this.validated = true;
        const value = await this.getValueAsync();
        if (!!value) {
            const lengthCheckResult = this.checkLength(value);
            if (!lengthCheckResult.valid) {
                await this.showInvalidEffectAsync(true, (lengthCheckResult.error ?? "格式錯誤！"));
                return false;
            }

            const formatCheckResult = await this.checkFormatAsync(value);
            if (!formatCheckResult.valid) {
                if (this.formatError) {
                    await this.showInvalidEffectAsync(true, (formatCheckResult.error ?? "格式錯誤！"));
                    return false;
                } else {
                    await this.showWarningEffectAsync(true, (formatCheckResult.error ?? "格式錯誤！"));
                    return true;
                }
            }

            await this.showInvalidEffectAsync(false);
            return true;
        } else {
            valid = !this.needToCheckRequire();
            await this.showInvalidEffectAsync(!valid, "此項目為必填！");
            return valid;
        }
    }

    async setDisableAsync(disable?: boolean): Promise<void> {
        this.disabled = disable !== false;
        this.element.disabled = this.disabled;
    }

    async clearAsync(): Promise<void> {
        this.element.value = "";
    }

    async getValueAsync(): Promise<string> {
        return this.element.value;
    }

    async setValueAsync(value: string | number | undefined): Promise<void> {
        this.element.value = typeof value === "string" ? (!!value ? value : "") : (!!value ? String(value) : "");
        await this.changeAsync();
    }

    checkLength(value: string): { valid: boolean, error?: string } {
        let valid = true;
        let error: string | undefined = undefined;
        if (this.minLength !== null && this.minLength !== undefined && this.minLength > 0) {
            valid = !!value && value.length >= this.minLength;
            error = !valid ? `字數不足，至少需要 ${this.minLength} 個字。` : "";
        }
        if (this.maxLength !== null && this.maxLength !== undefined && value) {
            valid = value.length <= this.maxLength;
            error = !valid ? `字數過多，不可超過 ${this.maxLength} 個字。` : "";
        }

        return { valid, error };
    }

    async checkFormatAsync(value: string): Promise<{ valid: boolean, error?: string }> {
        if (this.formatChecker) {
            return await this.formatChecker(value);
        } else if (this.format) {
            if (Object.keys(this.buildInFormatCheckers).indexOf(this.format) >= 0) {
                return this.buildInFormatCheckers[this.format](value);
            } else {
                return { valid: false, error: `格式設定錯誤，無效的格式：${this.format}` };
            }
        } else {
            return { valid: true };
        }
    }

    buildInFormatCheckers = {
        "email": (value: string) => {
            const valid = /^[\w!#$%&"*+\-/=?\^_`{|}~]+(\.[\w!#$%&"*+\-/=?\^_`{|}~]+)*@((([\-\w]+\.)+[a-zA-Z]{2,63})|(([0-9]{1,3}\.){3}[0-9]{1,3}))$/.test(value);
            return { valid, error: !valid ? "無效的電子郵件格式，需為半形英文與數字組成的電子郵件格式 (例如：example@domain.com.tw)" : undefined }
        },
        "twId": (value: string) => {
            let valid = true;
            const city = [1, 10, 19, 28, 37, 46, 55, 64, 39, 73, 82, 2, 11, 20, 48, 29, 38, 47, 56, 65, 74, 83, 21, 3, 12, 30];
            if (value.search(/^[A-Z](1|2)\d{8}$/i) === -1) {
                valid = false;
            } else {
                const data = value.split("");
                let total = city[data[0].charCodeAt(0) - 65];
                for (let i = 1; i <= 8; i++) { total += eval(data[i]) * (9 - i); }
                total += eval(data[9]);
                valid = total % 10 === 0;
            }

            return { valid, error: !valid ? "無效的身分證字號，需為半形大寫英文開頭與數字組成的中華民國身分證字號格式 (例如：A111222333)" : undefined }
        },
        "twUniId": (value: string) => {
            let valid = true;
            const invalidList = "00000000,11111111";
            if (/^\d{8}$/.test(value) === false || invalidList.indexOf(value) !== -1) {
                valid = false;
            } else {
                let sum = 0;
                const validateOperator = [1, 2, 1, 2, 1, 2, 4, 1];
                for (let i = 0; i < validateOperator.length; i++) {
                    const product = (<any>value)[i] * validateOperator[i];
                    const ones = product % 10, tens = (product - ones) / 10;
                    sum += ones + tens;
                }
                valid = sum % 10 === 0 || value[6] === "7" && (sum + 1) % 10 === 0;
            }
            return { valid, error: !valid ? "無效的統一編號，需為半形數字組成的中華民國統一編號格式 (例如：12345678)" : undefined }
        },
        "allTwId": (value: string) => {
            let validTwId = true;
            const city = [1, 10, 19, 28, 37, 46, 55, 64, 39, 73, 82, 2, 11, 20, 48, 29, 38, 47, 56, 65, 74, 83, 21, 3, 12, 30];
            if (value.search(/^[A-Z](1|2)\d{8}$/i) === -1) {
                validTwId = false;
            } else {
                const data = value.split("");
                let total = city[data[0].charCodeAt(0) - 65];
                for (let i = 1; i <= 8; i++) { total += eval(data[i]) * (9 - i); }
                total += eval(data[9]);
                validTwId = total % 10 === 0;
            }

            let validTwUniId = true;
            const invalidList = "00000000,11111111";
            if (/^\d{8}$/.test(value) === false || invalidList.indexOf(value) !== -1) {
                validTwUniId = false;
            } else {
                let sum = 0;
                const validateOperator = [1, 2, 1, 2, 1, 2, 4, 1];
                for (let i = 0; i < validateOperator.length; i++) {
                    const product = (<any>value)[i] * validateOperator[i];
                    const ones = product % 10, tens = (product - ones) / 10;
                    sum += ones + tens;
                }
                validTwUniId = sum % 10 === 0 || value[6] === "7" && (sum + 1) % 10 === 0;
            }

            const valid = validTwId || validTwUniId;
            return { valid, error: !valid ? "無效的身分證字號或統一編號格式，需為半形大寫英文開頭與數字組成的中華民國身分證字號或統一編號格式 (例如：「A111222333」或「12345678」)" : undefined }
        },
        "phone": (value: string) => {
            const result = /^\(?(\+\d{3}|0)\d\)?\-?(\d\)?\-?\d{3}\-?\d{3}|\d{3,4}\-?\d{4})(\s*\(?(\#+)\s*\d+\)?)?$/.test(value);
            const resultM = /^\(?(\+\d{3}|0)\d{3}\)?\-?(\d{2}\-?\d\-?\d\-?\d{2})$/.test(value);
            const valid = result || resultM;
            return { valid, error: !valid ? "無效的電話格式，需為半形數字組成的行動電話或市內電話格式 (例如：「02-21234567」、「02-21234567 #100」或「0912-345678」)" : undefined }
        }
    };
}