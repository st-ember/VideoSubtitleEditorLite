import FormElement from "baseElements/FormElement";
import FormElementContainer from "baseElements/FormElementContainer";
import InputElement from "formElements/InputElement";
import TextExpanderOptions from "options/TextExpanderOptions";

export default class TextExpander extends FormElementContainer implements TextExpanderOptions {

    allowDuplicated: boolean = false;
    textWhenEmpty: string = "(沒有任何項目)";
    appendButtonText: string = "新增";
    appendButtonTitle: string = "新增到清單中";

    textItems: { id: number; text: string; element: HTMLDivElement; deleteButton: HTMLButtonElement; }[] = [];
    emptyText: HTMLDivElement = document.createElement("div");
    textItemContainer: HTMLDivElement = document.createElement("div");

    textInputContainer: HTMLDivElement = document.createElement("div");
    textInputElement: InputElement = new InputElement();
    appendButton: HTMLButtonElement = document.createElement("button");

    // protected readonlyElement: ReadonlyArrayElement;

    protected textItemIdBase: number = 0;

    constructor(options?: TextExpanderOptions) {
        super(options);
        this.bindOptions(options);
    }

    static fromAsync(options: TextExpanderOptions): Promise<TextExpander> {
        return <Promise<TextExpander>>(new TextExpander(options).buildAsync());
    }

    async buildChildrenAsync(): Promise<void> {
        this.element.classList.add("expander-container");

        this.textItemContainer.className = "text-item-container";
        this.element.appendChild(this.textItemContainer);

        this.emptyText.className = "empty-text";
        this.emptyText.innerText = "(沒有任何項目)";
        this.textItemContainer.appendChild(this.emptyText);

        this.textInputContainer.className = "text-input-container";
        this.element.appendChild(this.textInputContainer);

        await this.textInputElement.buildAsync();
        this.textInputContainer.appendChild(this.textInputElement.container);
        this.formElements.push(this.textInputElement);
        this.textInputElement.element.addEventListener("keypress", e => this.onEnterKeyPress(e));

        this.appendButton.type = "button";
        this.appendButton.className = "append-button";
        this.appendButton.title = "新增到清單中";
        this.appendButton.innerHTML = "<i class=\"fa fa-plus\"></i>" + this.appendButtonText;
        this.appendButton.addEventListener("click", () => this.onAppendButtonClick());
        this.textInputContainer.appendChild(this.appendButton);
        
        return this.clearAsync();
    }

    rebuildAsync(): Promise<void> {
        return this.clearAsync();
    }

    async deleteAsync(): Promise<void> {
        this.container.remove();
    }

    async validateAsync(): Promise<boolean> {
        this.validated = true;
        const valid = !this.needToCheckRequire() || this.textItems.length > 0;
        await this.showInvalidEffectAsync(!valid, "此項目為必填！");
        return valid;
    }

    async setDisableAsync(disable?: boolean): Promise<void> {
        this.disabled = disable !== false;
        this.textInputElement.disabled = this.disabled;
        this.appendButton.disabled = this.disabled;
        this.textItems.forEach(item => item.deleteButton.disabled = this.disabled === true);
    }

    async appendTextItemAsync(text: string): Promise<void> {
        if (!this.allowDuplicated && this.textItems.filter(o => o.text === text).length > 0) {
            return;
        }

        const id = this.textItemIdBase++;

        const element = document.createElement("div");
        element.className = "text-item";
        element.innerHTML = "<span>" + text + "</span>";

        const deleteButton = document.createElement("button");
        deleteButton.type = "button";
        deleteButton.className = "danger delete-button";
        deleteButton.title = "刪除這個項目";
        deleteButton.innerHTML = "<i class=\"fa fa-times\"></i>";
        deleteButton.addEventListener("click", () => this.deleteTextItemAsync(id));
        element.appendChild(deleteButton);
        this.textItemContainer.appendChild(element);

        this.textItems.push({ id, text, element, deleteButton });

        if (this.textItems.length > 0) {
            this.emptyText.style.display = "none";
        }
    }

    async deleteTextItemAsync(id: number): Promise<void> {
        const index = this.textItems.findIndex(o => o.id === id);
        const deletedItems = this.textItems.splice(index, 1);

        deletedItems[0].element.remove();
        await this.changeAsync();

        if (this.textItems.length === 0) {
            this.emptyText.style.display = "";
        }
    }

    async clearAsync(): Promise<void> {
        await this.textInputElement.clearAsync();
        await this.setValueAsync([]);
    }

    async getValueAsync(): Promise<string[]> {
        return this.textItems.map(textItem => textItem.text);
    }

    async setValueAsync(value: string[]): Promise<void> {
        const newValues = value ? value.map(o => o ? o.trim() : "").filter(o => !!o) : [];
        if (this.textItems.length > 0) {
            for (let i = 0; i < this.textItems.length; i++) {
                await this.deleteTextItemAsync(this.textItems[i].id);
            }
        }

        for (let i = 0; i < newValues.length; i++) {
            await this.appendTextItemAsync(newValues[i]);
        }
    }

    append(formElement: FormElement): void { }

    async onAppendButtonClick(): Promise<void> {
        const value = await this.textInputElement.getValueAsync();
        await this.textInputElement.clearAsync();

        if (!value) {
            return;
        }

        const newValues = value.split(/[,;，：、]/)
            .map(o => o ? o.trim() : "")
            .filter(o => !!o);

        for (let i = 0; i < newValues.length; i++) {
            await this.appendTextItemAsync(newValues[i]);
        }

        await this.changeAsync();
    }

    async onEnterKeyPress(event: KeyboardEvent): Promise<void> {
        if (event.key === "Enter") {
            await this.onAppendButtonClick();
        }
    }
}