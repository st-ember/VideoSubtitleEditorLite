import FormElement from "baseElements/FormElement";
import FormElementContainer from "baseElements/FormElementContainer";
import TextElement from "formElements/staticElements/TextElement";
import ElementExpanderOptions, { ElementExpanderTableOptions } from "options/ElementExpanderOptions";

export default class ElementExpander<TRow extends FormElement, TData> extends FormElementContainer implements ElementExpanderOptions<TRow> {

    formElementCreationFunc: () => TRow = undefined!;

    /** 新增與刪除的按鈕放在每行的前面。 */
    buttonAhead?: boolean = true;
    showExpandButtons?: boolean = true;
    insertButtonTitle: string = "插入新行";
    deleteButtonTitle: string = "刪除此行";
    title?: string;
    tableOptions?: ElementExpanderTableOptions;

    header: { formElement: FormElementContainer; container: HTMLDivElement; } = undefined!;
    body: HTMLDivElement = undefined!;
    bodyTitle: HTMLDivElement = undefined!;
    rows: { formElement: TRow; container: HTMLDivElement; insertButton?: HTMLButtonElement; deleteButton?: HTMLButtonElement; }[] = [];

    protected rowIdBase: number = 0;
    protected withHeader: boolean = false;
    protected applyingData: boolean = false;

    constructor(options?: ElementExpanderOptions<TRow>) {
        super(options);
        this.bindOptions(options);
    }

    static fromAsync<TRow extends FormElement, TData>(options: ElementExpanderOptions<TRow>): Promise<ElementExpander<TRow, TData>> {
        return <Promise<ElementExpander<TRow, TData>>>(new ElementExpander<TRow, TData>(options).buildAsync());
    }

    async buildChildrenAsync(): Promise<void> {
        this.element.classList.add("expander-container");
        await this.buildHeaderAsync();
        this.buildBodyTitle();
        this.buildBody();
        await this.clearAsync();
    }

    protected async buildHeaderAsync(): Promise<void> {
        this.withHeader = !!this.tableOptions && this.tableOptions.columns && this.tableOptions.columns.length > 0;
        const container = document.createElement("div");
        container.className = `row-container expander-header form-theme-header${this.withHeader && !this.tableOptions?.hideHeader ? "" : " hide-header"}`;

        if (this.buttonAhead && this.showExpandButtons) {
            container.classList.add("button-ahead");
        }

        if (!this.showExpandButtons) {
            container.classList.add("without-buttons");
        }

        const header = await FormElementContainer.fromAsync({
            buildChildrenFunc: async group => {
                if (this.withHeader) {
                    for (let i = 0; i < this.tableOptions!.columns.length; i++) {
                        const elem = TextElement.fromAsync({
                            flex: this.tableOptions!.columns[i].flex,
                            width: this.tableOptions!.columns[i].width,
                            text: this.tableOptions!.columns[i].head
                        });
                        await group.appendAsync(elem);
                    }
                }
            }
        });

        header.element.style.width = "100%";

        this.header = { formElement: header, container };

        this.formElements.push(header);
        this.element.appendChild(header.container);
        await header.onAppendAsync();

        container.appendChild(header.container);
        this.element.appendChild(container);
    }

    protected buildBody(): void {
        this.body = document.createElement("div");
        this.body.className = "expander-body";
        this.element.appendChild(this.body);
    }

    protected buildBodyTitle(): void {
        this.bodyTitle = document.createElement("div");
        this.bodyTitle.className = "expander-body-title form-theme-color-light";
        this.element.appendChild(this.bodyTitle);

        if (this.title) {
            this.element.classList.add("with-body-title");
            this.bodyTitle.innerHTML = this.title;
        } else {
            this.element.classList.remove("with-body-title");
        }
    }

    rebuildAsync(): Promise<void> {
        if (this.title) {
            this.bodyTitle.classList.remove("hide");
            this.bodyTitle.innerHTML = this.title;
        } else {
            this.bodyTitle.classList.add("hide");
        }

        return this.clearAsync();
    }

    async deleteAsync(): Promise<void> {
        while (this.rows.length > 0) {
            const index = this.rows.length - 1;
            this.formElements.splice(index + 1, 1);
            const deletedRow = this.rows.splice(index, 1);
            
            for (let i = 0; i < deletedRow.length; i++) {
                const row = deletedRow[i];
                await row.formElement.deleteAsync();
                row.container.remove();
            }
        }
        this.container.remove();
    }

    async validateAsync(): Promise<boolean> {
        this.validated = true;

        if (this.needToCheckRequire() && this.rows.length === 0) {
            await this.showInvalidEffectAsync(true, "您必須至少加入一筆資料！");
            return false;
        } else {
            await this.showInvalidEffectAsync(false);
        }

        if (this.needToCheckRequire()) {
            const results = await Promise.all(this.rows.map(row => row.formElement.validateAsync()));
            return results.filter(o => !o).length === 0;
        } else {
            return true;
        }
    }

    async setDisableAsync(disable?: boolean): Promise<void> {
        this.disabled = disable !== false;
        this.rows.forEach(row => {
            if (row.insertButton) {
                row.insertButton.disabled = this.disabled === true;
            }

            if (row.deleteButton) {
                row.deleteButton.disabled = this.disabled === true;
            }
        });
        await Promise.all(this.formElements.map(formElement => formElement.setDisableAsync(this.disabled)));
    }

    async insertRowAsync(index: number, doNotTriggerChangeEvent?: boolean): Promise<TRow> {
        const rowElement = this.formElementCreationFunc();
        rowElement.addChangeFunc(() => this.changeAsync());
        
        const newRow = this.createRow(rowElement);
        if (index <= this.rows.length - 1) {
            const refElem = this.body.children.item(index);
            this.body.insertBefore(newRow.container, refElem);
        } else {
            this.body.appendChild(newRow.container);
        }

        this.rows.splice(index, 0, newRow);
        this.formElements.splice(index + 1, 0, newRow.formElement);
        
        await newRow.formElement.buildAsync(this.name + "-" + String(this.rowIdBase++));

        newRow.container.appendChild(newRow.formElement.container);

        if (this.buttonAhead && this.showExpandButtons) {
            newRow.container.classList.add("button-ahead");
        }

        if (!this.showExpandButtons) {
            newRow.container.classList.add("without-buttons");
        }

        if (this.withHeader && newRow.formElement instanceof FormElementContainer) {
            await Promise.all(this.tableOptions!.columns.map(async (column, i) => {
                const formElement = <FormElementContainer><unknown>newRow.formElement;
                if (i < formElement.formElements.length) {
                    const childElement = formElement.formElements[i];
                    childElement.flex = column.flex;
                    childElement.width = column.width;
                    childElement.updateContainer();
                    await childElement.rebuildAsync();
                }
            }));
        }

        if (doNotTriggerChangeEvent !== true) {
            await this.changeAsync();
        }

        return newRow.formElement;
    }

    async deleteRowAsync(index: number, doNotTriggerChangeEvent?: boolean): Promise<void> {
        this.formElements.splice(index + 1, 1);
        const deletedRow = this.rows.splice(index, 1);
        
        for (let i = 0; i < deletedRow.length; i++) {
            const row = deletedRow[i];
            await row.formElement.deleteAsync();
            row.container.remove();
        }

        if (this.rows.length === 0) {
            await this.insertRowAsync(0);
        }

        if (doNotTriggerChangeEvent !== true) {
            await this.changeAsync();
        }
    }

    protected createRow(formElement: TRow) {
        const container = document.createElement("div");
        container.className = "row-container";

        if (this.showExpandButtons) {
            const insertButton = document.createElement("button");
            insertButton.className = "row-insert-button success small-button";
            insertButton.type = "button";
            insertButton.innerHTML = "<i class=\"fa fa-plus\"></i>";
            insertButton.title = this.insertButtonTitle;
            insertButton.addEventListener("click", () => this.insertRowAsync(this.findIndex(container) + 1));
            container.appendChild(insertButton);
    
            const deleteButton = document.createElement("button");
            deleteButton.className = "row-delete-button warning small-button";
            deleteButton.type = "button";
            deleteButton.innerHTML = "<i class=\"fa fa-times\"></i>";
            deleteButton.title = this.deleteButtonTitle;
            deleteButton.addEventListener("click", () => this.deleteRowAsync(this.findIndex(container)));
            container.appendChild(deleteButton);

            container.classList.add("show-expand-button");
    
            return { formElement, container, insertButton, deleteButton };
        } else {
            return { formElement, container };
        }
    }

    findIndex(container: HTMLDivElement): number {
        const index = this.rows.findIndex(row => row.container.isSameNode(container));
        return index >= 0 ? index : this.rows.length - 1;
    }

    clearAsync(): Promise<void> {
        return this.setValueAsync([]);
    }

    async getValueAsync(): Promise<TData[]> {
        const value: TData[] = [];
        await Promise.all(this.rows.map(async row => {
            const childValue = await row.formElement.getValueAsync();
            if (childValue) {
                value.push(childValue);
            }
        }));

        return value;
    }

    async setValueAsync(value: TData[]): Promise<void> {
        this.applyingData = true;
        const newValues = value && value.length > 0 ? value : [<TData>{}];
        const addCount = newValues.length - this.rows.length;
        const deleteCount = this.rows.length - newValues.length;
        
        if (addCount > 0) {
            for (let i = 0; i < addCount; i++) {
                await this.insertRowAsync(this.rows.length, true);
            }
        } else if (deleteCount > 0) {
            for (let i = 0; i < deleteCount; i++) {
                await this.deleteRowAsync(this.rows.length - 1, true);
            }
        }

        await Promise.all(this.formElements.map(async (formElement, index) => {
            if (index > 0) {
                await formElement.setValueAsync(newValues[index - 1] ? newValues[index - 1] : {});
            }
        }));

        this.applyingData = false;
        await this.changeAsync();
    }

    async appendAsync(formElement: TRow): Promise<void>;
    async appendAsync(formElement: HTMLElement): Promise<void>;
    async appendAsync(formElement: Promise<TRow>): Promise<void>;
    async appendAsync(formElement: Promise<HTMLElement>): Promise<void>;
    async appendAsync(formElement: TRow | HTMLElement | Promise<TRow> | Promise<HTMLElement>): Promise<void> {
        let element: TRow | HTMLElement;
        if ("then" in formElement) {
            // Is Promise type.
            element = await formElement;
        } else {
            element = formElement;
        }

        if (element instanceof FormElement) {
            const index = this.rows.length - 1;
            const newRow = this.createRow(element);
            this.rows.splice(index, 0, newRow);
            this.formElements.splice(index + 1, 0, newRow.formElement);
        }
    }
}