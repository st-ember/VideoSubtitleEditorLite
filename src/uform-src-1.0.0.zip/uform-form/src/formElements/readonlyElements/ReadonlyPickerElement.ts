import PickerElementGeneric from "baseElements/PickerElementGeneric";
import PickerElementOptions from "options/PickerElementOptions";

export default class ReadonlyPickerElement extends PickerElementGeneric<string | string[] | undefined> implements PickerElementOptions {

    element: HTMLDivElement = document.createElement("div");

    value: string | string[] | undefined;

    static fromAsync(options: PickerElementOptions): Promise<ReadonlyPickerElement> {
        return <Promise<ReadonlyPickerElement>>(new ReadonlyPickerElement(options).buildAsync());
    }

    protected async buildElementAsync(): Promise<void> {
        this.element = document.createElement("div");
        this.element.className = "readonly-input form-theme-input readonly-items";
        this.element.id = this.id;
        this.container.appendChild(this.element);

        if (this.title) {
            this.element.title = this.title;
        }

        this.messageAnchor = this.element;
        await this.getOptionsAsync();
    }

    async rebuildAsync(): Promise<void> {
        await this.clearAsync();
        this.element.remove();
        await this.buildElementAsync();
    }

    async deleteAsync(): Promise<void> {
        this.container.remove();
    }

    async validateAsync(): Promise<boolean> {
        this.validated = true;
        return true;
    }

    async setDisableAsync(disable?: boolean): Promise<void> {
        this.disabled = disable !== false;
    }

    async clearAsync(): Promise<void> {
        this.value = [];
        this.element.innerHTML = "";
    }

    async getValueAsync(): Promise<string | string[] | undefined> {
        return typeof this.value === "string" ? this.value : (this.value ? this.value : []);
    }

    async getSingleValueAsync(): Promise<string | undefined> {
        return typeof this.value === "string" ? this.value : (this.value && this.value.length > 0 ? this.value[0] : undefined);
    }

    async getTextAsync(): Promise<string | (string | undefined)[] | undefined> {
        const value = await this.getValueAsync();
        if (value instanceof Array) {
            return this.options.filter(o => value.indexOf(o.value ?? "") >= 0).map(o => o.text);
        } else {
            const matchs = this.options.filter(o => o.value === value).map(o => o.text);
            return matchs.length > 0 ? matchs[0] : undefined;
        }
    }

    async getArrayTextAsync(): Promise<string | (string | undefined)[] | undefined> {
        const value = await this.getValueAsync();
        if (value instanceof Array) {
            return this.options.filter(o => value.indexOf(o.value ?? "") >= 0).map(o => o.text);
        } else {
            const matchs = this.options.filter(o => o.value === value).map(o => o.text);
            return matchs.length > 0 ? [matchs[0]] : [];
        }
    }

    async getSingleTextAsync(): Promise<string | undefined> {
        const value = await this.getSingleValueAsync();
        const matchs = this.options.filter(o => o.value === value).map(o => o.text);
        return matchs.length > 0 ? matchs[0] : undefined;
    }

    async getArrayNumberAsync(): Promise<number | (number | undefined)[] | undefined> {
        const value = await this.getValueAsync();
        if (value instanceof Array) {
            return this.options.filter(o => value.indexOf(o.value ?? "") >= 0).map(o => Number(o.value)).map(n => !isNaN(n) ? n : undefined);
        } else {
            const matchs = this.options.filter(o => o.value === value).map(o => Number(o.value)).map(n => !isNaN(n) ? n : undefined);
            return matchs.length > 0 ? [matchs[0]] : [];
        }
    }

    async getNumberAsync(): Promise<number | (number | undefined)[] | undefined> {
        const value = await this.getValueAsync();
        if (value instanceof Array) {
            return this.options.filter(o => value.indexOf(o.value ?? "") >= 0).map(o => Number(o.value)).map(n => !isNaN(n) ? n : undefined);
        } else {
            const matchs = this.options.filter(o => o.value === value).map(o => Number(o.value)).map(n => !isNaN(n) ? n : undefined);
            return matchs.length > 0 ? matchs[0] : undefined;
        }
    }

    async getSingleNumberAsync(): Promise<number | undefined> {
        const value = await this.getSingleValueAsync();
        const matchs = this.options.filter(o => o.value === value).map(o => Number(o.value)).map(n => !isNaN(n) ? n : undefined);
        return matchs.length > 0 ? matchs[0] : undefined;
    }

    async setValueAsync(value: string | string[] | number | number[] | undefined): Promise<void> {
        this.value = value instanceof Array ? value.map((o: string | number) => String(o)) : String(value);

        this.element.innerHTML = "";

        const values = (this.value instanceof Array ? this.value : [this.value]) ?? [];
        const optionItems = this.options
            .filter(o => values.indexOf(o.value ?? "") >= 0)
            .map(option => {
                const optionItem = document.createElement("div");
                optionItem.className = "readonly-text-item form-theme-color-light";
                optionItem.innerHTML = `<span>${option.text}</span>`;
                this.element.appendChild(optionItem);
                return optionItem;
            });

        if (typeof this.value === "string" && optionItems.length > 0) {
            this.element.classList.add("single-item");
        } else {
            this.element.classList.remove("single-item");
        }

        await this.changeAsync();
    }
}