import FormElementOptions from "options/FormElementOptions";
import ReadonlyInputElement from "./ReadonlyInputElement";

export default class ReadonlyTextAreaElement extends ReadonlyInputElement implements FormElementOptions {

    constructor(options?: FormElementOptions) {
        super(options);
        this.bindOptions(options);
    }

    static fromAsync(options: FormElementOptions): Promise<ReadonlyTextAreaElement> {
        return <Promise<ReadonlyTextAreaElement>>(new ReadonlyTextAreaElement(options).buildAsync());
    }

    protected async buildElementAsync(): Promise<void> {
        this.element = document.createElement("div");
        this.element.className = "readonly-input form-theme-input form-theme-color-light multiple-lines";
        this.element.id = this.id;
        this.container.appendChild(this.element);

        this.messageAnchor = this.element;

        if (this.title) {
            this.element.title = this.title;
        }
    }
}
