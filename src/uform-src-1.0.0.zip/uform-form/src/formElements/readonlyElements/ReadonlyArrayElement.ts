import FormElementGeneric from "baseElements/FormElementGeneric";
import FormElementOptions from "options/FormElementOptions";

export default class ReadonlyArrayElement extends FormElementGeneric<string[]> implements FormElementOptions {

    element: HTMLDivElement = document.createElement("div");

    value: string[] = [];

    static fromAsync(options: FormElementOptions): Promise<ReadonlyArrayElement> {
        return <Promise<ReadonlyArrayElement>>(new ReadonlyArrayElement(options).buildAsync());
    }

    protected async buildElementAsync(): Promise<void> {
        this.element.className = "readonly-input form-theme-input multiple-lines";
        this.element.id = this.id;
        this.container.appendChild(this.element);

        this.messageAnchor = this.element;

        if (this.title) {
            this.element.title = this.title;
        }
    }

    async rebuildAsync(): Promise<void> {
        await this.clearAsync();
        this.element.remove();
        await this.buildElementAsync();
    }

    async deleteAsync(): Promise<void> {
        this.container.remove();
    }

    async validateAsync(): Promise<boolean> {
        this.validated = true;
        return true;
    }

    async setDisableAsync(disable?: boolean): Promise<void> {
        this.disabled = disable !== false;
    }

    async clearAsync(): Promise<void> {
        this.value = [];
        this.element.innerHTML = "";
    }

    async getValueAsync(): Promise<string[]> {
        return this.value ? this.value : [];
    }

    async setValueAsync(value: string[]): Promise<void> {
        this.value = value;

        this.element.innerHTML = "";

        this.value.forEach(value => {
            const item = document.createElement("div");
            item.className = "readonly-text-item form-theme-color-light";
            item.innerText = `<span>${value}</span>`;
            this.element.appendChild(item);
        });
        
        await this.changeAsync();
    }
}