import FormElementGeneric from "baseElements/FormElementGeneric";
import FormElementOptions from "options/FormElementOptions";

export default class ReadonlyNumberElement extends FormElementGeneric<number | undefined> implements FormElementOptions {

    element: HTMLDivElement = document.createElement("div");

    value: number | undefined;

    constructor(options?: FormElementOptions) {
        super(options);
        this.bindOptions(options);
    }

    static fromAsync(options: FormElementOptions): Promise<ReadonlyNumberElement> {
        return <Promise<ReadonlyNumberElement>>(new ReadonlyNumberElement(options).buildAsync());
    }

    protected async buildElementAsync(): Promise<void> {
        this.element = document.createElement("div");
        this.element.className = "readonly-input form-theme-input form-theme-color-light";
        this.element.id = this.id;
        this.container.appendChild(this.element);

        if (this.title) {
            this.element.title = this.title;
        }

        this.messageAnchor = this.element;
    }

    async rebuildAsync(): Promise<void> {
        await this.clearAsync();
        this.element.remove();
        await this.buildElementAsync();
    }

    async deleteAsync(): Promise<void> {
        this.container.remove();
    }

    async validateAsync(): Promise<boolean> {
        this.validated = true;
        return true;
    }

    async setDisableAsync(disable?: boolean): Promise<void> {
        this.disabled = disable !== false;
    }

    async clearAsync(): Promise<void> {
        this.value = undefined;
        this.element.innerText = "";
    }

    async getValueAsync(): Promise<number | undefined> {
        return this.value;
    }

    async setValueAsync(value: string | number | undefined): Promise<void> {
        const numberValue = typeof value === "string" ? Number(value) : value;
        this.value = numberValue !== undefined && !isNaN(numberValue) ? numberValue : undefined;
        this.element.innerText = String(this.value ?? "");
        
        await this.changeAsync();
    }
}
