import PickerElementGeneric from "baseElements/PickerElementGeneric";
import OptionItem from "models/OptionItem";
import PickerElementOptions from "options/PickerElementOptions";

export default class RadioButtonElement extends PickerElementGeneric<string | undefined> {

    element: HTMLInputElement = undefined!;
    radioOptionElements: { value?: string; element: HTMLInputElement; label: HTMLLabelElement; }[] = [];

    static fromAsync(options: PickerElementOptions): Promise<RadioButtonElement> {
        return <Promise<RadioButtonElement>>(new RadioButtonElement(options).buildAsync());
    }

    protected async buildElementAsync(): Promise<void> {
        await this.getOptionsAsync();

        this.options.forEach(option => this.buildOption(option));
        this.element = this.radioOptionElements.length > 0 ? this.radioOptionElements[0].element : undefined!;
    }

    protected buildOption(option: OptionItem): void {
        const radioElementGroup = document.createElement("div");
        radioElementGroup.className = "radio-element-group";
        this.container.appendChild(radioElementGroup);

        const element = document.createElement("input");
        element.type = "radio";

        if (this.name) {
            element.name = this.name;
        }
        
        if (option.value) {
            element.value = option.value;
        }
        
        element.id = this.id + "-" + (option.value ?? "");
        element.addEventListener("change", () => this.changeAsync());
        radioElementGroup.appendChild(element);

        if (this.radioOptionElements.length === 0 && !this.allowEmpty) {
            element.checked = true;
        }

        const label = document.createElement("label");
        label.className = "button default";
        label.innerText = option.text ?? "";
        label.setAttribute("for", element.id);
        radioElementGroup.appendChild(label);

        if (option.subText) {
            const subText = document.createElement("span");
            subText.className = "sub-text";
            subText.innerText = option.subText;
            label.appendChild(subText);
            label.title = option.subText;
        }

        this.radioOptionElements.push({ value: option.value, element, label });
    }

    async rebuildAsync(): Promise<void> {
        this.radioOptionElements.forEach(o => {
            o.element.parentElement?.remove();
            o.element.remove();
            o.label.remove();
        });

        this.element = undefined!;
        this.radioOptionElements = [];
        await this.buildElementAsync();
        await this.clearAsync();
    }

    async deleteAsync(): Promise<void> {
        await this.removeMessageAsync();
        this.container.remove();
    }

    async validateAsync(): Promise<boolean> {
        const valid = !this.needToCheckRequire() || !!(await this.getValueAsync());
        this.validated = true;
        await this.showInvalidEffectAsync(!valid, "您必須選擇一個項目！");

        return valid;
    }

    async setDisableAsync(disable?: boolean): Promise<void> {
        this.disabled = disable !== false;
        this.radioOptionElements.forEach(o => o.element.disabled = this.disabled === true);
    }

    clearAsync(): Promise<void> {
        return this.setValueAsync(undefined);
    }

    async getValueAsync(): Promise<string | undefined> {
        const checkedItems = this.radioOptionElements.filter(o => o.element.checked);
        return checkedItems.length > 0 ? checkedItems[0].value : undefined;
    }

    async getNumberValueAsync(): Promise<number | undefined> {
        const value = await this.getValueAsync();
        return !isNaN(Number(value)) ? Number(value) : undefined;
    }

    async setValueAsync(value: number | string | undefined): Promise<void> {
        const newValue = String(value);
        this.radioOptionElements.forEach(o => o.element.checked = o.value === newValue);

        if (this.radioOptionElements.filter(o => o.element.checked).length === 0 && !this.allowEmpty) {
            this.radioOptionElements[0].element.checked = true;
        }

        await this.changeAsync();
    }
}