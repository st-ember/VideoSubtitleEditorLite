import { Api } from "uform-api";

export const fileOptionApiMap = {
    Upload: <Api>{ url: "/File/Upload", method: "POST" },
    Check: <Api>{ url: "/File/Check", method: "GET" },
    Download: <Api>{ url: "/File/Download", method: "GET" },
    Delete: <Api>{ url: "/File/Delete", method: "POST" },
    UploadToCache: <Api>{ url: "/File/UploadToCache", method: "POST" },
    CheckFromCache: <Api>{ url: "/File/Check", method: "GET" },
    DownloadFromCache: <Api>{ url: "/File/DownloadFromCache", method: "GET" },
    DeleteFromCache: <Api>{ url: "/File/DeleteFromCache", method: "POST" }
};