
// const dataSourceApiMap = {
//     GetOptions: <Api>{ url: "/DataSource/Get{OptionName}Options", method: "GET" }
// };