import FormElementOptions from "options/FormElementOptions";
import FormElement from "./FormElement";

export default abstract class StaticFormElement extends FormElement {

    constructor(options?: FormElementOptions) {
        super(options);
    }

    async deleteAsync(): Promise<void> {
        this.container.remove();
    }

    async validateAsync(): Promise<boolean> {
        this.validated = true;
        return true;
    }

    async setDisableAsync(disable?: boolean): Promise<void> {
        this.disabled = disable !== false;
    }

    async clearAsync(): Promise<void> { }

    async getValueAsync(): Promise<undefined> {
        return undefined;
    }

    async setValueAsync(value: string | number): Promise<void> { }
}