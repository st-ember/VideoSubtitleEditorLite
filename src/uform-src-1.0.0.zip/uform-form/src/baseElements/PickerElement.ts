import { dataSourceController } from "controllers/DataSourceController";
import OptionItem from "models/OptionItem";
import PickerElementOptions from "options/PickerElementOptions";
import FormElement from "./FormElement";

export default abstract class PickerElement extends FormElement implements PickerElementOptions {

    optionName?: string;
    defaultOptionText?: string;
    options?: OptionItem[];

    constructor(options?: PickerElementOptions) {
        super(options);
        this.bindOptions(options);
    }

    protected async getOptionsAsync(): Promise<void> {
        if (!this.options) {
            this.options = this.optionName ? await dataSourceController.getSelectOptionsAsync(this.optionName, this.defaultOptionText) : [];
        }
    }
}
