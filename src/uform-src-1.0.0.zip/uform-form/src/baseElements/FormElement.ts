import { formFontawesomeIcons } from "contexts/FormIcons";
import { formController } from "controllers/FormController";
import FormElementOptions from "options/FormElementOptions";
import popoverController, { Popover } from "uform-popover";

export default abstract class FormElement implements FormElementOptions {

    /** 指定元件使用的 ID；如未指定，元件會自動獲得一個全域唯一 ID。 */
    id: string;
    name?: string;
    /** 元件的寬度，可用數字代表 px 值，或是輸入 css 可接受的字串。 */
    width?: number | string;
    /** 元件在 Flex 模式下的寬度，只可提供數字。與 width 同時設定時會取代 width 的功能。 */
    flex?: number;
    /** 元件前方的標籤。 */
    label?: string;
    /** 元件預設的必要屬性。 */
    required?: boolean = false;
    /** 元件預設的停用屬性。 */
    disabled?: boolean = false;
    /** 元件預設的隱藏屬性。 */
    hide?: boolean = false;
    /** 強制隱藏元件必要時顯示在前方的紅色星號。 */
    hideReqiredIcon?: boolean = false;
    /** 元件的 title 屬性，通常是滑鼠置於元件上時要顯示的說明文字。 */
    title?: string;
    /** 當 Change 行為發生後，要執行的 Funcion 清單。 */
    onChangeFuncs: (((value?: any) => void) | ((value?: any) => Promise<void>))[] = [];

    container: HTMLDivElement = undefined!;
    labelElement?: HTMLLabelElement;
    /** 標示元件為必要的紅色星號，只會在此元件沒有 label 時被建立。 */
    requiredIconElement?: HTMLSpanElement;
    element: HTMLElement = undefined!;

    /** 此元件的值是否已經人工修改過。 */
    edited: boolean = false;

    /** 元件狀態。0 表示尚未 builded，2 表示已全部完成可供使用。 */
    state: number = 0;

    /** 這個元件專用的 Popover，用來顯示資訊、警告與錯誤訊息。 */
    protected popover?: Popover;
    /** Popover 定位點物件，預設是 Container，但應隨不同元件的結構調整。 */
    protected messageAnchor?: HTMLElement;
    /** 此元件上的 Popover 是否在建立後立刻自動彈出。 */
    protected autoOpenMessage: boolean = true;

    /** 是否已經驗證過或是已經包含初始預設值。如果是的話應該要在變更後直接再驗證一次並於驗證失敗時立刻顯示錯誤訊息。 */
    protected validated: boolean = false;
    protected excludeOptionKeys = ["id", "name", "width", "flex", "label", "required", "disabled", "hide", "onChangeFuncs"];
    protected baseOptions?: FormElementOptions;
    protected validateWarning?: string;
    protected validateError?: string;

    constructor(options?: FormElementOptions) {
        this._bindBaseOptions(options);
        this.id = String(formController.getNewElementId());
    }

    private _bindBaseOptions(options?: FormElementOptions): void {
        if (!options) {
            return;
        }

        this.baseOptions = { ...options };

        if (options.name) {
            this.name = options.name;
        }

        if (options.width !== undefined && options.width !== null) {
            this.width = options.width;
        }

        if (options.flex !== undefined && options.flex !== null && !isNaN(options.flex)) {
            this.flex = options.flex;
        }

        if (options.label != undefined && options.label != null) {
            this.label = options.label;
        }

        if (options.required != undefined && options.required != null) {
            this.required = options.required;
        }

        if (options.disabled != undefined && options.disabled != null) {
            this.disabled = options.disabled;
        }

        if (options.hide != undefined && options.hide != null) {
            this.hide = options.hide;
        }

        if (options.onChangeFuncs) {
            this.onChangeFuncs = options.onChangeFuncs;
        }
    }

    protected bindOptions(options?: FormElementOptions): void {
        if (options) {
            Object.keys(options).forEach(key => {
                if (this.excludeOptionKeys.indexOf(key) < 0 && (<any>options)[key] !== undefined && (<any>options)[key] !== null) {
                    (<any>this)[key] = (<any>options)[key];
                }
            });
        }
    }

    async buildAsync(): Promise<FormElement>;
    async buildAsync(name: string): Promise<FormElement>;
    async buildAsync(name: string, label: string): Promise<FormElement>;
    async buildAsync(name?: string, label?: string): Promise<FormElement> {
        if (this.state !== 0) {
            return this;
        }

        this.state = 1;

        if (name !== undefined && name != null) {
            this.name = name;
        }

        if (label !== undefined && label != null) {
            this.label = label;
        }

        if (!this.name) {
            this.name = this.id;
        }

        await this.buildContainerAsync();
        this.buildLabel(this.label);
        await this.buildElementAsync();

        if (this.required) {
            await this.setRequiredAsync();
        }

        if (this.disabled) {
            await this.setDisableAsync();
        }

        if (this.hide) {
            await this.hideAsync();
        }

        this.state = 2;

        return this;
    }

    protected buildContainerAsync(): Promise<void> {
        this.container = document.createElement("div");
        this.container.className = "form-container";

        if (this.flex !== undefined && this.flex !== null && !isNaN(this.flex)) {
            this.container.style.flex = String(this.flex);
        }
        else if (this.width !== undefined && this.width !== null) {
            this.container.style.width = typeof this.width === "number" ? `${this.width}px` : this.width;
        }

        this.messageAnchor = this.container;

        return this.setRequiredAsync(this.required);
    }

    protected buildLabel(text?: string): void {
        if (text !== undefined && text !== null) {
            this.labelElement = document.createElement("label");
            this.labelElement.className = "form-theme-light";
            this.labelElement.innerText = text;
            this.labelElement.setAttribute("for", this.id);
            this.container.appendChild(this.labelElement);
        }
    }

    protected abstract buildElementAsync(): Promise<void>;

    updateContainer(): void {
        if (this.flex !== undefined && this.flex !== null && !isNaN(this.flex)) {
            this.container.style.flex = String(this.flex);
        }
        else if (this.width !== undefined && this.width !== null) {
            this.container.style.width = typeof this.width === "number" ? `${this.width}px` : this.width;
        }
    }

    async onAppendAsync(): Promise<void> {}

    abstract rebuildAsync(): Promise<void>;

    abstract deleteAsync(): Promise<void>;

    async validateAsync(): Promise<boolean> {
        const valid = !this.needToCheckRequire() || !!(await this.getValueAsync());
        this.validated = true;
        await this.showInvalidEffectAsync(!valid, "此項目為必填！");

        return valid;
    }

    protected needToCheckRequire(): boolean {
        return this.required === true && !this.hide && !this.disabled;
    }

    /** 隱藏此元件。 */
    async hideAsync(): Promise<void> {
        this.container.classList.add("hide");
        this.hide = true;
    }

    /** 如此元件狀態為隱藏中，顯示此元件。 */
    async showAsync(): Promise<void> {
        this.container.classList.remove("hide");
        this.hide = false;
    }

    /** 修改此元件的停用狀態。 */
    abstract setDisableAsync(disable?: boolean): Promise<void>;

    /** 修改此元件的必填狀態。 */
    async setRequiredAsync(required?: boolean): Promise<void> {
        this.required = required !== false;
        if (this.required) {
            this.container.classList.add("required");

            if (!this.hideReqiredIcon && (this.label === undefined || this.label === null) && !this.requiredIconElement) {
                this.requiredIconElement = document.createElement("span");
                this.requiredIconElement.className = "reqiured-icon";
                if (this.container.firstChild) {
                    this.container.insertBefore(this.requiredIconElement, this.container.firstChild);
                } else {
                    this.container.appendChild(this.requiredIconElement);
                }
            }
        } else {
            this.container.classList.remove("required");
            if (this.requiredIconElement) {
                this.requiredIconElement.remove();
            }
        }
    }

    /** 設定此元件是否在 Popover 建立後自動彈出。 */
    setAutoOpenMessage(enable?: boolean): void {
        this.autoOpenMessage = enable !== false;
    }

    /** 清除此元件的值。 */
    abstract clearAsync(): Promise<void>;

    abstract getValueAsync(): Promise<any>;

    abstract setValueAsync(value: any): Promise<void>;

    /** 觸發此元件的 change 事件，會導致必填元件進行驗證，並執行 change 後對應的 Function 清單。*/
    async changeAsync(): Promise<void> {
        this.edited = true;
        if (this.validated) {
            await this.validateAsync();
        }

        const value = await this.getValueAsync();
        await Promise.all(this.onChangeFuncs.map(func => {
            const result = func(value);
            return result && "then" in result ? result : new Promise<void>(resolve => resolve());
        }));
    }

    /**
     * 於元件上彈出一段訊息。
     * @param html 訊息內容，HTML 格式。
     * @returns 彈出所用的 Popover 物件。
     */
    async showMessageAsync(html: string): Promise<Popover | undefined> {
        if (!this.messageAnchor) {
            return;
        }

        if (this.popover) {
            await this.popover.setContentAsync(html);
            await this.popover.closeAsync();
        } else {
            this.popover = (await popoverController.buildAsync({
                target: this.messageAnchor,
                content: html,
                onlyTriggerByClick: false
            }))[0];
        }

        if (this.autoOpenMessage) {
            await this.popover.openAsync();
        }
        
        return this.popover;
    }

    /** 移除原件上彈出的 Popover。 */
    async removeMessageAsync(): Promise<void> {
        if (this.popover) {
            await popoverController.removeAsync(this.popover.id);
            this.popover = undefined;
        }
    }

    /**
     * 於元件上彈出一段警告訊息。
     * @param text 訊息內容，HTML 格式。
     * @returns 彈出所用的 Popover 物件。
     */
    showWarningAsync(text: string): Promise<Popover | undefined> {
        const html = `<div class=\"form-message warning form-theme-color\"><i class=\"${formFontawesomeIcons.warning} form-message-icon\"></i><span class=\"form-message-text\">${text}</span></div>`;
        return this.showMessageAsync(html);
    }

    /**
     * 於元件上彈出一段錯誤訊息。
     * @param text 訊息內容，HTML 格式。
     * @returns 彈出所用的 Popover 物件。
     */
    showErrorAsync(text: string): Promise<Popover | undefined> {
        const html = `<div class=\"form-message danger form-theme-color\"><i class=\"${formFontawesomeIcons.error} form-message-icon\"></i><span class=\"form-message-text\">${text}</span></div>`;
        return this.showMessageAsync(html);
    }

    /** 將元件設定為 highlight 模式，會在 container 上顯示黃色的背景。 */
    async showHighlightEffectAsync(show?: boolean): Promise<void> {
        if (show !== false) {
            this.container.classList.add("highlight");
        } else {
            this.container.classList.remove("highlight");
        }
    }

    /**
     * 將元件設定為警告模式，會在元件輸入框上顯示黃色框線，並彈出警告訊息。
     * @param show 是否啟動警告模式。
     * @param message 要顯示的警告訊息。
     */
    async showWarningEffectAsync(show?: boolean, message?: string): Promise<void> {
        this.validateWarning = message;
        if (show !== false) {
            this.container.classList.remove("invalid");
            this.container.classList.add("warning");
            if (message) {
                await this.showWarningAsync(message);
            }
        } else {
            this.container.classList.remove("warning");
            await this.removeMessageAsync();
        }
    }

    /**
     * 將元件設定為驗證失敗模式，會在元件輸入框上顯示紅色框線，並彈出驗證失敗訊息。
     * @param show 是否啟動驗證失敗模式。
     * @param message 要顯示的驗證失敗訊息。
     */
    async showInvalidEffectAsync(show?: boolean, message?: string): Promise<void> {
        this.validateError = message;
        if (show !== false) {
            this.container.classList.remove("warning");
            this.container.classList.add("invalid");
            if (message) {
                await this.showErrorAsync(message);
            }
        } else {
            this.container.classList.remove("invalid");
            await this.removeMessageAsync();
        }
    }

    addChangeFunc(func: ((value?: any) => void) | ((value?: any) => Promise<void>)): void {
        if (!this.onChangeFuncs) {
            this.onChangeFuncs = [];
        }

        this.onChangeFuncs.push(func);
    }

    getValidateWarning(): string | undefined {
        return this.validateWarning;
    }

    getValidateError(): string | undefined {
        return this.validateError;
    }
}