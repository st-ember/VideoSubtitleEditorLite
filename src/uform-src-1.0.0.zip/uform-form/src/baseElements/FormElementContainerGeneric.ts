import FormElementContainer from "./FormElementContainer";

export default abstract class FormElementContainerGeneric<TData extends { [name: string]: any }> extends FormElementContainer {
    abstract getValueAsync(): Promise<TData>;
    abstract setValueAsync(value: TData): Promise<void>;
}
