import { dataSourceController } from "controllers/DataSourceController";
import OptionItem from "models/OptionItem";
import PickerElementOptions from "options/PickerElementOptions";
import FormElementGeneric from "./FormElementGeneric";

export default abstract class PickerElementGeneric<TValue extends any> extends FormElementGeneric<TValue> implements PickerElementOptions {

    optionName?: string;
    defaultOptionText?: string;
    options: OptionItem[] = [];
    /** 預設狀態是否為未選擇。預設為 False，元件完成建立後會自動選擇第一個項目。 */
    allowEmpty?: boolean = false;

    constructor(options?: PickerElementOptions) {
        super(options);
        this.bindOptions(options);
    }

    protected async getOptionsAsync(): Promise<void> {
        if (!this.options) {
            this.options = this.optionName ? await dataSourceController.getSelectOptionsAsync(this.optionName, this.defaultOptionText) : [];
        }
    }
}
