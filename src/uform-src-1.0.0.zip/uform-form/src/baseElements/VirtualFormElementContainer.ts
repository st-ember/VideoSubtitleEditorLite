import VirtualFormElementContainerOptions from "options/VirtualFormElementContainerOptions";
import FormElement from "./FormElement";
import FormElementContainer from "./FormElementContainer";

export default class VirtualFormElementContainer extends FormElement implements VirtualFormElementContainerOptions {

    parent: FormElementContainer = undefined!;
    buildChildrenFunc?: (virtualFormElementContainer: VirtualFormElementContainer) => Promise<void>;

    formElements: FormElement[] = [];

    private _formElementHiddenStates: { [id: string]: boolean | undefined } = {};

    constructor(options?: VirtualFormElementContainerOptions) {
        super(options);
        this.bindOptions(options);
    }

    static fromAsync(options: VirtualFormElementContainerOptions): Promise<VirtualFormElementContainer> {
        return <Promise<VirtualFormElementContainer>>(new VirtualFormElementContainer(options).buildAsync());
    }

    protected async buildContainerAsync(): Promise<void> {
        this.container = this.parent.container;
    }

    protected buildLabel(text: string): void {
        this.labelElement = this.parent.labelElement;
    }

    protected async buildElementAsync(): Promise<void> {
        this.element = this.parent.element;
        await this.buildChildrenAsync();
    }

    async buildChildrenAsync(): Promise<void> {
        if (this.buildChildrenFunc) {
            await this.buildChildrenFunc(this);
        }
    }

    async rebuildAsync(): Promise<void> {
        for (let i = 0; i < this.formElements.length; i++) {
            const child = this.formElements[i];
            await child.rebuildAsync();
        }
        await this.clearAsync();
    }

    async deleteAsync(): Promise<void> {
        for (let i = 0; i < this.formElements.length; i++) {
            const child = this.formElements[i];
            await child.deleteAsync();
        }
    }

    /** 隱藏此元件。 */
    async hideAsync(): Promise<void> {
        for (let i = 0; i < this.formElements.length; i++) {
            if (!this.hide) {
                this._formElementHiddenStates[this.formElements[i].id] = this.formElements[i].hide;
            }
            await this.formElements[i].hideAsync();
        }

        this.hide = true;
    }

    /** 如此元件狀態為隱藏中，顯示此元件。 */
    async showAsync(): Promise<void> {
        for (let i = 0; i < this.formElements.length; i++) {
            const storedValue = this._formElementHiddenStates[this.formElements[i].id];
            if (storedValue !== true) {
                await this.formElements[i].showAsync();
            }
        }

        this.hide = false;
    }

    async setDisableAsync(disable?: boolean): Promise<void> {
        this.disabled = disable !== false;
        for (let i = 0; i < this.formElements.length; i++) {
            await this.formElements[i].setDisableAsync(disable);
        }
    }

    /** 設定此元件是否允許彈出 Popover 訊息。 */
    setAutoOpenMessage(enable?: boolean): void {
        this.autoOpenMessage = enable !== false;
        this.formElements.forEach(child => child.setAutoOpenMessage(enable));
    }

    async validateAsync(): Promise<boolean> {
        let valid = true;
        for (let i = 0; i < this.formElements.length; i++) {
            const childValid = await this.formElements[i].validateAsync();
            if (!childValid) {
                valid = false;
            }
        }   
        
        this.validated = true;

        return valid;
    }

    async clearAsync(): Promise<void> {
        for (let i = 0; i < this.formElements.length; i++) {
            const child = this.formElements[i];
            await child.clearAsync();
        }
    }

    async getValueAsync(): Promise<{ [name: string]: any }> {
        const value: { [name: string]: any } = {};
        for (let i = 0; i < this.formElements.length; i++) {
            const child = this.formElements[i];
            if (!!child.name) {
                value[child.name] = await child.getValueAsync();
            }
        }

        return value;
    }

    async setValueAsync(value: { [name: string]: any }): Promise<void> {
        for (let i = 0; i < this.formElements.length; i++) {
            const child = this.formElements[i];
            if (!!child.name) {
                await child.setValueAsync(value ? value[child.name] : undefined);
            }
        }
    }

    async appendAsync(formElement: FormElement): Promise<void>;
    async appendAsync(formElement: HTMLElement): Promise<void>;
    async appendAsync(formElement: Promise<FormElement>): Promise<void>;
    async appendAsync(formElement: Promise<HTMLElement>): Promise<void>;
    async appendAsync(formElement: FormElement | HTMLElement | Promise<FormElement> | Promise<HTMLElement>): Promise<void> {
        let element: FormElement | HTMLElement;
        if ("then" in formElement) {
            // Is Promise type.
            element = await formElement;
        } else {
            element = formElement;
        }

        if (element instanceof FormElement) {
            this.formElements.push(element);
            this.element.appendChild(element.container);
            await element.onAppendAsync();
        } else {
            this.element.appendChild(element);
        }
    }

    async insertBeforeAsync(formElement: FormElement, relateChild: FormElement | HTMLElement): Promise<void>;
    async insertBeforeAsync(formElement: HTMLElement, relateChild: FormElement | HTMLElement): Promise<void>;
    async insertBeforeAsync(formElement: Promise<FormElement>, relateChild: FormElement | HTMLElement): Promise<void>;
    async insertBeforeAsync(formElement: Promise<HTMLElement>, relateChild: FormElement | HTMLElement): Promise<void>;
    async insertBeforeAsync(formElement: FormElement | HTMLElement | Promise<FormElement> | Promise<HTMLElement>, relateChild: FormElement | HTMLElement): Promise<void> {
        let element: FormElement | HTMLElement;
        if ("then" in formElement) {
            // Is Promise type.
            element = await formElement;
        } else {
            element = formElement;
        }

        const relateHTMLElement = relateChild instanceof FormElement ? relateChild.container : relateChild;
        if (element instanceof FormElement) {
            const index = this.formElements.findIndex(child => child.container.isSameNode(relateHTMLElement));
            this.formElements.splice(index, 0, element);

            this.element.insertBefore(element.container, relateHTMLElement);
            await element.onAppendAsync();
        } else {
            this.element.insertBefore(element, relateHTMLElement);
        }
    }

    getElement(name: string): FormElement | undefined {
        const matchs = this.formElements.filter(o => o.name === name);
        return matchs.length > 0 ? matchs[0] : undefined;
    }
}