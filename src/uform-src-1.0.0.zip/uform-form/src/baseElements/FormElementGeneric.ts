import FormElementOptions from "options/FormElementOptions";
import FormElement from "./FormElement";

export default abstract class FormElementGeneric<TValue extends any> extends FormElement {

    constructor(options?: FormElementOptions) {
        super(options);
    }

    abstract getValueAsync(): Promise<TValue>;
    abstract setValueAsync(value: TValue): Promise<void>;
}