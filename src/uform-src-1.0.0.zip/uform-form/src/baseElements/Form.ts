import FormElementContainer from "./FormElementContainer";

export default abstract class Form extends FormElementContainer {

    element: HTMLElement;

    constructor(element?: HTMLElement) {
        super();
        this.element = element ? element : document.createElement("div");
    }

    buildContainer(): void {
        this.container = <any>this.element;
    }

    protected buildLabel(): void {
        this.labelElement = undefined;
    }

    protected async buildElementAsync(): Promise<void> {
        this.element.classList.add("form-element-container");
        this.element.style.pointerEvents = "none";
        this.element.style.opacity = "0.6";

        if (this.width !== undefined && this.width !== null) {
            this.element.style.width = typeof this.width === "number" ? `${this.width}px` : this.width;
        }

        await this.buildChildrenAsync();

        this.element.style.pointerEvents = "";
        this.element.style.opacity = "";
    }

    async deleteAsync(): Promise<void> {
        for (let i = 0; i < this.formElements.length; i++) {
            const child = this.formElements[i];
            await child.deleteAsync();
        }
        this.element.remove();
    }

    async getValueAsync(): Promise<any> {
        const value: { [name: string]: any } = {};
        for (let i = 0; i < this.formElements.length; i++) {
            const child = this.formElements[i];
            if (!!child.name) {
                value[child.name] = await child.getValueAsync();
            }
        }

        return <any>value;
    }

    async setValueAsync(value: any): Promise<void> {
        for (let i = 0; i < this.formElements.length; i++) {
            const child = this.formElements[i];
            if (!!child.name) {
                await child.setValueAsync(value[child.name]);
            }
        }
    }

    async hideAsync(): Promise<void> {
        this.element.style.display = "none";
    }

    async showAsync(): Promise<void> {
        this.element.style.display = "";
    }

    setEdited(edited: boolean): void {
        for (let i = 0; i < this.formElements.length; i++) {
            const child = this.formElements[i];
            child.edited = edited;
        }
    }

    isEdited(): boolean {
        if (this.formElements.length > 0) {
            return this.formElements.filter(o => o.edited).length > 0;
        } else {
            return false;
        }
    }
}