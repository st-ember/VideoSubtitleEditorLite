import Form from "./Form";

export default abstract class FormGeneric<TData extends { [name: string]: any; }> extends Form {

    constructor(element?: HTMLElement) {
        super(element);
    }

    async getValueAsync(): Promise<TData> {
        return <TData><unknown>await super.getValueAsync();
    }

    setValueAsync(value: TData): Promise<void> {
        return super.setValueAsync(value);
    }
}
