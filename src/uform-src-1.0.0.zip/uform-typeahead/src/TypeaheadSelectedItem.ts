import Typeahead from "Typeahead";
import { typeaheadController } from "TypeaheadController";
import TypeaheadOption from "TypeaheadOption";
import { TypeaheadOptionItem } from "TypeaheadOptions";

export default class TypeaheadSelectedItem {
    value?: string;
    text: string = "";
    subText: string = "";

    typeahead: Typeahead;
    option: TypeaheadOption;
    menuElement: HTMLSpanElement = document.createElement("span");
    deleteAnchor: HTMLAnchorElement = document.createElement("a");

    constructor(typeahead: Typeahead, option: TypeaheadOption) {
        this.typeahead = typeahead;
        this.option = option;
        this._updateOptions({ value: option.value, text: option.text, subText: option.subText });
    }

    init(): void {
        this._initMenuItem();
        this._initEvents();
    }

    private _updateOptions(options: TypeaheadOptionItem): void {
        this.value = options.value;
        this.text = options.text ?? "";

        if (options.subText) {
            this.subText = options.subText;
        }
    }

    update(): void {
        
    }

    remove(): void {
        this.menuElement.remove();
    }

    private _initMenuItem(): void {
        this.menuElement.className = "selected-item";
        this.menuElement.innerHTML = `<span class="selector-text">${this.text}</span>` + 
            (this.subText ? `<span class="selector-subtext">${this.subText}</span>` : "");

        this.deleteAnchor.className = "delete-button"
        this.deleteAnchor.innerHTML = typeaheadController.deleteIconSvg;
        this.menuElement.insertBefore(this.deleteAnchor, this.menuElement.firstChild);
    }

    private _initEvents(): void {
        this.deleteAnchor.addEventListener("click", () => this.option.set(false));
        this.menuElement.addEventListener("click", () => this.typeahead.element.focus());
    }
}