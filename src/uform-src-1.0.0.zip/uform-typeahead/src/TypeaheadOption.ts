import Typeahead from "Typeahead";
import { typeaheadController } from "TypeaheadController";
import { TypeaheadOptionItem } from "TypeaheadOptions";
import TypeaheadSelectedItem from "TypeaheadSelectedItem";

export default class TypeaheadOption {
    value?: string;
    text: string = "";
    subText: string = "";
    selected: boolean = false;

    typeahead: Typeahead;
    menuElement: HTMLSpanElement = document.createElement("span");
    selectedItem?: TypeaheadSelectedItem;

    onHoverFuncs: ((option: TypeaheadOption) => void)[] = [];
    onBlurFuncs: ((option: TypeaheadOption) => void)[] = [];

    constructor(typeahead: Typeahead, options: TypeaheadOptionItem) {
        this.typeahead = typeahead;
        this._updateOptions(options);
    }

    async init(): Promise<void> {
        this._initMenuItem();
        this._initEvents();
    }

    private _updateOptions(options: TypeaheadOptionItem): void {
        this.value = options.value;
        this.text = options.text ?? "";

        if (options.subText) {
            this.subText = options.subText;
        }
        
        if (options.selected) {
            this.selected = options.selected;
        }
    }

    update(): void {
        this._updateElement();
    }

    modifyText(html: string): void {
        if (this.text === html) { return; }
        this.text = html;
        this.menuElement.innerHTML = "<span class=\"selector-text\">" + this.text + "</span>" +
            (this.subText ? "<span class=\"selector-subtext\">" + this.subText + "</span>" : "") + typeaheadController.checkIconSvg;

        if (this.selected) {
            this.typeahead.updateAsync();
        }
    }

    modifySubText(html: string): void {
        if (this.subText === html) { return; }
        this.subText = html;
        this.menuElement.innerHTML = "<span class=\"selector-text\">" + this.text + "</span>" +
            (this.subText ? "<span class=\"selector-subtext\">" + this.subText + "</span>" : "") + typeaheadController.checkIconSvg;

        if (this.selected) {
            this.typeahead.updateAsync();
        }
    }

    remove(): void {
        this.menuElement.remove();
    }

    private _initMenuItem(): void {
        this.menuElement.className = "selector-option";
        this.menuElement.innerHTML = "<span class=\"selector-text\">" + this.text + "</span>" +
            (this.subText ? "<span class=\"selector-subtext\">" + this.subText + "</span>" : "") + typeaheadController.checkIconSvg;

        if (this.typeahead.multiple) {
            const exists = this.typeahead.selectedItems.filter(item => item.value === this.value);
            if (exists.length > 0) {
                const selectedItem = exists[0];
                selectedItem.option = this;
                this.selectedItem = selectedItem;
                
                this.selected = true;
                this._buildSelectedItem();
                this.menuElement.classList.add("selector-hidden");
            }
        }
    }

    private _initEvents(): void {
        this.menuElement.addEventListener("click", () => this.clickAsync());
        this.menuElement.addEventListener("mouseenter", () => this.onHover());
        this.menuElement.addEventListener("mouseleave", () => this.onBlur());
    }

    private _updateElement(): void {
        if (this.selected) {
            this.menuElement.classList.add("selector-selected");
        } else {
            this.menuElement.classList.remove("selector-selected");
        }
    }

    async clickAsync(update?: boolean): Promise<void> {
        if (this.typeahead.multiple) {
            this.typeahead.element.focus();
            this.set(!this.selected);
        } else {
            const selected = !this.selected;
            this.typeahead.setAll(false);
            this.set(selected);
        }

        if (update !== false) {
            await this.typeahead.changeAsync();
            if (!this.typeahead.multiple) {
                await this.typeahead.triggerAsync();
            }
        }
    }

    onHover(): void {
        this.onHoverFuncs.forEach(func => func(this));
    }

    onBlur(): void {
        this.onBlurFuncs.forEach(func => func(this));
    }

    focus(): void {
        this.menuElement.classList.add("focus");
    }

    blur(): void {
        this.menuElement.classList.remove("focus");
    }

    set(selected: boolean): void {
        if (this.selected !== selected) {
            if (selected) {
                if (this.typeahead.isAllowSelect()) {
                    this.typeahead.selectedCount++;
                    this.selected = true;

                    if (this.typeahead.multiple) {
                        this._buildSelectedItem();
                        this.menuElement.classList.add("selector-hidden");
                    }
                } else {
                    this.typeahead.showWarning(true);
                }
            } else {
                this.typeahead.selectedCount--;
                this.selected = false;
                this.menuElement.classList.remove("selector-hidden");
                this._deleteSelectedItemAsync();
            }
        }
    }

    private _buildSelectedItem(): void {
        if (!this.selectedItem) {
            this.selectedItem = new TypeaheadSelectedItem(this.typeahead, this);
            this.selectedItem.init();
            this.typeahead.dropdown?.head.appendChild(this.selectedItem.menuElement);
            this.typeahead.selectedItems.push(this.selectedItem);
        }
    }

    private async _deleteSelectedItemAsync(): Promise<void> {
        if (this.selectedItem) {
            this.typeahead.selectedItems = this.typeahead.selectedItems.filter(item => item.value !== this.value);
            this.selectedItem.remove();
            this.selectedItem = undefined;
            await this.typeahead.updateAsync();
        }
    }
}