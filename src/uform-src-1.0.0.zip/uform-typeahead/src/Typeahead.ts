import TypeaheadOption from "TypeaheadOption";
import TypeaheadOptions, { TypeaheadSearchResult, TypeaheadOptionItem, TypeaheadSelectOption } from "TypeaheadOptions";
import TypeaheadSelectedItem from "TypeaheadSelectedItem";
import dropdownController, { Dropdown } from "uform-dropdown";

export default class Typeahead {

    multiple: boolean = false;
    max: number = 0;
    /** 允許在沒有選擇搜尋結果的狀態下保留輸入的文字當作值。 */
    directInput?: boolean;
    /** 呈現多選文字時，每個選項文字間用來分隔的字元。 */
    splittor: string = ", ";
    /** 只有在關閉下拉選單時才觸發 Change 事件。 */
    changeWhenClose: boolean = false;
    /** 指定輸入搜尋文字時停止多長的時間會啟動搜尋。預設為一秒鐘。 */
    searchDelayTime: number = 1000;
    /** 進行搜尋時使用的非同步方法。 */
    searchFunc?: (text: string) => Promise<TypeaheadSearchResult>;

    options: TypeaheadOptions;

    dropdown?: Dropdown;
    loadingMessageGroup?: HTMLDivElement;
    warningGroup?: HTMLDivElement;
    messageGroup?: HTMLDivElement;
    errorMessageGroup?: HTMLDivElement;

    id: number = -1;
    element: HTMLInputElement;
    selectedCount: number = 0;
    warningShowing: boolean = false;
    searchText: string = "";

    children: TypeaheadOption[] = [];
    selectedItems: TypeaheadSelectedItem[] = [];
    onChangeFuncs: (() => void)[] = [];

    private _focused?: TypeaheadOption;
    private _pendingChanges: boolean = false;
    private _inputCheckTimer?: number;
    private _focusing: boolean = false;
    private _mouseEntering: boolean = false;

    constructor(element: HTMLInputElement, id: number, options?: TypeaheadOptions) {
        this.id = id;
        this.element = element;
        this.options = options ?? <any>{};
        this._updateOptions();
    }

    init(): void {
        this._initElement();
        this._initDropdown();
        this._initChildren();
        this._initItems();
        this._initLoadingMessage();
        this._initMessage();
        this._initErrorMessage();
        this._initWarning();
        this._initHooks();
    }

    async updateAsync(): Promise<void> {
        this._updateOptions();
        this._processSelected();
        this._updateChildren();
        this._updateWarning();
        await this._updateDropdownAsync();
    }

    removeAsync(): Promise<void> {
        return dropdownController.removeAsync(this.element, "typeahead");
    }

    async changeAsync(): Promise<void> {
        await this.updateAsync();
        if (!this.changeWhenClose) {
            this.onChangeFuncs.forEach(func => func());
        } else {
            this._pendingChanges = true;
        }
    }

    private _initElement(): void {
        this.element.classList.add("typeahead-trigger");

        let count = 0;
        let tempValue: string | undefined = undefined;
        this.element.addEventListener("focus", () => {
            this._focusing = true;
            if (!this._inputCheckTimer) {
                this.dropdown?.openAsync(true);
                this.element.value = this.searchText;
                this._inputCheckTimer = setInterval(async () => {
                    const value = this.element.value;
                    if (this.searchText !== value) {
                        count++;
                        if (count > 20) {
                            tempValue = value;
                            this.searchText = value;
                            count = 0;
                            await this._searchAsync(value);
                        }
                    } else {
                        count = 0;
                    }

                    if (tempValue !== value) {
                        count = 0;
                        tempValue = value;
                    }
                }, 100);
            }
        });

        this.element.addEventListener("blur", () => {
            this._focusing = false;
            if (this._inputCheckTimer) {
                clearInterval(this._inputCheckTimer);
                this._inputCheckTimer = undefined;
            }

            if (!this._mouseEntering && this.dropdown?.opened) {
                this.dropdown?.openAsync(false);
            }
        });
    }

    private _initDropdown(): void {
        if (!this.dropdown) {
            this.dropdown = dropdownController.add({ 
                tag: "typeahead", 
                target: this.element, 
                disableTargetEvent: true
            });

            this.dropdown.onOpenStatusChangeFuncs.push(() => {
                if (this._pendingChanges && this.changeWhenClose) {
                    this.onChangeFuncs.forEach(func => func());
                }
            });

            this.dropdown.onMouseEnterFuncs.push(() => this._mouseEntering = true);
            this.dropdown.onMouseLeaveFuncs.push(() => {
                this._mouseEntering = false;
                if (!this._focusing && this.dropdown?.opened) {
                    this.dropdown?.openAsync(false);
                }
            });
        }
    }

    private _initChildren(): void {
        const children = [];
        if (this.options && this.options.items) {
            for (let i = 0; i < this.options.items.length; i++) {
                const childOptions = this.options.items[i];
                const option = new TypeaheadOption(this, childOptions);
                option.init();
                children.push(option);
            }
        }

        this.children = children;
    }

    private _initItems(): void {
        this.dropdown?.clearBody();
        this.children.forEach(child => this.dropdown?.body.appendChild(child.menuElement));
    }

    private _initLoadingMessage(): void {
        if (!this.loadingMessageGroup) {
            const loadingMessageGroup = document.createElement("div");
            loadingMessageGroup.className = "selector-loading-group selector-hidden";
            loadingMessageGroup.innerText = "載入中...";
            this.loadingMessageGroup = loadingMessageGroup;
            this.dropdown?.head.appendChild(loadingMessageGroup);
        }
    }

    private _initMessage(): void {
        if (!this.messageGroup) {
            const messageGroup = document.createElement("div");
            messageGroup.className = "selector-message-group selector-hidden";
            messageGroup.innerText = "沒有符合的項目";
            this.messageGroup = messageGroup;
            this.dropdown?.head.appendChild(messageGroup);
        }
    }

    private _initErrorMessage(): void {
        if (!this.errorMessageGroup) {
            const errorMessageGroup = document.createElement("div");
            errorMessageGroup.className = "selector-error-group selector-hidden";
            errorMessageGroup.innerText = "";
            this.errorMessageGroup = errorMessageGroup;
            this.dropdown?.head.appendChild(errorMessageGroup);
        }
    }

    private _initWarning(): void {
        if (!this.warningGroup) {
            const warningGroup = document.createElement("div");
            warningGroup.className = "selector-warning-group selector-hidden";
            warningGroup.innerText = "";
            this.warningGroup = warningGroup;
            this.dropdown?.head.appendChild(warningGroup);
        }
    }

    private _initHooks(): void {
        this.dropdown?.onDownKeyPressFuncs.push(() => this.focusDown());
        this.dropdown?.onUpKeyPressFuncs.push(() => this.focusUp());
        this.dropdown?.onEnterKeyPressFuncs.push(() => {
            if (this._focused) {
                this._focused.clickAsync();
            }
        });

        this.children.forEach(child => {
            child.onHoverFuncs.push(c => this.onChildFocus(c));
            child.onBlurFuncs.push(c => this.onChildBlur(c));
        });

        if (this.options.onChange) {
            this.onChangeFuncs.push(() => this.options.onChange!(this));
        }

        this.dropdown?.onOpenStatusChangeFuncs.push(async () => {
            if (this.dropdown?.opened) {
                this.element.classList.add("menu-opened");
                this.element.value = this.searchText ?? "";
                if (this.options.onOpen) {
                    this.options.onOpen(this);
                }

                this.element.focus();

                if (!this.searchText && this.children.length === 0) {
                    this._showMessage(true, "於上方輸入文字開始搜尋");
                    this.dropdown.element.style.minWidth = `${this.element.clientWidth}px`;
                    this._updateDropdownAsync();
                }
            } else {
                if (this._inputCheckTimer) {
                    clearInterval(this._inputCheckTimer);
                    this._inputCheckTimer = undefined;
                }

                this.element.classList.remove("menu-opened");
                
                if (this.searchText !== this.element.value) {
                    this.searchText = this.element.value;

                    if (this.directInput && !this.searchText) {
                        this.children.forEach(child => child.set(false));
                    }

                    await this.updateAsync();
                    if (this.changeWhenClose) {
                        this.onChangeFuncs.forEach(func => func());
                    }
                }

                const selectedTexts = this.getArraySelectedText();
                if (selectedTexts.length > 0) {
                    this.element.value = selectedTexts.join(this.splittor ?? "");
                } else if (!this.directInput) {
                    this.element.value = "";
                }
                
                this._updateWarning();
                if (this.options.onClose) {
                    this.options.onClose(this);
                }

                if (this._focusing) {
                    this.element.blur();
                }
            }
        });
    }

    private _updateOptions(): void {
        if (Object.keys(this.options).length > 0) {
            if (!this.element.multiple && this.options.multiple === true) {
                this.element.multiple = true;
            }

            if (!this.element.hasAttribute("data-direct-input") && this.options.directInput !== undefined && this.options.directInput !== null) {
                this.element.setAttribute("data-direct-input", this.options.directInput ? "true" : "false");
            }

            if (!this.element.hasAttribute("data-splittor") && this.options.splittor !== undefined && this.options.splittor !== null) {
                this.element.setAttribute("data-splittor", String(this.options.splittor));
            }

            if (!this.element.hasAttribute("data-max") && this.options.max !== undefined && this.options.max !== null && this.options.max >= 0) {
                this.element.setAttribute("data-max", String(this.options.max));
            }

            if (!this.element.hasAttribute("data-search-delay") && this.options.searchDelayTime !== undefined && this.options.searchDelayTime !== null && this.options.searchDelayTime >= 0) {
                this.element.setAttribute("data-search-delay", String(this.options.searchDelayTime));
            }

            this.changeWhenClose = this.options.changeWhenClose === true;
            this.searchFunc = this.options.searchFunc;
        } else {
            this.options = { input: this.element };
        }

        this.multiple = this.element.multiple;

        if (this.dropdown) {
            if (this.multiple) {
                this.dropdown.element.classList.add("selector-multiple");
            } else {
                this.dropdown.element.classList.remove("selector-multiple");
            }
        }

        if (this.element.hasAttribute("data-direct-input")) {
            this.directInput = this.element.getAttribute("data-direct-input")!.toLowerCase() === "true";
        }

        if (this.element.hasAttribute("data-splittor")) {
            this.splittor = this.element.getAttribute("data-splittor") ?? ", ";
        }
        
        if (this.element.hasAttribute("data-max")) {
            const dataMax = Number(this.element.getAttribute("data-max"));
            this.max = !isNaN(dataMax) && dataMax >= 0 ? dataMax : 0;
        }

        if (this.element.hasAttribute("data-search-delay")) {
            const searchDelayTime = Number(this.element.getAttribute("data-search-delay"));
            this.max = !isNaN(searchDelayTime) && searchDelayTime >= 0 ? searchDelayTime : 1000;
        }
    }

    private async _updateDropdownAsync(): Promise<void> {
        await this.dropdown?.updateAsync();
    }

    private _updateChildren(): void {
        this.children.forEach(child => child.update());
    }

    private _updateWarning(): void {
        if (this.warningGroup) {
            if (this.warningShowing) {
                this.warningGroup.innerText = "選擇的數量不可超過 " + this.max + " 個";
                this.warningGroup.classList.remove("selector-hidden");
                this.warningShowing = false;
            } else {
                this.warningGroup.classList.add("selector-hidden");
            }
        }
    }

    private _processSelected(): void {
        if (this.multiple && this.max !== 0) {
            const selectedChildren = this.selectedItems;
            let selectedCount = 0;
            for (let i = 0; i < selectedChildren.length; i++) {
                if (i >= this.max) {
                    const selectedItem = selectedChildren[i];
                    selectedItem.option.set(false);
                } else {
                    selectedCount++;
                }
            }
            this.selectedCount = selectedCount;
        } else if (!this.multiple) {
            this.selectedCount = 1;
        }
    }

    setAll(selected: boolean): void {
        this.children.forEach(child => child.set(selected));
    }

    protected async _searchAsync(text: string): Promise<void> {
        if (text) {
            const searchText = text.toLowerCase();

            if (this.dropdown) {
                this.dropdown.element.style.minWidth = `${this.element.clientWidth}px`;
            }

            await this.clearChildAsync();

            this.showWarning(false);
            this._showMessage(false);
            this._showErrorMessage(false);
            this._showLoadingMessage(true);
            await this._updateDropdownAsync();

            const result = this.searchFunc ? await this.searchFunc(searchText) : { success: true, items: this.options.items ? this.options.items : [] };

            this._showLoadingMessage(false);

            if (result && result.success) {
                if (result.items.length > 0) {
                    this.appendOptions(result.items);
                } else {
                    this._showMessage(true, "沒有符合的項目");
                }
            } else {
                this._showErrorMessage(true, result && result.message ? `發生錯誤：${result.message}` : "發生錯誤");
            }

            await this.changeAsync();
        }

        await this._updateDropdownAsync();
    }

    async triggerAsync(): Promise<void> {
        if (!this.element.disabled) {
            await this.dropdown?.openAsync(!this.dropdown.opened);
        } else {
            await this.dropdown?.openAsync(false);
        }
    }

    isAllowSelect(): boolean {
        this._processSelected();
        return !this.multiple || this.max === 0 || this.max > 0 && this.selectedCount < this.max;
    }

    protected _showLoadingMessage(show: boolean): void {
        if (!this.loadingMessageGroup || !this.dropdown) { return; }
        if (show) {
            this.loadingMessageGroup.classList.remove("selector-hidden");
            this.dropdown.head.style.borderBottom = "none";
            this.dropdown.bottom.style.borderTop = "none";
        } else {
            this.loadingMessageGroup.classList.add("selector-hidden");
            this.dropdown.head.style.borderBottom = "";
            this.dropdown.bottom.style.borderTop = "";
        }
    }

    protected _showMessage(show: boolean, message?: string): void {
        if (!this.messageGroup || !this.dropdown) { return; }
        if (show) {
            this.messageGroup.innerHTML = message ?? "";
            this.messageGroup.classList.remove("selector-hidden");
            this.dropdown.head.style.borderBottom = "none";
            this.dropdown.bottom.style.borderTop = "none";
        } else {
            this.messageGroup.classList.add("selector-hidden");
            this.dropdown.head.style.borderBottom = "";
            this.dropdown.bottom.style.borderTop = "";
        }
    }

    protected _showErrorMessage(show: boolean, message?: string): void {
        if (!this.errorMessageGroup || !this.dropdown) { return; }
        if (show) {
            this.errorMessageGroup.innerHTML = message ?? "";
            this.errorMessageGroup.classList.remove("selector-hidden");
            this.dropdown.head.style.borderBottom = "none";
            this.dropdown.bottom.style.borderTop = "none";
        } else {
            this.errorMessageGroup.classList.add("selector-hidden");
            this.dropdown.head.style.borderBottom = "";
            this.dropdown.bottom.style.borderTop = "";
        }
    }

    showWarning(value: boolean): void {
        this.warningShowing = value !== false;
    }

    getValue(): string | (string | undefined)[] | undefined {
        const values = this.multiple ? 
            this.selectedItems.map(item => item.value) : 
            this.children.filter(child => child.selected).map(child => child.value);

        if (values.length > 0) {
            return this.multiple ? values : values[0];
        } else {
            return this.directInput && this.searchText ? (this.multiple ? [undefined] : undefined) : (this.multiple ? [] : undefined);
        }
    }

    getArrayValue(): (string | undefined)[] {
        const values = this.multiple ? 
            this.selectedItems.map(item => item.value) : 
            this.children.filter(child => child.selected).map(child => child.value);

        if (values.length > 0) {
            return this.multiple ? values : [values[0]];
        } else {
            return this.directInput && this.searchText ? [undefined] : [];
        }
    }

    getSingleValue(): string | undefined {
        const values = this.multiple ? 
            this.selectedItems.map(item => item.value) : 
            this.children.filter(child => child.selected).map(child => child.value);

        if (values.length > 0) {
            return values[0];
        } else {
            return undefined;
        }
    }

    getSelectedText(): string | (string | undefined)[] | undefined {
        const texts = this.multiple ? 
            this.selectedItems.map(item => item.text) : 
            this.children.filter(child => child.selected).map(child => child.text);

        if (texts.length > 0) {
            return this.multiple ? texts : texts[0];
        } else {
            return this.directInput && this.searchText ? (this.multiple ? [this.searchText] : this.searchText) : (this.multiple ? [] : undefined);
        }
    }

    getArraySelectedText(): string[] {
        const texts = this.multiple ? 
            this.selectedItems.map(item => item.text) : 
            this.children.filter(child => child.selected).map(child => child.text);

        if (texts.length > 0) {
            return this.multiple ? texts : [texts[0]];
        } else {
            return this.directInput && this.searchText ? [this.searchText] : [];
        }
    }

    getSingleSelectedText(): string | undefined {
        const texts = this.multiple ? 
            this.selectedItems.map(item => item.text) : 
            this.children.filter(child => child.selected).map(child => child.text);
            
        if (texts.length > 0) {
            return texts[0];
        } else {
            return this.directInput && this.searchText ? this.searchText : undefined;
        }
    }

    async setValueAsync(value: string | string[]): Promise<void> {
        const newValues = value ? (typeof value === "string" ? [value] : value) : [];
        if (this.multiple) {
            this.children.forEach(child => {
                const isMatchs = newValues.indexOf(child.value ?? "") >= 0;
                if (child.selected !== isMatchs) {
                    child.set(isMatchs);
                }
            });
        } else {
            const matchChildren = this.children.filter(child => newValues.indexOf(child.value ?? "") >= 0);
            if (matchChildren.length > 0) {
                matchChildren[0].set(true);
            }
        }

        await this.changeAsync();
    }

    async setSelectedOptionAsValueAsync(value: TypeaheadSelectOption): Promise<void>;
    async setSelectedOptionAsValueAsync(value: TypeaheadSelectOption[]): Promise<void>;
    async setSelectedOptionAsValueAsync(arg: TypeaheadSelectOption | TypeaheadSelectOption[]): Promise<void> {
        if (arg instanceof Array) {
            arg.forEach(value => this.appendOption(value.value, value.text, value.subText));

            if (this.multiple) {
                this.setAll(true);
            } else {
                this.children.forEach(child => {
                    const isMatchs = arg[0].value === child.value;
                    if (child.selected !== isMatchs) {
                        child.set(isMatchs);
                    }
                });
            }

            const selectedTexts = this.getArraySelectedText();
            if (selectedTexts.length > 0) {
                this.element.value = selectedTexts.join(this.splittor ?? "");
            }
        } else {
            if (!arg || !arg.text) { return; }

            this.appendOption(arg.value, arg.text, arg.subText);
            this.searchText = arg.text;
            this.element.value = arg.text;
            this.children.forEach(child => {
                const isMatchs = arg.value === child.value;
                if (child.selected !== isMatchs) {
                    child.set(isMatchs);
                }
            });
        }

        await this.changeAsync();
    }

    async setDisableAsync(value?: boolean): Promise<void> {
        this.element.disabled = value !== false;

        if (this.dropdown) {
            this.dropdown.disabled = value !== false;

            if (this.dropdown.opened) {
                await this.dropdown.openAsync(false);
            }
        }
    }

    cancelFocus(): void {
        if (this._focused) {
            this._focused.blur();
            this._focused = undefined;
        }
    }

    focusDown(): void {
        const next = this._findNext(this._focused);

        if (this._focused) {
            this._focused.blur();
            this._focused = undefined;
        }

        if (next) {
            this._focused = next;
            this._focused.focus();
        }
    }

    focusUp(): void {
        const prev = this._findPrev(this._focused);

        if (this._focused) {
            this._focused.blur();
            this._focused = undefined;
        }

        if (prev) {
            this._focused = prev;
            this._focused.focus();
        }
    }

    onChildFocus(child: TypeaheadOption): void {
        if (this._focused) {
            this._focused.blur();
        }

        this._focused = child;
        this._focused.focus();
    }

    onChildBlur(child: TypeaheadOption): void {
        child.blur();

        if (this._focused && this._focused === child) {
            this._focused.blur();
            this._focused = undefined;
        }
    }

    private _findChildIndex(child: TypeaheadOption): number {
        return this.children.findIndex(o => o === child);
    }

    private _findNext(current?: TypeaheadOption): TypeaheadOption {
        if (current) {
            const index = this._findChildIndex(current);
            if (index >= 0 && index + 1 < this.children.length) {
                return this.children[index + 1];
            }
        }

        return this.children[0];
    }

    private _findPrev(current?: TypeaheadOption): TypeaheadOption {
        if (current) {
            const index = this._findChildIndex(current);
            if (index > 0 && index < this.children.length) {
                return this.children[index - 1];
            }
        }

        return this.children[this.children.length - 1];
    }

    getChild(index: number): TypeaheadOption | undefined {
        return this.children.length <= index || index < 0 ? undefined : this.children[index];
    }

    getOption(value: string): TypeaheadOption | undefined;
    getOption(index: number): TypeaheadOption | undefined;
    getOption(value: string | number): TypeaheadOption | undefined {
        if (typeof value === "string") {
            const matchs = this.children.filter(o => o.value === value);
            return matchs.length > 0 ? matchs[0] : undefined;
        } else {
            return this.children.length <= value || value < 0 ? undefined : this.children[value];
        }
    }

    getOptionIndex(value: string): number {
        return this.children.findIndex(o => o.value === value);
    }

    appendOption(value?: string, html?: string, subtext?: string): TypeaheadOption {
        const option = new TypeaheadOption(this, {
            value,
            text: html ?? "",
            subText: subtext ?? ""
        });
        option.init();

        this.dropdown?.body.appendChild(option.menuElement);
        this.children.push(option);

        option.onHoverFuncs.push(c => this.onChildFocus(c));
        option.onBlurFuncs.push(c => this.onChildBlur(c));

        return option;
    }

    appendOptions(items: TypeaheadOptionItem[]): TypeaheadOption[] {
        return items ? items.map(item => this.appendOption(item.value, item.text, item.subText)) : [];
    }

    insertOption(index: number, value?: string, html?: string, subtext?: string): TypeaheadOption {
        const option = new TypeaheadOption(this, {
            value,
            text: html ?? "",
            subText: subtext ?? ""
        });
        option.init();

        const refChild = this.getChild(index);
        if (refChild) {
            this.dropdown?.body.insertBefore(option.menuElement, refChild.menuElement);
            this.children.splice(index, 0, option);
        } else {
            this.dropdown?.body.appendChild(option.menuElement);
            this.children.push(option);
        }

        option.onHoverFuncs.push(c => this.onChildFocus(c));
        option.onBlurFuncs.push(c => this.onChildBlur(c));

        return option;
    }

    removeChild(index: number): void {
        const option = this.getChild(index);
        if (!option) {
            return;
        }

        this.children.splice(index, 1);
        option.remove();

        this.updateAsync();
    }

    async clearChildAsync(): Promise<void> {
        this.children.forEach(child => child.remove());
        this.children = [];
        await this.updateAsync();
    }
}