import Typeahead from "Typeahead";

export default interface TypeaheadOptions {
    input: HTMLInputElement;
    /** 是否允許多選 */
    multiple?: boolean;
    /** 最大可選數量 */
    max?: number;
    /** 允許在沒有選擇搜尋結果的狀態下保留輸入的文字當作值。 */
    directInput?: boolean;
    /** 呈現多選文字時，每個選項文字間用來分隔的字元。 */
    splittor?: string;
    /** 只有在關閉下拉選單時才觸發 Change 事件。 */
    changeWhenClose?: boolean;
    /** 指定輸入搜尋文字時停止多長的時間會啟動搜尋。預設為一秒鐘。 */
    searchDelayTime?: number;
    /** 進行搜尋時使用的非同步方法。 */
    searchFunc?: (text: string) => Promise<TypeaheadSearchResult>;

    items?: TypeaheadOptionItem[];

    onBuild?: (typeahead: Typeahead) => void;
    onOpen?: (typeahead: Typeahead) => void;
    onClose?: (typeahead: Typeahead) => void;
    onChange?: (typeahead: Typeahead) => void;
}

export interface TypeaheadSelectOption {
    value?: string;
    text?: string;
    subText?: string;
}

export interface TypeaheadOptionItem extends TypeaheadSelectOption {
    selected?: boolean;
}

export interface TypeaheadSearchResult {
    success: boolean;
    message?: string;
    items: TypeaheadOptionItem[];
}