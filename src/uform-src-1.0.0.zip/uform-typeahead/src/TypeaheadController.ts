import Typeahead from "Typeahead";
import TypeaheadOptions from "TypeaheadOptions";

export default class TypeaheadController {

    private _currentId: number = 0;

    private _typeaheads: { [id: string]: Typeahead } = {};

    checkIconSvg: string = "<svg aria-hidden=\"true\" focusable=\"false\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 512 512\">" +
        "<path d=\"M173.898 439.404l-166.4-166.4c-9.997-9.997-9.997-26.206 0-36.204l36.20" +
        "3-36.204c9.997-9.998 26.207-9.998 36.204 0L192 312.69 432.095 72.596c9.997-9.997 26.207-9.997 36.20" +
        "4 0l36.203 36.204c9.997 9.997 9.997 26.206 0 36.204l-294.4 294.401c-9.998 9.997-26.207 9.997-36.204" +
        "-.001z\"></path></svg>";

    deleteIconSvg: string = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 320 512\">" +
        "<path d=\"M310.6 150.6c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L160 210.7 54.6 105.4c-12.5-12.5-32.8-12.5-45.3 " +
        "0s-12.5 32.8 0 45.3L114.7 256 9.4 361.4c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0L160 301.3 265.4 406.6c12.5 12.5 " + 
        "32.8 12.5 45.3 0s12.5-32.8 0-45.3L205.3 256 310.6 150.6z\"/></svg>";

    private _getNewId(): number {
        return this._currentId++;
    }

    async scanAsync(): Promise<HTMLInputElement[]> {
        const inputElements: HTMLInputElement[] = [];
        const matchs = document.querySelectorAll("input.typeahead");
        for (let i = 0; i < matchs.length; i++) {
            inputElements.push(<HTMLInputElement>(matchs.item(i)));
        }

        return inputElements;
    }

    async scanAndBuildAsync(): Promise<Typeahead[]> {
        const elements = await this.scanAsync();
        return this.buildAsync(elements);
    }

    get(id: number): Typeahead | undefined;
    get(element: HTMLElement): Typeahead | undefined;
    get(arg0: number | HTMLElement): Typeahead | undefined {
        if (typeof arg0 === "number") {
            return this._typeaheads[String(arg0)];
        } else {
            const ids = Object.keys(this._typeaheads);
            for (let i = 0; i < ids.length; i++) {
                if (this._typeaheads[ids[i]].element.isSameNode(arg0)) {
                    return this._typeaheads[ids[i]];
                }
            }
        }
    }

    list(): Typeahead[];
    list(id: number): Typeahead[];
    list(element: HTMLElement): Typeahead[];
    list(idOrElements: (number | HTMLElement)[]): Typeahead[];
    list(arg0?: number | HTMLElement | (number | HTMLElement)[]): Typeahead[] {
        if (!arg0) {
            return Object.keys(this._typeaheads).map(id => this._typeaheads[id]);
        } else if (typeof arg0 === "number") {
            return [this._typeaheads[String(arg0)]].filter(typeahead => !!typeahead);
        } else if (Array.isArray(arg0)) {
            return arg0
                .map(item => {
                    if (typeof item === "number") {
                        return this._typeaheads[String(item)];
                    } else {
                        return this.get(item);
                    }
                })
                .filter(typeahead => !!typeahead)
                .map(typeahead => typeahead!);
        } else {
            const typeaheads: Typeahead[] = [];
            const ids = Object.keys(this._typeaheads);
            for (let i = 0; i < ids.length; i++) {
                if (this._typeaheads[ids[i]].element.isSameNode(arg0)) {
                    typeaheads.push(this._typeaheads[ids[i]]);
                }
            }

            return typeaheads;
        }
    }

    buildAsync(options: TypeaheadOptions): Promise<Typeahead[]>;
    buildAsync(element: HTMLInputElement): Promise<Typeahead[]>;
    buildAsync(elements: HTMLInputElement[]): Promise<Typeahead[]>;
    async buildAsync(arg0: TypeaheadOptions | HTMLInputElement | HTMLInputElement[]): Promise<Typeahead[]> {
        if ("input" in arg0) {
            if (!arg0.input) {
                return [];
            }

            const exists = this.get(arg0.input);
            if (exists) {
                return [exists];
            }

            const id = this._getNewId();
            const typeahead = new Typeahead(arg0.input, id, arg0);
            typeahead.init();
            await typeahead.updateAsync();
            this._typeaheads[String(id)] = typeahead;

            if (typeahead.options.onBuild) {
                typeahead.options.onBuild(typeahead);
            }

            return [typeahead];
        } else {
            const typeaheads: Typeahead[] = [];
            const elements = Array.isArray(arg0) ? arg0 : [arg0];
            for (let i = 0; i < elements.length; i++) {
                if (!elements[i]) {
                    continue;
                }

                const exists = this.get(elements[i]);
                if (exists) {
                    typeaheads.push(exists);
                    continue;
                }

                const id = this._getNewId();
                const typeahead = new Typeahead(elements[i], id);
                typeahead.init();
                await typeahead.updateAsync();
                this._typeaheads[String(id)] = typeahead;

                typeaheads.push(typeahead);

                if (typeahead.options.onBuild) {
                    typeahead.options.onBuild(typeahead);
                }
            }

            return typeaheads;
        }
    }

    updateAsync(): Promise<void>;
    updateAsync(id: number): Promise<void>;
    updateAsync(element: HTMLSelectElement): Promise<void>;
    updateAsync(idOrElements: (number | HTMLElement)[]): Promise<void>;
    async updateAsync(arg0?: number | HTMLSelectElement | (number | HTMLElement)[]): Promise<void> {
        const typeaheads = this.list(<any>arg0);
        for (let i = 0; i < typeaheads.length; i++) {
            await typeaheads[i].updateAsync();
        }
    }

    rebuildAsync(): Promise<void>;
    rebuildAsync(id: number): Promise<void>;
    rebuildAsync(element: HTMLSelectElement): Promise<void>;
    rebuildAsync(idOrElements: (number | HTMLElement)[]): Promise<void>;
    async rebuildAsync(arg0?: number | HTMLSelectElement | (number | HTMLElement)[]): Promise<void> {
        const typeaheads: Typeahead[] = this.list(<any>arg0);
        for (let i = 0; i < typeaheads.length; i++) {
            const typeahead = typeaheads[i];
            const id = typeahead.id;
            const element = typeahead.element;
            await typeahead.removeAsync();

            const newTypeahead = new Typeahead(element, id);
            newTypeahead.init();
            await newTypeahead.updateAsync();
        }
    }

    removeAsync(): Promise<void>;
    removeAsync(id: number): Promise<void>;
    removeAsync(element: HTMLSelectElement): Promise<void>;
    removeAsync(idOrElements: (number | HTMLElement)[]): Promise<void>;
    async removeAsync(arg0?: number | HTMLSelectElement | (number | HTMLElement)[]): Promise<void> {
        const typeaheads: Typeahead[] = this.list(<any>arg0);

        for (let i = 0; i < typeaheads.length; i++) {
            const typeahead = typeaheads[i];
            const id = typeahead.id;
            await typeahead.removeAsync();
            delete this._typeaheads[id];
        }
    }
}

export const typeaheadController = new TypeaheadController();
(<any>window).typeaheadController = typeaheadController;
typeaheadController.scanAndBuildAsync();