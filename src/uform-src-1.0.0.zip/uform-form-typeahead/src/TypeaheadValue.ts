
export default interface TypeaheadValue {
    text: string;
    value: string;
}