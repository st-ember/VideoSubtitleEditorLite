import TypeaheadElementOption from "TypeaheadElementOption";
import TypeaheadValue from "TypeaheadValue";
import { FormElementGeneric } from "uform-form";
import typeaheadController, { TypeaheadSearchResult, Typeahead } from "uform-typeahead";

export default class TypeaheadElement extends FormElementGeneric<TypeaheadValue | TypeaheadValue[] | undefined> implements TypeaheadElementOption {

    multiple?: boolean = false;
    max?: number;
    /** 允許在沒有選擇搜尋結果的狀態下保留輸入的文字當作值。 */
    directInput?: boolean;
    /** 呈現多選文字時，每個選項文字間用來分隔的字元。 */
    splittor?: string;
    /** 只有在關閉下拉選單時才觸發 Change 事件。 */
    changeWhenClose?: boolean = false;
    /** 指定輸入搜尋文字時停止多長的時間會啟動搜尋。預設為一秒鐘。 */
    searchDelayTime?: number;
    /** 進行搜尋時使用的非同步方法。 */
    searchFunc: (text: string) => Promise<TypeaheadSearchResult> = undefined!;

    element: HTMLInputElement = document.createElement("input");

    typeahead?: Typeahead;

    onTypeaheadBuild?: (typeahead: Typeahead) => void;

    constructor(options?: TypeaheadElementOption) {
        super(options);
        this.bindOptions(options);
    }

    static fromAsync(options: TypeaheadElementOption): Promise<TypeaheadElement> {
        return <Promise<TypeaheadElement>>(new TypeaheadElement(options).buildAsync());
    }

    protected async buildElementAsync(): Promise<void> {
        this.element.type = "text";

        if (this.name) {
            this.element.name = this.name;
        }

        this.element.id = this.id;
        this.element.autocomplete = "nope";
        this.container.appendChild(this.element);

        await this.buildTypeaheadAsync();
    }

    protected async buildTypeaheadAsync(): Promise<void> {
        const typeaheads = await typeaheadController.buildAsync({
            input: this.element,
            multiple: this.multiple,
            max: this.max,
            directInput: this.directInput,
            splittor: this.splittor,
            changeWhenClose: this.changeWhenClose,
            searchDelayTime: this.searchDelayTime,
            searchFunc: this.searchFunc,
            onChange: () => this.changeAsync(),
            onBuild: typeahead => {
                if (this.onTypeaheadBuild) {
                    this.onTypeaheadBuild(typeahead);
                }
            }
        });

        this.typeahead = typeaheads[0];
        this.messageAnchor = this.element;
        
        if (this.width) {
            this.element.style.width = typeof this.width === "number" ? `${this.width}px` : this.width;
        }
    }

    async rebuildAsync(): Promise<void> {
        if (this.typeahead) {
            await typeaheadController.removeAsync(this.typeahead.id);
            this.typeahead = undefined;
        }

        await this.buildTypeaheadAsync();
        await this.clearAsync();
    }

    async deleteAsync(): Promise<void> {
        await this.removeMessageAsync();

        if (this.typeahead) {
            await typeaheadController.removeAsync(this.typeahead.id);
            this.typeahead = undefined;
        }
        
        this.container.remove();
    }

    async validateAsync(): Promise<boolean> {
        this.validated = true;

        const value = this.typeahead ? (this.directInput ? this.typeahead.getSelectedText() : this.typeahead.getValue()) : undefined;
        const valid = !this.needToCheckRequire() || typeof value === "string" ? (value && value !== "-1") : (value && (value.length > 1 || value.length === 1 && value[0] !== "-1"));
        await this.showInvalidEffectAsync(!valid, "此項目為必填！");
        return valid === true;
    }

    async setDisableAsync(disable?: boolean): Promise<void> {
        this.disabled = disable !== false;
        await this.typeahead?.setDisableAsync(this.disabled);
    }

    async clearAsync(): Promise<void> {
        await this.typeahead?.setValueAsync("");
    }

    async getValueAsync(): Promise<TypeaheadValue | TypeaheadValue[] | undefined> {
        const value = this.typeahead?.getValue();
        if (!value && !this.directInput) {
            return this.multiple ? [] : undefined;
        }

        const text = this.typeahead?.getSelectedText();
        if (!text) {
            return this.multiple ? [] : undefined;
        }

        return typeof text === "string" ? 
            { value: <string>value, text: text } : 
            text.map((text, index) => { return { value: (<string[]>value)[index], text: text ?? "" }; });
    }

    async getArrayValueAsync(): Promise<TypeaheadValue[]> {
        const value = await this.getValueAsync();
        return !!value ? (value instanceof Array ? value : [value]) : [];
    }

    async getSingleValueAsync(): Promise<TypeaheadValue | undefined> {
        const value = await this.getValueAsync();
        return !!value ? (value instanceof Array ? value.length > 0 ? value[0] : undefined : value) : undefined;
    }

    async setValueAsync(value: TypeaheadValue | TypeaheadValue[] | undefined): Promise<void> {
        if (this.typeahead) {
            const adoptedValue = !!value ? (value instanceof Array ? value.map(o => o.value) : value.value) : "";
            await this.typeahead.setValueAsync(adoptedValue);
        }
    }

    async setSelectedOptionAsValueAsync(value: TypeaheadValue | TypeaheadValue[]): Promise<void> {
        if (this.typeahead) {
            if (!!value) {
                if (value instanceof Array) {
                    await this.typeahead.setSelectedOptionAsValueAsync(value);
                } else {
                    await this.typeahead.setSelectedOptionAsValueAsync(value);
                }
            } else {
                await this.typeahead.setValueAsync("");
            }
        }
    }
}