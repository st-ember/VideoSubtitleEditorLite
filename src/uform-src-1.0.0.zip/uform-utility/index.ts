import Utility from "./src/uform-utility";

export default Utility;
export { Utility };