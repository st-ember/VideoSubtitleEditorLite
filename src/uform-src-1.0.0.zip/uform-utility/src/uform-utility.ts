
export default class Utility {

    public static forEachElement(selector: keyof(HTMLElementTagNameMap), action: (element: HTMLElement) => void): void {
        const nodeList = document.querySelectorAll(selector);
        for (let i = 0; i < nodeList.length; i++) {
            action(nodeList[i]);
        }
    }

    public static mapElement<TResult>(selector: keyof(HTMLElementTagNameMap), func: (element: HTMLElement) => TResult): TResult[] {
        const nodeList = document.querySelectorAll(selector);
        const results: TResult[] = [];
        for (let i = 0; i < nodeList.length; i++) {
            results.push(func(nodeList[i]));
        }
        return results;
    }

    public static listElement(selector: keyof(HTMLElementTagNameMap)): HTMLElement[] {
        const nodeList = document.querySelectorAll(selector);
        const results: HTMLElement[] = [];
        for (let i = 0; i < nodeList.length; i++) {
            results.push(nodeList[i]);
        }
        return results;
    }

    /**
     * 以輸入的節點為基礎，逐層往上搜尋顯示垂直卷軸的節點。
     * @param node 基礎節點
     * @returns 顯示垂直卷軸的節點，如果未找到會回傳 Body 物件。如果輸入無效則會回傳 undefined。
     */
    public static getScrollParent(node: HTMLElement | null): HTMLElement | undefined {
        if (!node) {
            return undefined;
        }

        const isElement = node instanceof HTMLElement;
        const overflowY = isElement && window.getComputedStyle(node).overflowY;
        const isScrollable = overflowY !== "visible" && overflowY !== "hidden";

        if (isScrollable && node.scrollHeight >= node.clientHeight) {
            return node;
        }

        return this.getScrollParent(node.parentElement) || document.body;
    }

    /**
     * 檢查指定的節點是否已經被附加到網頁上。
     * @param node 要檢查的節點
     * @returns 是否已被附加到網頁上。如果輸入無效則會回傳 undefined。
     */
    public static isAppendedToDocument(node: Node | null): boolean | undefined {
        if (!node) {
            return undefined;
        }

        while (node.parentNode) {
            node = node.parentNode;
        }

        return node instanceof Document;
    }

    /**
     * 回傳一個等待指定時間後才會完成的 Promise。
     * @param time 要等待的時間
     * @returns 尚未完成的 Promise
     */
    public static wait(time: number): Promise<void> {
        return new Promise<void>(resolve => setTimeout(() => resolve(), time));
    }

    public static doAsyncTask<T>(task: () => Promise<T>, time: number = 0): Promise<T> {
        return new Promise<T>(resolve => setTimeout(async () => resolve(await task()), time));
    }

    /**
     * 輸入一個條件，每隔一段時間會檢查條件是否達成。直到條件達成後才會完成 Promise。
     * @param checker 條件的檢查 Function
     * @param checkTime 每次檢查的間隔時間
     * @returns 尚未完成的 Promise 物件，只有當條件達成後才會完成。
     */
    public static waitUntil(checker: () => boolean, checkTime: number = 10): Promise<void> {
        return new Promise<void>(resolve => {
            if (checker()) { 
                resolve();
                return;
            }

            const loop = setInterval(() => {
                if (checker()) {
                    resolve();
                    clearInterval(loop);
                }
            }, checkTime && checkTime > 0 ? checkTime : 10);
        });
    }

    /**
     * 輸入一個條件，並將檢查條件放入佇列中，每隔一段時間會檢查最舊的條件是否達成。直到條件達成才會完成該 Promise 並繼續處理佇列中的下一個條件。
     * @param queueHolder 擁有佇列的物件
     * @param checker 條件的檢查 Function
     * @param checkTime 每次檢查的間隔時間
     * @returns 尚未完成的 Promise 物件，只有當條件達成後才會完成。
     */
    public static queueUntil(queueHolder: any, checker: () => boolean, checkTime: number = 10): Promise<void> {
        if (checker()) {
            return new Promise<void>(resolve => resolve());
        }

        if (!queueHolder.__queue) {
            queueHolder.__queue = [];
        }

        const promise = new Promise<void>(resolve => {
            queueHolder.__queue.push({ checker, checkTime, resolve });
        });

        if (!queueHolder.__queue.processor) {
            queueHolder.__queue.processor = () => {
                for (let i = 0; i < queueHolder.__queue.length; i++) {
                    this.waitUntil(queueHolder.__queue[i].checker, queueHolder.__queue[i].checkTime).then(() => queueHolder.__queue[i].resolve());
                }
                queueHolder.__queue.processor = undefined;
            };
            queueHolder.__queue.processor();
        }

        return promise;
    }
}