
export default interface Api {
    url: string;
    method: "GET" | "POST" | "PUT",

    /** 在執行 cross-origin 要求時，是否送出驗證資訊。 */
    withCredential?: boolean;
}