import Api from "Api";
import ApiControllerPromise from "ApiControllerPromise";
import ApiControllerPromiseRetrieveResult from "ApiControllerPromiseRetrieveResult";
import ApiResponse, { ApiResponseImp } from "ApiResponse";

export default class ApiController {

    private _promises: ApiControllerPromise[] = [];
    cacheLifeTime: number = 3000;

    constructor() {
        setInterval(() => {
            if (this._promises.length === 0) { return; }

            const time = Number(new Date());
            const promises: ApiControllerPromise[] = [];
            this._promises.forEach(promise => {
                if (time - promise.time <= this.cacheLifeTime) {
                    promises.push(promise);
                }
            });

            this._promises = promises;
        }, this.cacheLifeTime + 1);
    }

    /**
     * 以非同步方式提供 API 資訊以及要求資料並呼叫 API。
     * @param api API 物件
     * @param data 要傳給 API 的資料
     * @returns ApiResponse
     */
    queryAsync(api: Api, data?: any): Promise<ApiResponse> {
        return new Promise<ApiResponse>(resolve => {
            try {
                const url = this.parseUrl(api, data);
                const request = this.buildRequest(api, data);
    
                let fromCache = false;
                const joinFunc = (response: ApiResponse) => {
                    if (fromCache) {
                        resolve(response);
                    }
                };
    
                const promiseResult = this.checkAndAddPromise(url, request, joinFunc);
    
                if (promiseResult.fromCache) {
                    if (!promiseResult.wait) {
                        resolve(promiseResult.response!);
                    } else {
                        fromCache = true;
                    }
                } else {
                    const promise = promiseResult.promise!;
                    fetch(url, request)
                        .then(response => {
                            if (response.ok) {
                                response.json()
                                    .then(apiResponse => {
                                        const response = new ApiResponseImp(apiResponse.success, 200, apiResponse, apiResponse.message);
                                        promise.response = response;
                                        resolve(response);
                                        promise.joinFuncs.forEach(func => func(response));
                                    })
                                    .catch(reason => {
                                        const response = new ApiResponseImp(false, 0, undefined, reason);
                                        resolve(response);
                                    });
                            } else {
                                resolve(new ApiResponseImp(false, 0, undefined, "error"));
                            }
                        });
                }
            } catch (error) {
                console.log("error")
                resolve(new ApiResponseImp(false, 0, undefined, <any>error));
            }
        });
    }

    checkAndAddPromise(url: string, request: RequestInit, joinFunc: (r: ApiResponse) => void): ApiControllerPromiseRetrieveResult {
        const requestJson = JSON.stringify(request);
        const matchs = this._promises.filter(o => o.url === url && o.request === requestJson);
        const now = Number(new Date());

        if (matchs.length > 0) {
            const promise = matchs[0];
            if (!promise.response) {
                promise.joinFuncs.push(joinFunc);
                return { wait: true, fromCache: true };
            } else if (now - promise.time < this.cacheLifeTime) {
                return { wait: false, fromCache: true, response: promise.response };
            }
        }

        const promise: ApiControllerPromise = { url: url, request: requestJson, time: now, joinFuncs: [] };
        this._promises.push(promise);

        return { wait: false, fromCache: false, promise: promise };
    }

    /**
     * 根據 HTTP 方法轉換 Url，如果方法是 GET，表示輸入的資料需要以 query 的方式附加在網址後。
     * 如果網址中帶有冒號開頭的參數，會自動將輸入的資料中擁有相同名稱的項目帶入網址中。
     * @param api API 物件
     * @param data 要傳給 API 的資料
     * @returns 已經完成整理的網址。
     */
    parseUrl(api: Api, data?: any): string {
        if (data === undefined || Object.keys(data).length === 0) {
            return api.url;
        }
    
        const mappedKeys: string[] = [];
        const array = api.url.split("/")
            .map(item => {
                // 掃描過網址中的每個字串，檢查是否有冒號開頭的參數需要帶入。
                if (item && item.length > 1 && item.substring(0, 1) === ":") {
                    const key = item.substring(1);
                    mappedKeys.push(key);
    
                    const value = data[key];
                    if (value !== undefined && value !== null) {
                        if (typeof value === "string" && value !== "") {
                            return value;
                        }
                        else if (typeof value === "number" || typeof value === "boolean") {
                            return String(value);
                        }
                    }
                }
                return item;
            });
    
        if (api.method === "POST" || api.method === "PUT") {
            // 如果方法是 POST 或 PUT，就不用費心整理尚未被附加到網址當作參數的資料了，之後所有資料都會被放到 body 中。
            return array.join("/");
        }
        else {
            // 如果是 GET，所有未被帶入到網址中的資料都要被整理成「成對」的形式，以便附加在網址後面。
            const keys = Object.keys(data).filter(key => !mappedKeys.some((mappedKey => mappedKey === key)));
            const unmappedPairs = [];
            for (let i = 0; i < keys.length; i++) {
                const key = keys[i];
                const value = data[key];
                if (value instanceof Array) {
                    value.forEach(item => unmappedPairs.push(key + "=" + item));
                } else {
                    unmappedPairs.push(key + "=" + value);
                }
            }
    
            return unmappedPairs.length === 0 ? array.join("/") : (array.join("/") + "?" + unmappedPairs.join("&"));
        }
    }

    /**
     * 建立 Fetch 需要的 RequestInit 物件。如果 HTTP 方法是 PUT 或 POST，會將輸入的資料以 JSON 格式放在 body 中。
     * @param api API 物件
     * @param data 要傳給 API 的資料
     * @returns RequestInit 物件
     */
    buildRequest(api: Api, data?: any): RequestInit {
        if (api.method === "PUT" || api.method === "POST") {
            return {
                body: this.parseBody(data !== undefined ? data : {}),
                cache: "no-cache",
                method: api.method,
                headers: new Headers({ "Content-Type": "application/json" }),
                credentials: api.withCredential ? "include" : "same-origin"
            };
        } else {
            // 如果不是 PUT 和 POST，就不會附加資料在 body 了。
            return {
                cache: "no-cache",
                method: api.method,
                headers: new Headers({ "Content-Type": "application/json" }),
                credentials: api.withCredential ? "include" : "same-origin"
            };
        }
    }

    /**
     * 將輸入的資料轉換成 JSON 格式，如果沒有輸入任何資料，則用空的物件代替。
     * @param data 要傳給 API 的資料
     * @returns 完成轉換的資料
     */
    parseBody(data: any): string {
        if (data === undefined) {
            return "{}";
        }
    
        return JSON.stringify(data);
    }
}

export const apiController = new ApiController();
(<any>window).apiController = apiController;