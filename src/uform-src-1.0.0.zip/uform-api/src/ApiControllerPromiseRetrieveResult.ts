import ApiControllerPromise from "ApiControllerPromise";
import ApiResponse from "ApiResponse";

export default interface ApiControllerPromiseRetrieveResult {
    wait: boolean;
    fromCache: boolean;
    response?: ApiResponse;
    promise?: ApiControllerPromise;
}