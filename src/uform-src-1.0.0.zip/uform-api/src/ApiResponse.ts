
export default interface ApiResponse {
    response?: any;
    success: boolean;
    message?: string;
    code?: number;
    data?: any;
}

export class ApiResponseImp implements ApiResponse {
    response?: any;
    success: boolean = false;
    message?: string;
    code?: number;
    data?: any;

    constructor(success: boolean, code?: number, response?: any, message?: string) {
        this.response = response;
        this.success = success;
        this.message = message;
        this.code = code;
        this.data = response ? response.data : undefined;

        if (response) {
            Object.keys(response).forEach(key => {
                if (key !== "success" && key !== "message" && key !== "code" && key !== "data") {
                    (<any>this)[key] = response[key];
                }
            });
        }
    }
}