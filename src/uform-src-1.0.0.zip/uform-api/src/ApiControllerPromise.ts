import ApiResponse from "ApiResponse";

export default interface ApiControllerPromise {
    url: string;
    request: string;
    response?: ApiResponse;
    time: number;
    joinFuncs: ((r: ApiResponse) => void)[];
}