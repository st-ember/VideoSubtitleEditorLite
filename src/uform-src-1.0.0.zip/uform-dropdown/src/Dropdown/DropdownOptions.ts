
export default interface DropdownOptions {
    tag?: string;
    container?: HTMLElement;
    target: HTMLElement;
    head?: HTMLElement;
    content?: HTMLElement;
    bottom?: HTMLElement;
    maxHeight?: number;
    maxWidth?: number;
    paddingTop?: number;
    paddingBottom?: number;
    marginTop?: number;
    marginBottom?: number;
    marginLeft?: number;
    marginRight?: number;
    showArrow?: boolean;
    disableTargetEvent?: boolean;
}