import DropdownOptions from "./DropdownOptions";
import Dropdown from "./Dropdown";

export default class DropdownController {

    private _dropdowns: Dropdown[] = [];

    constructor() {
        this._onTargetClickAsync = this._onTargetClickAsync.bind(this);
    }

    get(target: HTMLElement, tag?: string): Dropdown | undefined {
        const matchs = this._dropdowns.filter(o => o.getTarget().isSameNode(target) && o.options.tag === tag);
        return matchs.length > 0 ? matchs[0] : undefined;
    }

    add(target: DropdownOptions): Dropdown;
    add(target: HTMLElement, content: HTMLElement, disableTargetEvent?: boolean, tag?: string): Dropdown;
    add(target: HTMLElement | DropdownOptions, content?: HTMLElement, disableTargetEvent?: boolean, tag?: string): Dropdown {
        
        let options: DropdownOptions | undefined = undefined;
        if ("target" in target) {
            // input options.
            options = target;
        } else {
            // input target, content and disableTargetEvent.
            options = { tag, target, content, disableTargetEvent };
        }

        const dropdown = new Dropdown(options);
        const targetElement = dropdown.getTarget();

        targetElement.addEventListener("click", this._onTargetClickAsync);
        dropdown.disableTargetEvent = options.disableTargetEvent === true;

        dropdown.init();

        if (options.content && dropdown.body) {
            dropdown.body.appendChild(options.content);
        }
        
        this._dropdowns.push(dropdown);
        return dropdown;
    }

    async removeAsync(target: HTMLElement, tag?: string): Promise<void> {
        const dropdown = this.get(target, tag);
        if (dropdown) {
            dropdown.getTarget().removeEventListener("click", this._onTargetClickAsync);
            await dropdown.removeAsync();
            this._dropdowns = this._dropdowns.filter(o => !o.getTarget().isSameNode(target) || o.options.tag !== tag);
        }
    }

    private async _onTargetClickAsync(event: MouseEvent): Promise<void> {
        const matchs = this._dropdowns.filter(dropdown => dropdown.getTarget().isSameNode(<HTMLElement>event.currentTarget));
        matchs.forEach(dropdown => {
            if (!dropdown.disableTargetEvent) {
                dropdown.openAsync(!dropdown.opened);
            }
        });
    }
}

export const dropdownController: DropdownController = new DropdownController();
(<any>window).dropdownController = dropdownController;