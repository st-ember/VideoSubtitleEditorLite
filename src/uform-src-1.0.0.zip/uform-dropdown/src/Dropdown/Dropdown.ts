import DropdownOptions from "./DropdownOptions";
import Utility from "uform-utility";

export default class Dropdown {

    menuAtTargetBottom: boolean = true;
    opened: boolean = false;
    disabled: boolean = false;
    mouseEntered: boolean = false;
    disableTargetEvent: boolean = false;

    options: DropdownOptions;

    scrollParent: HTMLElement | undefined;
    frame: HTMLDivElement = document.createElement("div");
    element: HTMLDivElement = document.createElement("div");
    head: HTMLDivElement = document.createElement("div");
    body: HTMLDivElement = document.createElement("div");
    bottom: HTMLDivElement = document.createElement("div");
    arrow: HTMLDivElement | undefined;

    onPositionChangeFuncs: (() => void)[] = [];
    onOpenStatusChangeFuncs: (() => void)[] = [];
    onUpKeyPressFuncs: (() => void)[] = [];
    onDownKeyPressFuncs: (() => void)[] = [];
    onEnterKeyPressFuncs: (() => void)[] = [];
    onSpaceKeyPressFuncs: (() => void)[] = [];
    onMouseWheelUpFuncs: (() => void)[] = [];
    onMouseWheelDownFuncs: (() => void)[] = [];
    onMouseEnterFuncs: (() => void)[] = [];
    onMouseLeaveFuncs: (() => void)[] = [];

    constructor(options: DropdownOptions) {
        this.options = options;
    }

    init(): void {
        this._initOptions();
        this._initMenuElements();
        this.getContainer().appendChild(this.frame!);

        this._onScrollAsync = this._onScrollAsync.bind(this);
        this._onMouseClickAsync = this._onMouseClickAsync.bind(this);
        this._onKeyUpAsync = this._onKeyUpAsync.bind(this);
        this._onMouseWheel = this._onMouseWheel.bind(this);
        this._onMouseEnter = this._onMouseEnter.bind(this);
        this._onMouseLeave = this._onMouseLeave.bind(this);
    }

    async updateAsync(force?: boolean): Promise<void> {
        if (this.opened || force === true) {
            await this._updateElementAsync();
        }
    }

    async removeAsync(): Promise<void> {
        if (this.opened) {
            this.openAsync(false);
        }

        if (this.frame) {
            this.frame.remove();
        }
    }

    private _initOptions(): void {
        if (this.options.marginTop === undefined) {
            this.options.marginTop = 2;
        }

        if (this.options.marginBottom === undefined) {
            this.options.marginBottom = 5;
        }

        if (this.options.marginLeft === undefined) {
            this.options.marginLeft = 4;
        }

        if (this.options.marginRight === undefined) {
            this.options.marginRight = 4;
        }

        if (this.options.paddingTop === undefined) {
            this.options.paddingTop = 4;
        }

        if (this.options.paddingBottom === undefined) {
            this.options.paddingBottom = 4;
        }

        if (this.options.showArrow === undefined) {
            this.options.showArrow = false;
        }
    }

    private _initMenuElements(): void {
        this.frame.className = "dropdown-frame";

        this.element.className = "dropdown-element";
        this.frame.appendChild(this.element);

        if (this.options.showArrow) {
            this.arrow = document.createElement("div");
            this.arrow.className = "dropdown-arrow-container";
            this.arrow.innerHTML = "<span class=\"dropdown-arrow\"></span>";
            this.element.appendChild(this.arrow);
        }

        this.head.className = "dropdown-head";
        this.element.appendChild(this.head);

        if (this.options.head) {
            this.head.appendChild(this.options.head);
        }

        this.body.className = "dropdown-body";
        this.element.appendChild(this.body);

        this.bottom.className = "dropdown-bottom";
        this.element.appendChild(this.bottom);

        if (this.options.bottom) {
            this.bottom.appendChild(this.options.bottom);
        }

        this.element.addEventListener("mouseenter", () => this.mouseEntered = true);
        this.element.addEventListener("mouseleave", () => this.mouseEntered = false);
    }

    getTarget(): HTMLElement {
        return this.options.target;
    }

    getContainer(): HTMLElement {
        return this.options.container ? this.options.container : document.body;
    }

    private async _updateElementAsync(): Promise<void> {
        if (!this.options || !this.head || !this.body || !this.bottom || !this.frame || !this.element) {
            return;
        }

        const headHeight = this.head.getBoundingClientRect().height;
        const bottomHeight = this.bottom.getBoundingClientRect().height;
        const marginTop = this.options.marginTop ?? 0;
        const marginBottom = this.options.marginBottom ?? 0;

        const bodyChildren = this.body.children;
        let bodyHeight = 0;
        for (let i = 0; i < bodyChildren.length; i++) {
            bodyHeight += bodyChildren.item(i)!.clientHeight;
        }
        
        this.body.style.height = `calc(100% - ${headHeight + bottomHeight}px)`;

        const totalHeight = headHeight + bottomHeight + (this.options.paddingTop ?? 0) + (this.options.paddingBottom ?? 0) + bodyHeight + 2;

        const targetRect = this.getTarget().getBoundingClientRect();
        const targetTop = targetRect.top;
        const targetHeight = targetRect.height;
        const targetBottom = window.innerHeight - targetTop - targetHeight;
        const marginLeft = this.options.marginLeft ?? 0;
        const marginRight = this.options.marginRight ?? 0;

        const menuAtTargetBottom = targetTop * 0.6 < targetBottom;

        if (menuAtTargetBottom) {
            this.frame.style.top = `${targetTop + targetHeight + marginTop}px`;

            let maxHeight = targetBottom - (marginTop + marginBottom);
            if (this.options.maxHeight !== undefined && this.options.maxHeight >= 0 && maxHeight > this.options.maxHeight) {
                maxHeight = this.options.maxHeight;
            }

            this.element.style.height = `${maxHeight < totalHeight ? maxHeight : totalHeight}px`;
        } else {
            let maxHeight = targetTop - (marginTop + marginBottom);
            if (this.options.maxHeight !== undefined && this.options.maxHeight >= 0 && maxHeight > this.options.maxHeight) {
                maxHeight = this.options.maxHeight;
            }

            if (maxHeight < totalHeight) {
                this.frame.style.top = `${marginTop}px`;
                this.element.style.height = `${maxHeight}px`;
            } else {
                this.frame.style.top = `${targetTop - totalHeight - marginBottom}px`;
                this.element.style.height = `${totalHeight}px`;
            }
        }

        if (this.menuAtTargetBottom !== menuAtTargetBottom) {
            this.onPositionChangeFuncs.forEach(func => func());
        }

        this.menuAtTargetBottom = menuAtTargetBottom;

        this.element.style.paddingTop = `${this.options.paddingTop}px`;
        this.element.style.paddingBottom = `${this.options.paddingBottom}px`;

        // Update width.
        const windowMaxWidth = window.innerWidth - marginLeft - marginRight;
        if (this.options.maxWidth !== undefined && this.options.maxWidth >= 0) {
            this.element.style.maxWidth = `${this.options.maxWidth >= windowMaxWidth ? this.options.maxWidth : windowMaxWidth}px`;
        } else {
            this.element.style.maxWidth = `${windowMaxWidth}px`;
        }

        // Update left.
        const elementRect = this.element.getBoundingClientRect();
        const elementRight = elementRect.width + targetRect.left;

        const left = window.innerWidth - elementRight < marginRight ?
            targetRect.left + (window.innerWidth - elementRight - marginRight) :
            (targetRect.left >= marginLeft ? targetRect.left : marginLeft);

        this.frame.style.left = `${left}px`;

        // Update arrow.
        if (this.options.showArrow && this.arrow) {
            const halfArrowWidth = this.arrow.clientWidth / 2;
            if (targetRect.width > elementRect.width) {
                this.arrow.style.left = `${elementRect.width / 2 - halfArrowWidth}px`;
            } else {
                this.arrow.style.left = `${targetRect.left - left + targetRect.width / 2 - halfArrowWidth}px`;
            }

            if (!menuAtTargetBottom) {
                this.arrow.classList.add("arrow-at-bottom");
                this.arrow.style.top = `${elementRect.height - 2}px`;
            } else {
                this.arrow.classList.remove("arrow-at-bottom");
                this.arrow.style.top = "";
            }
        }

        if (targetRect.bottom < 0 || targetRect.top > window.innerHeight) {
            setTimeout(() => this.openAsync(false), 200);
        }
    }

    clearBody(): void {
        if (this.body) {
            while (this.body.lastChild) {
                this.body.removeChild(this.body.lastChild);
            }
        }
    }

    async openAsync(value: boolean): Promise<void> {
        if (!this.opened && this.disabled || !this.frame || !this.element) {
            return;
        }

        if (!this.scrollParent) {
            const scrollParent = Utility.getScrollParent(this.getTarget().parentElement);
            this.scrollParent = scrollParent ? scrollParent : this.getContainer();
        }

        const open = value !== false;
        if (!this.opened && open) {
            this.opened = true;
            this.scrollParent!.addEventListener("scroll", this._onScrollAsync);
            await this.updateAsync();
            this.frame.classList.add("dropdown-opened");

            setTimeout(() => {
                if (!this.disableTargetEvent) {
                    window.addEventListener("click", this._onMouseClickAsync);
                }

                window.addEventListener("keydown", this._onKeyPress);
                window.addEventListener("keyup", this._onKeyUpAsync);

                if (this.element) {
                    this.element.addEventListener("wheel", this._onMouseWheel);
                    this.element.addEventListener("mouseenter", this._onMouseEnter);
                    this.element.addEventListener("mouseleave", this._onMouseLeave);
                }
            }, 100);

            setTimeout(() => this.updateAsync(), 200);

            this.onOpenStatusChangeFuncs.forEach(func => func());
        } else if (this.opened && !open) {
            this.opened = false;
            this.mouseEntered = false;
            this.frame.classList.remove("dropdown-opened");
            this.scrollParent!.removeEventListener("scroll", this._onScrollAsync);
            window.removeEventListener("keydown", this._onKeyPress);
            window.removeEventListener("keyup", this._onKeyUpAsync);
            this.element.removeEventListener("wheel", this._onMouseWheel);
            this.element.removeEventListener("mouseenter", this._onMouseEnter);
            this.element.removeEventListener("mouseleave", this._onMouseLeave);

            if (!this.disableTargetEvent) {
                window.removeEventListener("click", this._onMouseClickAsync);
            }

            this.onOpenStatusChangeFuncs.forEach(func => func());
        }
    }

    private async _onScrollAsync(): Promise<void> {
        if (this.opened) {
            await this.updateAsync();
        }
    }

    private async _onMouseClickAsync(): Promise<void> {
        if (this.opened && !this.mouseEntered) {
            await this.openAsync(false);
        }
    }

    private _onMouseWheel(event: WheelEvent): void {
        if (event.deltaY && event.deltaY > 0) {
            this.onMouseWheelUpFuncs.forEach(func => func());
        } else {
            this.onMouseWheelDownFuncs.forEach(func => func());
        }
    }

    private _onMouseEnter(): void {
        this.onMouseEnterFuncs.forEach(func => func());
    }

    private _onMouseLeave(): void {
        this.onMouseLeaveFuncs.forEach(func => func());
    }

    private _onKeyPress(event: KeyboardEvent): void {
        if (event.code) {
            const code = event.code;
            const codes = ["ArrowUp", "ArrowDown", "Enter", "Escape"];
            if (codes.indexOf(code) >= 0) {
                event.preventDefault();
            }
        } else if (event.keyCode) {
            const code = event.keyCode;
            const codes = [38, 40, 13, 27];
            if (codes.indexOf(code) >= 0) {
                event.preventDefault();
            }
        }
    }

    private async _onKeyUpAsync(event: KeyboardEvent): Promise<void> {
        if (event.code) {
            const code = event.code;
            if (code === "ArrowUp") {
                this.onUpKeyPressFuncs.forEach(func => func());
            } else if (code === "ArrowDown") {
                this.onDownKeyPressFuncs.forEach(func => func());
            } else if (code === "Enter") {
                this.onEnterKeyPressFuncs.forEach(func => func());
            } else if (code === "Space") {
                this.onSpaceKeyPressFuncs.forEach(func => func());
            } else if (code === "Escape") {
                await this.openAsync(false);
            }
        } else if (event.keyCode) {
            const code = event.keyCode;
            if (code === 38) {
                this.onUpKeyPressFuncs.forEach(func => func());
            } else if (code === 40) {
                this.onDownKeyPressFuncs.forEach(func => func());
            } else if (code === 13) {
                this.onEnterKeyPressFuncs.forEach(func => func());
            } else if (code === 27) {
                await this.openAsync(false);
            }
        }
    }
}