import { Form, InputElement } from "uform-form";
import SelectElement from "./SelectElement";

async function testAsync(): Promise<void> {
    const target = document.getElementById("test-form-0");
    if (target) {
        const form = new TestForm(target);
        await form.buildAsync();
    }
}

class TestForm extends Form {
    
    async buildChildrenAsync(): Promise<void> {
        
        const selector = await SelectElement.fromAsync({
            label: "選單",
            options: [{ text: "選項A", value: "a", subText: "subtext-a" }, { text: "選項B", value: "b" }, { text: "選項C", value: "c" }]
        });
        await this.appendAsync(selector);

        const output = await InputElement.fromAsync({ label: "測試 output" });
        await this.appendAsync(output);

        const input = await InputElement.fromAsync({ label: "測試 input" });
        await this.appendAsync(input);

        selector.addChangeFunc(async () => {
            const value = await selector.getSingleValueAsync();
            output.setValueAsync(value);
        });

        input.addChangeFunc(async () => {
            const value = await input.getValueAsync();
            if (value) {
                selector.setValueAsync(value);
            }
        });
    }
}

testAsync();