import SelectElementOptions from "SelectElementOptions";
import { PickerElementGeneric } from "uform-form";
import selectorController, { Selector } from "uform-selector";

export default class SelectElement extends PickerElementGeneric<string | string[] | undefined> implements SelectElementOptions {

    multiple: boolean = false;
    maxWidth: number = 400;
    showAllItemText: boolean = false;
    changeWhenClose: boolean = false;
    fullWidth?: boolean = false;

    element: HTMLSelectElement = document.createElement("select");

    selector?: Selector;

    onSelectorBuild?: (selector: Selector) => void;

    constructor(options?: SelectElementOptions) {
        super(options);
        this.bindOptions(options);
    }

    static fromAsync(options: SelectElementOptions): Promise<SelectElement> {
        return <Promise<SelectElement>>(new SelectElement(options).buildAsync());
    }

    protected async buildElementAsync(): Promise<void> {
        if (this.name) {
            this.element.name = this.name;
        }
        
        this.element.id = this.id;
        this.container.appendChild(this.element);

        if (this.fullWidth) {
            this.container.classList.add("full-width-selector");
        } else {
            this.container.classList.remove("full-width-selector");
        }

        await this.buildOptionsAsync();
        await this.buildSelectorAsync();
    }

    protected buildOptionsAsync(): Promise<void> {
        return this.getOptionsAsync();
    }

    protected async buildSelectorAsync(): Promise<void> {
        const selectors = await selectorController.buildAsync({
            select: this.element,
            multiple: this.multiple,
            maxWidth: this.maxWidth,
            showAllItemText: this.showAllItemText,
            changeWhenClose: this.changeWhenClose,
            allowEmpty: this.allowEmpty,
            items: this.options.map(option => {
                return {
                    type: "OPTION",
                    text: option.text,
                    value: option.value,
                    subText: option.subText
                };
            }),
            onChange: () => this.changeAsync(),
            onBuild: (selector) => {
                if (this.onSelectorBuild) {
                    this.onSelectorBuild(selector);
                }
            }
        });

        this.selector = selectors[0];
        this.messageAnchor = this.selector.button;
    }

    async rebuildAsync(): Promise<void> {
        if (this.selector) {
            await selectorController.removeAsync(this.selector.id);
            this.selector = undefined;
        }
        
        this.element.innerHTML = "";

        await this.buildOptionsAsync();
        await this.buildSelectorAsync();
        await this.clearAsync();
    }

    async deleteAsync(): Promise<void> {
        await this.removeMessageAsync();

        if (this.selector) {
            await selectorController.removeAsync(this.selector.id);
            this.selector = undefined;
        }
        
        this.container.remove();
    }

    async validateAsync(): Promise<boolean> {
        this.validated = true;

        const value = this.selector?.getValue();
        const valid = !this.needToCheckRequire() || (typeof value === "string" ? (value && value !== "-1") : (value && (value.length > 1 || value.length === 1 && value[0] !== "-1")));
        await this.showInvalidEffectAsync(!valid, "此項目為必填！");
        return valid === true;
    }

    async setDisableAsync(disable?: boolean): Promise<void> {
        this.disabled = disable !== false;
        await this.selector?.setDisableAsync(this.disabled);
    }

    async clearAsync(): Promise<void> {
        await this.selector?.setValueAsync(undefined);
    }

    async getValueAsync(): Promise<string | string[] | undefined> {
        return this.selector?.getValue();
    }

    async getArrayValueAsync(): Promise<(string | undefined)[]> {
        const value = this.selector?.getValue();
        return value && value instanceof Array ? value : [value];
    }

    async getSingleValueAsync(): Promise<string | undefined> {
        const value = this.selector?.getValue();
        return value && value instanceof Array ? value.length > 0 ? value[0] : undefined : value;
    }

    async getTextAsync(): Promise<string | (string | undefined)[] | undefined> {
        const value = await this.getValueAsync();
        if (value instanceof Array) {
            return this.options.filter(o => value.indexOf(o.value ?? "") >= 0).map(o => o.text);
        } else {
            const matchs = this.options.filter(o => o.value === value).map(o => o.text);
            return matchs.length > 0 ? matchs[0] : undefined;
        }
    }

    async getArrayTextAsync(): Promise<(string | undefined)[]> {
        const value = await this.getValueAsync();
        if (value instanceof Array) {
            return this.options.filter(o => value.indexOf(o.value ?? "") >= 0).map(o => o.text);
        } else {
            const matchs = this.options.filter(o => o.value === value).map(o => o.text);
            return matchs.length > 0 ? [matchs[0]] : [];
        }
    }

    async getSingleTextAsync(): Promise<string | undefined> {
        const value = await this.getSingleValueAsync();
        const matchs = this.options.filter(o => o.value === value).map(o => o.text);
        return matchs.length > 0 ? matchs[0] : undefined;
    }

    async setValueAsync(value: string | number | string[] | number[] | undefined): Promise<void> {
        if (this.selector) {
            await this.selector.setValueAsync(value instanceof Array ? value.map((o: string | number) => String(o)) : String(value));
        }
    }
}