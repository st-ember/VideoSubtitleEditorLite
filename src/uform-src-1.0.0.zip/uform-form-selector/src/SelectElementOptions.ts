import { PickerElementOptions }  from "uform-form";

export default interface SelectElementOptions extends PickerElementOptions {
    multiple?: boolean;
    /** 按鈕的最大寬度 */
    maxWidth?: number;
    /** 是否在按鈕上顯示所有已選項目的文字。如果為 False，選擇多於一個項目時會改為顯示「已選擇 X 個項目」。 */
    showAllItemText?: boolean;
    /** 只有在關閉下拉選單時才觸發 Change 事件。 */
    changeWhenClose?: boolean;
    /** 盡量讓按鈕寬度填滿到極限 */
    fullWidth?: boolean;
}
