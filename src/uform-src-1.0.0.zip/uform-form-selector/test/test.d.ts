﻿declare module "SelectElementOptions" {
    import { PickerElementOptions } from "uform-form";
    export default interface SelectElementOptions extends PickerElementOptions {
        multiple?: boolean;
        maxWidth?: number;
        showAllItemText?: boolean;
        changeWhenClose?: boolean;
        fullWidth?: boolean;
    }
}
declare module "SelectElement" {
    import SelectElementOptions from "SelectElementOptions";
    import { PickerElementGeneric } from "uform-form";
    import { Selector } from "uform-selector";
    export default class SelectElement extends PickerElementGeneric<string | string[] | undefined> implements SelectElementOptions {
        multiple: boolean;
        maxWidth: number;
        showAllItemText: boolean;
        changeWhenClose: boolean;
        fullWidth?: boolean;
        element: HTMLSelectElement;
        selector?: Selector;
        onSelectorBuild?: (selector: Selector) => void;
        constructor(options?: SelectElementOptions);
        static fromAsync(options: SelectElementOptions): Promise<SelectElement>;
        protected buildElementAsync(): Promise<void>;
        protected buildOptionsAsync(): Promise<void>;
        protected buildSelectorAsync(): Promise<void>;
        rebuildAsync(): Promise<void>;
        deleteAsync(): Promise<void>;
        validateAsync(): Promise<boolean>;
        setDisableAsync(disable?: boolean): Promise<void>;
        clearAsync(): Promise<void>;
        getValueAsync(): Promise<string | string[] | undefined>;
        getArrayValueAsync(): Promise<(string | undefined)[]>;
        getSingleValueAsync(): Promise<string | undefined>;
        getTextAsync(): Promise<string | (string | undefined)[] | undefined>;
        getArrayTextAsync(): Promise<(string | undefined)[]>;
        getSingleTextAsync(): Promise<string | undefined>;
        setValueAsync(value: string | number | string[] | number[] | undefined): Promise<void>;
    }
}
declare module "test" { }
declare module "uform-form-selector" {
    import SelectElementOptions from "SelectElementOptions";
    import SelectElement from "SelectElement";
    export { SelectElementOptions, SelectElement };
}
