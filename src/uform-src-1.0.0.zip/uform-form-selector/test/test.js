﻿define("SelectElementOptions", ["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
});
define("SelectElement", ["require", "exports", "uform-form", "uform-selector"], function (require, exports, uform_form_1, uform_selector_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    class SelectElement extends uform_form_1.PickerElementGeneric {
        constructor(options) {
            super(options);
            this.multiple = false;
            this.maxWidth = 400;
            this.showAllItemText = false;
            this.changeWhenClose = false;
            this.fullWidth = false;
            this.element = document.createElement("select");
            this.bindOptions(options);
        }
        static fromAsync(options) {
            return (new SelectElement(options).buildAsync());
        }
        async buildElementAsync() {
            if (this.name) {
                this.element.name = this.name;
            }
            this.element.id = this.id;
            this.container.appendChild(this.element);
            if (this.fullWidth) {
                this.container.classList.add("full-width-selector");
            }
            else {
                this.container.classList.remove("full-width-selector");
            }
            await this.buildOptionsAsync();
            await this.buildSelectorAsync();
        }
        buildOptionsAsync() {
            return this._getOptionsAsync();
        }
        async buildSelectorAsync() {
            const selectors = await uform_selector_1.default.buildAsync({
                select: this.element,
                multiple: this.multiple,
                maxWidth: this.maxWidth,
                showAllItemText: this.showAllItemText,
                changeWhenClose: this.changeWhenClose,
                allowEmpty: this.allowEmpty,
                items: this.options.map(option => {
                    return {
                        type: "OPTION",
                        text: option.text,
                        value: option.value,
                        subText: option.subText
                    };
                }),
                onChange: () => this.changeAsync(),
                onBuild: (selector) => {
                    if (this.onSelectorBuild) {
                        this.onSelectorBuild(selector);
                    }
                }
            });
            this.selector = selectors[0];
            this.messageAnchor = this.selector.button;
        }
        async rebuildAsync() {
            if (this.selector) {
                await uform_selector_1.default.removeAsync(this.selector.id);
                this.selector = undefined;
            }
            this.element.innerHTML = "";
            await this.buildOptionsAsync();
            await this.buildSelectorAsync();
            await this.clearAsync();
        }
        async deleteAsync() {
            await this.removeMessageAsync();
            if (this.selector) {
                await uform_selector_1.default.removeAsync(this.selector.id);
                this.selector = undefined;
            }
            this.container.remove();
        }
        async validateAsync() {
            var _a;
            this.validated = true;
            const value = (_a = this.selector) === null || _a === void 0 ? void 0 : _a.getValue();
            const valid = !this.needToCheckRequire() || (typeof value === "string" ? (value && value !== "-1") : (value && (value.length > 1 || value.length === 1 && value[0] !== "-1")));
            await this.showInvalidEffectAsync(!valid, "此項目為必填！");
            return valid === true;
        }
        async setDisableAsync(disable) {
            var _a;
            this.disabled = disable !== false;
            await ((_a = this.selector) === null || _a === void 0 ? void 0 : _a.setDisableAsync(this.disabled));
        }
        async clearAsync() {
            var _a;
            await ((_a = this.selector) === null || _a === void 0 ? void 0 : _a.setValueAsync(undefined));
        }
        async getValueAsync() {
            var _a;
            return (_a = this.selector) === null || _a === void 0 ? void 0 : _a.getValue();
        }
        async getArrayValueAsync() {
            var _a;
            const value = (_a = this.selector) === null || _a === void 0 ? void 0 : _a.getValue();
            return value && value instanceof Array ? value : [value];
        }
        async getSingleValueAsync() {
            var _a;
            const value = (_a = this.selector) === null || _a === void 0 ? void 0 : _a.getValue();
            return value && value instanceof Array ? value.length > 0 ? value[0] : undefined : value;
        }
        async getTextAsync() {
            const value = await this.getValueAsync();
            if (value instanceof Array) {
                return this.options.filter(o => { var _a; return value.indexOf((_a = o.value) !== null && _a !== void 0 ? _a : "") >= 0; }).map(o => o.text);
            }
            else {
                const matchs = this.options.filter(o => o.value === value).map(o => o.text);
                return matchs.length > 0 ? matchs[0] : undefined;
            }
        }
        async getArrayTextAsync() {
            const value = await this.getValueAsync();
            if (value instanceof Array) {
                return this.options.filter(o => { var _a; return value.indexOf((_a = o.value) !== null && _a !== void 0 ? _a : "") >= 0; }).map(o => o.text);
            }
            else {
                const matchs = this.options.filter(o => o.value === value).map(o => o.text);
                return matchs.length > 0 ? [matchs[0]] : [];
            }
        }
        async getSingleTextAsync() {
            const value = await this.getSingleValueAsync();
            const matchs = this.options.filter(o => o.value === value).map(o => o.text);
            return matchs.length > 0 ? matchs[0] : undefined;
        }
        async setValueAsync(value) {
            if (this.selector) {
                await this.selector.setValueAsync(value instanceof Array ? value.map((o) => String(o)) : String(value));
            }
        }
    }
    exports.default = SelectElement;
});
define("test", ["require", "exports", "uform-form", "SelectElement"], function (require, exports, uform_form_2, SelectElement_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    async function testAsync() {
        const target = document.getElementById("test-form-0");
        if (target) {
            const form = new TestForm(target);
            await form.buildAsync();
        }
    }
    class TestForm extends uform_form_2.Form {
        async buildChildrenAsync() {
            const selector = await SelectElement_1.default.fromAsync({
                label: "選單",
                options: [{ text: "選項A", value: "a", subText: "subtext-a" }, { text: "選項B", value: "b" }, { text: "選項C", value: "c" }]
            });
            await this.appendAsync(selector);
            const output = await uform_form_2.InputElement.fromAsync({ label: "測試 output" });
            await this.appendAsync(output);
            const input = await uform_form_2.InputElement.fromAsync({ label: "測試 input" });
            await this.appendAsync(input);
            selector.addChangeFunc(async () => {
                const value = await selector.getSingleValueAsync();
                output.setValueAsync(value);
            });
            input.addChangeFunc(async () => {
                const value = await input.getValueAsync();
                if (value) {
                    selector.setValueAsync(value);
                }
            });
        }
    }
    testAsync();
});
define("uform-form-selector", ["require", "exports", "SelectElement"], function (require, exports, SelectElement_2) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.SelectElement = void 0;
    exports.SelectElement = SelectElement_2.default;
});
//# sourceMappingURL=test.js.map