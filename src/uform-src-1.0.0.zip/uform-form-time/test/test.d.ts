﻿declare module "TimeData" {
    export default interface TimeData {
        day: number;
        hour: number;
        minute: number;
        second: number;
    }
}
declare module "TimeElementOptions" {
    import { FormElementOptions } from "uform-form";
    export default interface TimeElementOptions extends FormElementOptions {
        mode?: "all" | "minuteAndSecond" | "hourAndMinute" | "dayAndHour" | "dayHourAndMinute" | "hourMinuteAndSecond";
        textAfterDay?: string;
        textAfterHour?: string;
        textAfterMinute?: string;
        textAfterSecond?: string;
        splitor?: string;
        defaultText?: string;
    }
}
declare module "TimeElement" {
    import TimeElementOptions from "TimeElementOptions";
    import TimeData from "TimeData";
    import { FormElementGeneric } from "uform-form";
    export default class TimeElement extends FormElementGeneric<TimeData> implements TimeElementOptions {
        mode: "all" | "minuteAndSecond" | "hourAndMinute" | "dayAndHour" | "dayHourAndMinute" | "hourMinuteAndSecond";
        textAfterDay: string;
        textAfterHour: string;
        textAfterMinute: string;
        textAfterSecond: string;
        splitor: string;
        defaultText: string;
        element: HTMLInputElement;
        timeContainer: HTMLDivElement;
        dayInput: HTMLInputElement;
        hourInput: HTMLInputElement;
        minuteInput: HTMLInputElement;
        secondInput: HTMLInputElement;
        textSpanAfterDay: HTMLSpanElement;
        textSpanAfterHour: HTMLSpanElement;
        textSpanAfterMinute: HTMLSpanElement;
        textSpanAfterSecond: HTMLSpanElement;
        minus: boolean;
        day: number;
        hour: number;
        minute: number;
        second: number;
        private get _showDayInput();
        private get _showHourInput();
        private get _showMinuteInput();
        private get _showSecondInput();
        constructor(options?: TimeElementOptions);
        static fromAsync(options: TimeElementOptions): Promise<TimeElement>;
        protected buildElementAsync(): Promise<void>;
        rebuildAsync(): Promise<void>;
        deleteAsync(): Promise<void>;
        validateAsync(): Promise<boolean>;
        setDisableAsync(disable?: boolean | undefined): Promise<void>;
        clearAsync(): Promise<void>;
        private _bindEvents;
        private _bindInputEvent;
        private _getStep;
        private _updateValueAsync;
        setValueAsync(value: TimeData | string | undefined): Promise<void>;
        getValueAsync(): Promise<TimeData>;
        getTotalSecondsAsync(): Promise<number>;
        getStringValueAsync(): Promise<string>;
    }
}
declare module "test" { }
declare module "uform-form-time" {
    import TimeData from "TimeData";
    import TimeElement from "TimeElement";
    import TimeElementOptions from "TimeElementOptions";
    export { TimeElement, TimeElementOptions, TimeData };
}
