import TimeElementOptions from "TimeElementOptions";
import TimeData from "TimeData";
import { FormElementGeneric } from "uform-form";

export default class TimeElement extends FormElementGeneric<TimeData> implements TimeElementOptions {
    mode: "all" | "minuteAndSecond" | "hourAndMinute" | "dayAndHour" | "dayHourAndMinute" | "hourMinuteAndSecond" = "all";
    textAfterDay: string = "天";
    textAfterHour: string = "時";
    textAfterMinute: string = "分";
    textAfterSecond: string = "秒";
    splitor: string = ":";
    defaultText: string = "請選擇";

    element: HTMLInputElement = document.createElement("input");
    timeContainer: HTMLDivElement = document.createElement("div");

    dayInput: HTMLInputElement = document.createElement("input");
    hourInput: HTMLInputElement = document.createElement("input");
    minuteInput: HTMLInputElement = document.createElement("input");
    secondInput: HTMLInputElement = document.createElement("input");

    textSpanAfterDay: HTMLSpanElement = document.createElement("span");
    textSpanAfterHour: HTMLSpanElement = document.createElement("span");
    textSpanAfterMinute: HTMLSpanElement = document.createElement("span");
    textSpanAfterSecond: HTMLSpanElement = document.createElement("span");

    minus: boolean = false;
    day: number = 0;
    hour: number = 0;
    minute: number = 0;
    second: number = 0;

    private get _showDayInput(): boolean { return this.mode === "all" || this.mode === "dayAndHour" || this.mode === "dayHourAndMinute" };
    private get _showHourInput(): boolean { return this.mode === "all" || this.mode === "dayAndHour" || this.mode === "dayHourAndMinute" || this.mode === "hourAndMinute" || this.mode === "hourMinuteAndSecond" };
    private get _showMinuteInput(): boolean { return this.mode === "all" || this.mode === "dayHourAndMinute" || this.mode === "minuteAndSecond" || this.mode === "hourAndMinute" || this.mode === "hourMinuteAndSecond" };
    private get _showSecondInput(): boolean { return this.mode === "all" || this.mode === "minuteAndSecond" || this.mode === "hourMinuteAndSecond" };

    constructor(options?: TimeElementOptions) {
        super(options);
        this.bindOptions(options);
    }

    static fromAsync(options: TimeElementOptions): Promise<TimeElement> {
        return <Promise<TimeElement>>new TimeElement(options).buildAsync();
    }

    protected async buildElementAsync(): Promise<void> {
        this.timeContainer.className = "time-container";
        this.container.appendChild(this.timeContainer);

        this.element.className = "time-text-input";
        this.element.readOnly = true;
        this.element.title = "Time";

        this.timeContainer.appendChild(this.element);
        this.timeContainer.appendChild(this.dayInput);
        this.timeContainer.appendChild(this.textSpanAfterDay);
        this.timeContainer.appendChild(this.hourInput);
        this.timeContainer.appendChild(this.textSpanAfterHour);
        this.timeContainer.appendChild(this.minuteInput);
        this.timeContainer.appendChild(this.textSpanAfterMinute);
        this.timeContainer.appendChild(this.secondInput);
        this.timeContainer.appendChild(this.textSpanAfterSecond);

        this.dayInput.className = "time-input day";
        this.dayInput.title = this.textAfterDay;
        this.dayInput.readOnly = true;
        this.dayInput.type = "number";
        this.hourInput.className = "time-input hour";
        this.hourInput.title = this.textAfterHour;
        this.hourInput.readOnly = true;
        this.hourInput.type = "number";
        this.minuteInput.className = "time-input minute";
        this.minuteInput.title = this.textAfterMinute;
        this.minuteInput.readOnly = true;
        this.minuteInput.type = "number";
        this.secondInput.className = "time-input second";
        this.secondInput.title = this.textAfterSecond;
        this.secondInput.readOnly = true;
        this.secondInput.type = "number";
        this.secondInput.step = "0.001";

        this.textSpanAfterDay.className = "time-text-span";
        this.textSpanAfterDay.innerText = this.textAfterDay;
        this.textSpanAfterHour.className = "time-text-span";
        this.textSpanAfterHour.innerText = this.textAfterHour;
        this.textSpanAfterMinute.className = "time-text-span";
        this.textSpanAfterMinute.innerText = this.textAfterMinute;
        this.textSpanAfterSecond.className = "time-text-span";
        this.textSpanAfterSecond.innerText = this.textAfterSecond;

        if (!this._showDayInput) {
            this.dayInput.classList.add("hide");
            this.textSpanAfterDay.classList.add("hide");
        } else {
            this.dayInput.classList.add("minusable");
            this.messageAnchor = this.dayInput;
        }

        if (!this._showHourInput) {
            this.hourInput.classList.add("hide");
            this.textSpanAfterHour.classList.add("hide");
        } else if (!this._showDayInput) {
            this.hourInput.classList.add("minusable");
            this.messageAnchor = this.hourInput;
        }

        if (!this._showMinuteInput) {
            this.minuteInput.classList.add("hide");
            this.textSpanAfterMinute.classList.add("hide");
        } else if (!this._showHourInput) {
            this.minuteInput.classList.add("minusable");
            this.messageAnchor = this.minuteInput;
        }

        if (!this._showSecondInput) {
            this.secondInput.classList.add("hide");
            this.textSpanAfterSecond.classList.add("hide");
        }

        this._bindEvents();
        await this._updateValueAsync();
    }

    async rebuildAsync(): Promise<void> {
        await this.clearAsync();
    }

    async deleteAsync(): Promise<void> {
        await this.removeMessageAsync();
        this.container.remove();
    }

    async validateAsync(): Promise<boolean> {
        return true;
    }

    async setDisableAsync(disable?: boolean | undefined): Promise<void> {
        this.disabled = disable !== false;
        this.dayInput.disabled = this.disabled === true;
        this.hourInput.disabled = this.disabled === true;
        this.minuteInput.disabled = this.disabled === true;
        this.secondInput.disabled = this.disabled === true;
    }

    async clearAsync(): Promise<void> {
        this.day = 0;
        this.hour = 0;
        this.minute = 0;
        this.second = 0;
        await this._updateValueAsync();
    }

    private _bindEvents(): void {
        if (this._showDayInput) {
            this._bindInputEvent(this.dayInput, false, 
                value => {
                    this.day += value;
                    this._updateValueAsync();
                },
                value => {
                    this.day = value;
                    this._updateValueAsync();
                },
                (value, toRight) => {
                    this.day = value;
                    this._updateValueAsync();

                    if (toRight) {
                        this.hourInput.focus();
                    }
                });
        }

        if (this._showHourInput) {
            this._bindInputEvent(this.hourInput, false, 
                value => {
                    const hour = this.hour + value;
                    this.hour = hour > 23 || hour < -23 ? 0 : hour;
                    this._updateValueAsync();
                },
                value => {
                    this.hour = value;
                    this._updateValueAsync();
                },
                (value, toRight) => {
                    this.hour = value;
                    this._updateValueAsync();

                    if (this._showMinuteInput && toRight) {
                        this.minuteInput.focus();
                    } else if (this._showDayInput && !toRight) {
                        this.dayInput.focus();
                    }
                });
        }
        
        if (this._showMinuteInput) {
            this._bindInputEvent(this.minuteInput, false, 
                value => {
                    const minute = this.minute + value;
                    this.minute = minute > 59 || minute < -59 ? 0 : minute;
                    this._updateValueAsync();
                },
                value => {
                    this.minute = value;
                    this._updateValueAsync();
                },
                (value, toRight) => {
                    this.minute = value;
                    this._updateValueAsync();

                    if (this._showSecondInput && toRight) {
                        this.secondInput.focus();
                    } else if (this._showHourInput && !toRight) {
                        this.hourInput.focus();
                    }
                });
        }

        if (this._showSecondInput) {
            this._bindInputEvent(this.secondInput, true, 
                value => {
                    const second = this.second + value;
                    this.second = second > 59 || second < -59 ? 0 : second;
                    this._updateValueAsync();
                },
                value => {
                    this.second = value;
                    this._updateValueAsync();
                },
                (value, toRight) => {
                    this.second = value;
                    this._updateValueAsync();

                    if (!toRight) {
                        this.minuteInput.focus();
                    }
                });
        }
    }

    private _bindInputEvent(input: HTMLInputElement, smallNumber: boolean, 
        wheelAction: (value: number) => void, 
        updateAction: (value: number) => void,
        completeAction: (value: number, toRight: boolean) => void): void {
        let focusing = false;
        let keyinCount = 0;
        let keyinValue = "";

        input.addEventListener("focus", () => {
            focusing = true;
            input.classList.add("focus");
        });

        input.addEventListener("blur", () => {
            focusing = false;
            keyinValue = "";
            keyinCount = 0;
            input.classList.remove("focus");
        });

        input.addEventListener("wheel", wheelEvent => {
            const step = this._getStep(input, wheelEvent.ctrlKey, wheelEvent.shiftKey);
            wheelAction(wheelEvent.deltaY < 0 ? step : -1 * step);
        });

        input.addEventListener("keyup", keyboardEvent => {
            if (focusing) {
                keyboardEvent.preventDefault();
                if (keyboardEvent.key === "-") {
                    keyinValue = "-";
                    keyinCount = 0;
                    input.value = "-";
                } else if (keyboardEvent.key === "." && smallNumber) {
                    keyinValue += ".";
                } else if (!isNaN(Number(keyboardEvent.key))) {
                    keyinValue += keyboardEvent.key;
                    if (!smallNumber) {
                        keyinCount++;
                        
                        if (keyinCount > 1) {
                            completeAction(Number(keyinValue), true);
                            keyinCount = 0;
                            keyinValue = "";
                        } else {
                            updateAction(Number(keyinValue));
                        }
                    } else {
                        updateAction(Number(keyinValue));
                    }
                } else if (keyboardEvent.code === "ArrowRight") {
                    keyinValue = input.value;
                    completeAction(Number(keyinValue), true);
                } else if (keyboardEvent.code === "ArrowLeft") {
                    keyinValue = input.value;
                    completeAction(Number(keyinValue), false);
                } else if (keyboardEvent.code === "ArrowUp") {
                    const step = this._getStep(input, keyboardEvent.ctrlKey, keyboardEvent.shiftKey);
                    wheelAction(step);
                } else if (keyboardEvent.code === "ArrowDown") {
                    const step = this._getStep(input, keyboardEvent.ctrlKey, keyboardEvent.shiftKey);
                    wheelAction(step * -1);
                } else if (keyboardEvent.code === "Backspace") {
                    keyinValue = input.value;
                    if (keyinValue.length <= 1) {
                        keyinValue = "";
                        keyinCount = 0;
                        updateAction(0);
                    } else {
                        keyinValue = keyinValue.substring(0, keyinValue.length - 1);
                        if (!smallNumber) {
                            keyinCount--;
                        }
                        updateAction(Number(keyinValue));
                    }
                } else if (keyboardEvent.code === "Delete") {
                    keyinValue = "";
                    keyinCount = 0;
                    updateAction(0);
                }
            }
        });
    }

    private _getStep(input: HTMLInputElement, ctrlKey: boolean, shiftKey: boolean): number {
        const array = input.value.split(".");
        let step = 0;
        if (array.length === 1) {
            step = 1;
        } else {
            if (array[1].length === 1) {
                step = 0.1;
            } else if (array[1].length === 2) {
                step = 0.01;
            } else {
                step = 0.001;
            }
        }

        if (ctrlKey) {
            step *= 10;
        }

        if (shiftKey) {
            step *= 100;
        }

        return step;
    }

    private async _updateValueAsync(): Promise<void> {
        this.day = this.day && !isNaN(this.day) ? Math.floor(this.day) : 0;
        this.hour = this.hour && !isNaN(this.hour) ? Math.floor(this.hour) : 0;
        this.minute = this.minute && !isNaN(this.minute) ? Math.floor(this.minute) : 0;
        this.second = this.second && !isNaN(this.second) ? Math.round(this.second * 1000) / 1000 : 0;

        if (this.mode !== "all" && this.mode !== "dayAndHour" && this.mode !== "dayHourAndMinute") {
            this.day = 0;
        }

        if (this.hour > 23 || this.hour < -23 || this.mode === "minuteAndSecond") {
            this.hour = 0;
        }

        if (this.minute > 59 || this.minute < -59 || this.mode === "dayAndHour") {
            this.minute = 0;
        }

        if (this.second >= 60 || this.second <= -60 || this.mode !== "all" && this.mode !== "minuteAndSecond" && this.mode !== "hourMinuteAndSecond") {
            this.second = 0;
        }

        this.dayInput.value = String(this.day);
        this.hourInput.value = String(this.hour);
        this.minuteInput.value = String(this.minute);
        this.secondInput.value = String(this.second);

        const absDay = Math.abs(this.day);
        const absHour = Math.abs(this.hour);
        const absMinute = Math.abs(this.minute);
        const absSecond = Math.abs(this.second);

        const texts: string[] = [];
        if (this.mode === "minuteAndSecond") {
            texts.push(absMinute >= 10 ? String(absMinute) : `0${absMinute}`);
            texts.push(absSecond >= 10 ? String(absSecond) : `0${absSecond}`);
        } else if (this.mode === "hourAndMinute") {
            texts.push(absHour >= 10 ? String(absHour) : `0${absHour}`);
            texts.push(absMinute >= 10 ? String(absMinute) : `0${absMinute}`);
        } else if (this.mode === "dayHourAndMinute") {
            texts.push(String(absDay));
            texts.push(absHour >= 10 ? String(absHour) : `0${absHour}`);
            texts.push(absMinute >= 10 ? String(absMinute) : `0${absMinute}`);
        } else if (this.mode === "hourMinuteAndSecond") {
            texts.push(absHour >= 10 ? String(absHour) : `0${absHour}`);
            texts.push(absMinute >= 10 ? String(absMinute) : `0${absMinute}`);
            texts.push(absSecond >= 10 ? String(absSecond) : `0${absSecond}`);
        } else if (this.mode === "dayAndHour") {
            texts.push(String(absDay));
            texts.push(absHour >= 10 ? String(absHour) : `0${absHour}`);
        } else {
            texts.push(String(absDay));
            texts.push(absHour >= 10 ? String(absHour) : `0${absHour}`);
            texts.push(absMinute >= 10 ? String(absMinute) : `0${absMinute}`);
            texts.push(absSecond >= 10 ? String(absSecond) : `0${absSecond}`);
        }

        this.minus = this.day < 0 || this.hour < 0 || this.minute < 0 || this.second < 0;

        this.element.value = `${this.minus ? "-" : ""}${texts.join(this.splitor)}`
        await this.changeAsync();
    }

    async setValueAsync(value: TimeData | string | undefined): Promise<void> {
        if (value === undefined || value === null) {
            await this.clearAsync();
        } else if (typeof(value) === "string") {
            const array = value.split(this.splitor).map(o => o.length > 0 ? Number(o) : 0);
            if (this.mode === "minuteAndSecond") {
                this.minute = array[0];
                this.second = array[1];
            } else if (this.mode === "hourAndMinute") {
                this.hour = array[0];
                this.minute = array[1];
            } else if (this.mode === "dayHourAndMinute") {
                this.day = array[0];
                this.hour = array[1];
                this.minute = array[2];
            } else if (this.mode === "hourMinuteAndSecond") {
                this.hour = array[0];
                this.minute = array[1];
                this.second = array[2];
            } else if (this.mode === "dayAndHour") {
                this.day = array[0];
                this.hour = array[1];
            } else {
                this.day = array[0];
                this.hour = array[1];
                this.minute = array[2];
                this.second = array[3];
            }

            await this._updateValueAsync();
        } else {
            this.day = value.day;
            this.hour = value.hour;
            this.minute = value.minute;
            this.second = value.second;
            await this._updateValueAsync();
        }
    }

    async getValueAsync(): Promise<TimeData> {
        return {
            day: this.day,
            hour: this.hour,
            minute: this.minute,
            second: this.second
        };
    }

    async getTotalSecondsAsync(): Promise<number> {
        const absDay = Math.abs(this.day);
        const absHour = Math.abs(this.hour);
        const absMinute = Math.abs(this.minute);
        const absSecond = Math.abs(this.second);

        return (absDay * 86400 + absHour * 3600 + absMinute * 60 + absSecond) * (this.minus ? -1 : 1);
    }

    async getStringValueAsync(): Promise<string> {
        return this.element.value;
    }
}