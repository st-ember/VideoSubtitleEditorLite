
export default interface TimeData {
    day: number,
    hour: number,
    minute: number,
    second: number
}