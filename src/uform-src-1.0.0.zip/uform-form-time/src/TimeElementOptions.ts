import { FormElementOptions } from "uform-form";

export default interface TimeElementOptions extends FormElementOptions {
    mode?: "all" | "minuteAndSecond" | "hourAndMinute" | "dayAndHour" | "dayHourAndMinute" | "hourMinuteAndSecond";
    textAfterDay?: string;
    textAfterHour?: string;
    textAfterMinute?: string;
    textAfterSecond?: string;
    splitor?: string;
    defaultText?: string;
}