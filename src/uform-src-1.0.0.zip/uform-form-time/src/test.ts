import { Form, InputElement } from "uform-form";
import TimeElement from "./TimeElement";

async function testAsync(): Promise<void> {
    const target = document.getElementById("test-form-0");
    if (target) {
        const form = new TestForm(target);
        await form.buildAsync();
    }
}

class TestForm extends Form {
    
    async buildChildrenAsync(): Promise<void> {
        
        const timeInput = await TimeElement.fromAsync({
            mode: "minuteAndSecond",
            label: "時間",
            disabled: false
        });
        await this.appendAsync(timeInput);

        const output = await InputElement.fromAsync({ label: "測試 output" });
        await this.appendAsync(output);

        const input = await InputElement.fromAsync({ label: "測試 input" });
        await this.appendAsync(input);

        timeInput.addChangeFunc(async () => {
            const value = await timeInput.getStringValueAsync();
            output.setValueAsync(value);
        });

        input.addChangeFunc(async () => {
            const value = await input.getValueAsync();
            if (value) {
                timeInput.setValueAsync(value);
            }
        });
    }
}

testAsync();