import SelectOption from "SelectOption";

export default interface SelectorOptionItem extends SelectOption {
    type: "OPTION" | "OPTGROUP";
    selected?: boolean;
    disabled?: boolean;
    hidden?: boolean;
    isAllOption?: boolean;
    isDefaultOption?: boolean;
    isExclusive?: boolean;

    children?: SelectorOptionItem[];
}