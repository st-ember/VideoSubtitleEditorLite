
export default interface SelectOption {
    value?: string;
    text?: string;
    subText?: string;
}