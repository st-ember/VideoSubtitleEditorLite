import { selectorController } from "SelectorController";
import SelectorOption from "SelectorOption";
import SelectorOptionGroup from "SelectorOptionGroup";
import SelectorOptionItem from "SelectorOptionItem";
import SelectorOptions from "SelectorOptions";
import dropdownController, { Dropdown } from "uform-dropdown";

export default class Selector {

    id: number = -1;
    multiple: boolean = false;
    showAllItemText: boolean = false;
    max: number = 0;
    search?: boolean = undefined;
    element: HTMLSelectElement;
    selectedCount: number = 0;
    warningShowing: boolean = false;
    maxWidth: number = 0;
    /** 只有在關閉下拉選單時才觸發 Change 事件。 */
    changeWhenClose: boolean = false;
    /** 未選擇任何項目時的預設文字。 */
    emptyText: string = "未選擇";
    /** 在單選的狀態下是否允許無值的狀態。 */
    allowEmpty: boolean = false;

    options?: SelectorOptions;

    dropdown?: Dropdown;
    button?: HTMLButtonElement;
    buttonText?: HTMLSpanElement;
    searchInput?: HTMLInputElement;
    warningGroup?: HTMLDivElement;

    children: (SelectorOption | SelectorOptionGroup)[] = [];
    allOption?: SelectorOption;
    onChangeFuncs: (() => void)[] = [];

    private _focused?: SelectorOption | SelectorOptionGroup;
    private _pendingChanges: boolean = false;

    constructor(selectElement: HTMLSelectElement, id: number, options?: SelectorOptions) {
        this.id = id;
        this.element = selectElement;
        this.options = options;
        this._updateOptions();
    }

    init(): void {
        this._hideSelectElement();
        this._initButton();
        this._initDropdown();
        this._initChildren();
        this._initItems();
        this._initSearch();
        this._initWarning();
        this._initHooks();

        this.element.addEventListener("change", () => this.updateAsync());

        const currentValue = this.getValue();
        if (!currentValue || this.multiple && currentValue.length === 0) {
            this.children.forEach(child => {
                if (child.type === "OPTION") {
                    if (child.isDefaultOption) {
                        if (child.isAllOption && !child.isExclusive) {
                            this.setAll(true);
                        } else {
                            child.set(true);
                        }
                    }
                } else if (child.type === "OPTGROUP") {
                    child.options.forEach(option => {
                        if (option.isDefaultOption) {
                            child.set(true);
                        }
                    });
                }
            });
        }
    }

    async updateAsync(): Promise<void> {
        this._updateOptions();
        this._processSelectElement();
        this._updateChildren();
        this._updateButton();
        this._updateWarning();
        await this._updateDropdownAsync();
    }

    async removeAsync(): Promise<void> {
        if (this.button) {
            await dropdownController.removeAsync(this.button, "selector");
            this.button.remove();
        }
        this._hideSelectElement(false);
    }

    async changeAsync(): Promise<void> {
        await this.updateAsync();
        if (!this.changeWhenClose) {
            this.onChangeFuncs.forEach(func => func());
        } else {
            this._pendingChanges = true;
        }
    }

    private _hideSelectElement(value?: boolean): void {
        this.element.style.display = value !== false ? "none" : "";
    }

    private _initButton(): void {
        if (!this.button) {
            const button = document.createElement("button");
            button.type = "button";
            button.className = "selector-trigger";

            this.button = button;
            this.element.parentElement?.insertBefore(button, this.element);

            const buttonTextContainer = document.createElement("span");
            buttonTextContainer.className = "trigger-text-container";
            this.button.appendChild(buttonTextContainer);

            const buttonText = document.createElement("span");
            buttonText.className = "trigger-text";
            this.buttonText = buttonText;
            buttonTextContainer.appendChild(buttonText);

            if (this.maxWidth && this.maxWidth > 0) {
                buttonText.style.maxWidth = `${this.maxWidth}px`;
            }

            const arrow = document.createElement("span");
            arrow.className = "trigger-arrow";
            buttonTextContainer.appendChild(arrow);
        }
    }

    private _initDropdown(): void {
        if (!this.dropdown && this.button) {
            this.dropdown = dropdownController.add({ tag: "selector", target: this.button });
            this.dropdown.onOpenStatusChangeFuncs.push(() => {
                if (this._pendingChanges && this.changeWhenClose) {
                    this.onChangeFuncs.forEach(func => func());
                }
            });
        }
    }

    private _initChildren(): void {
        const children = [];
        const childrenElements = this.element.children;
        if (childrenElements.length === 0 && this.options && this.options.items) {
            for (let i = 0; i < this.options.items.length; i++) {
                const childOptions = this.options.items[i];
                if (childOptions.type === "OPTION") {
                    const childElement = document.createElement("option");
                    this.element.appendChild(childElement);

                    const option = new SelectorOption(this, childElement, childOptions);
                    option.init();
                    children.push(option);
                } else if (childOptions.type === "OPTGROUP") {
                    const childElement = document.createElement("optgroup");
                    this.element.appendChild(childElement);

                    const optionGroup = new SelectorOptionGroup(this, childElement, childOptions);
                    optionGroup.init();
                    children.push(optionGroup);
                }
            }
        } else {
            for (let i = 0; i < childrenElements.length; i++) {
                const childElement = childrenElements.item(i);
                if (!childElement) { continue; }

                if (childElement.tagName === "OPTION") {
                    const option = new SelectorOption(this, <HTMLOptionElement>childElement);
                    option.init();
                    children.push(option);
                } else if (childElement.tagName === "OPTGROUP") {
                    const optionGroup = new SelectorOptionGroup(this, <HTMLOptGroupElement>childElement);
                    optionGroup.init();
                    children.push(optionGroup);
                }
            }
        }

        this.children = children;
    }

    private _initItems(): void {
        this.dropdown?.clearBody();
        this.children
            .filter(child => !!child.menuElement)
            .forEach(child => this.dropdown?.body.appendChild(child.menuElement!));
    }

    private _initSearch(): void {
        if (this.searchInput) {
            return;
        }

        const searchGroup = document.createElement("div");
        searchGroup.className = "selector-search-group";
        searchGroup.innerHTML = selectorController.searchIconSvg;
        this.dropdown?.head.appendChild(searchGroup);

        const input = document.createElement("input");
        input.type = "text";
        input.className = "selector-search-input";
        input.autocomplete = "off";
        input.placeholder = "搜尋";
        searchGroup.appendChild(input);
        this.searchInput = input;

        let oldValue = "";
        let timer: number | undefined = undefined;
        input.addEventListener("focus", () => {
            if (!timer) {
                timer = setInterval(async () => {
                    let value = input.value;
                    if (oldValue !== value) {
                        oldValue = value;
                        await this.searchAsync(value);
                    }
                }, 100);
            }
        });

        input.addEventListener("blur", () => {
            if (timer) {
                clearInterval(timer);
                timer = undefined;
            }
        });

        let childCount = 0;
        this.children.forEach(child => {
            if (child.type === "OPTION") {
                childCount++;
            } else if (child.type === "OPTGROUP") {
                childCount += child.options.length;
            }
        });

        if (this.search === false || this.search === undefined && childCount < 10) {
            searchGroup.style.display = "none";
        }
    }

    private _initWarning(): void {
        if (!this.warningGroup) {
            const warningGroup = document.createElement("div");
            warningGroup.className = "selector-warning-group selector-hidden";
            warningGroup.innerText = "";
            this.warningGroup = warningGroup;
            this.dropdown?.head.appendChild(warningGroup);
        }
    }

    private _initHooks(): void {
        this.dropdown?.onDownKeyPressFuncs.push(() => this.focusDown());
        this.dropdown?.onUpKeyPressFuncs.push(() => this.focusUp());
        this.dropdown?.onEnterKeyPressFuncs.push(() => {
            if (this._focused) {
                this._focused.clickAsync();
            }
        });

        this.dropdown?.onSpaceKeyPressFuncs.push(() => {
            if (this._focused) {
                this._focused.clickAsync();
            }
        });

        this.children.forEach(child => {
            child.onHoverFuncs.push((c: SelectorOption | SelectorOptionGroup) => this.onChildFocus(c));
            child.onBlurFuncs.push((c: SelectorOption | SelectorOptionGroup) => this.onChildBlur(c));

            if (child.type === "OPTGROUP") {
                child.options.forEach(child => {
                    child.onHoverFuncs.push(c => this.onChildFocus(c));
                    child.onBlurFuncs.push(c => this.onChildBlur(c));
                });
            }
        });

        if (this.options && this.options.onChange) {
            this.onChangeFuncs.push(() => this.options!.onChange!(this));
        }

        this.dropdown?.onOpenStatusChangeFuncs.push(() => {
            if (this.dropdown?.opened) {
                this.button?.classList.add("menu-opened");
                setTimeout(() => this.searchInput?.focus(), 100);
                if (this.options?.onOpen) {
                    this.options?.onOpen(this);
                }
            } else {
                this.button?.classList.remove("menu-opened");
                this._updateWarning();
                if (this.options?.onClose) {
                    this.options?.onClose(this);
                }
            }
        });
    }

    private _updateOptions(): void {
        if (this.options) {
            if (!this.element.multiple && this.options.multiple === true) {
                this.element.multiple = true;
            }

            if (this.element.multiple && !this.element.hasAttribute("data-show-all-item-text") && this.showAllItemText !== undefined && this.showAllItemText !== null) {
                this.element.setAttribute("data-show-all-item-text", this.options.showAllItemText ? "true" : "false");
            }

            if (!this.element.hasAttribute("data-max") && this.options.max !== undefined && this.options.max !== null && this.options.max >= 0) {
                this.element.setAttribute("data-max", String(this.options.max));
            }

            if (!this.element.hasAttribute("data-search") && this.options.search !== undefined && this.options.search !== null) {
                this.element.setAttribute("data-search", this.options.search === true ? "true" : "false");
            }

            if (!this.element.hasAttribute("data-max-width") && this.options.maxWidth !== undefined && this.options.maxWidth !== null && this.options.maxWidth > 0) {
                this.element.setAttribute("data-max-width", String(this.options.maxWidth));
            }

            if (!this.element.hasAttribute("data-empty-text") && this.options.emptyText) {
                this.element.setAttribute("data-empty-text", this.options.emptyText);
            }

            if (!this.element.multiple && !this.element.hasAttribute("data-allow-empty") && this.allowEmpty !== undefined && this.allowEmpty !== null) {
                this.element.setAttribute("data-allow-empty", this.options.allowEmpty ? "true" : "false");
            }

            const childrenElements = this.element.children;
            if (childrenElements.length === 0 && this.options.items) {
                this.options.items
                    .filter(optionItem => !!optionItem)
                    .forEach(optionItem => {
                        this.element.appendChild(optionItem.type === "OPTGROUP" ?
                            this._buildOptionGroupFromOptionItem(optionItem) :
                            this._buildOptionFromOptionItem(optionItem));
                    });
            }

            this.changeWhenClose = this.options.changeWhenClose === true;
        } else {
            this.options = {
                select: this.element
            };
        }

        this.multiple = this.element.multiple;

        if (this.element.hasAttribute("data-show-all-item-text")) {
            const showAllItemText = this.element.getAttribute("data-show-all-item-text")!.toLowerCase();
            this.showAllItemText = showAllItemText === "true";
        }

        if (this.dropdown) {
            if (this.multiple) {
                this.dropdown?.element.classList.add("selector-multiple");
            } else {
                this.dropdown?.element.classList.remove("selector-multiple");
            }
        }
        
        if (this.element.hasAttribute("data-max")) {
            const dataMax = Number(this.element.getAttribute("data-max"));
            this.max = !isNaN(dataMax) && dataMax >= 0 ? dataMax : 0;
        }

        if (this.element.hasAttribute("data-search")) {
            const search = this.element.getAttribute("data-search")!.toLowerCase();
            this.search = search === "true";
        }

        if (this.element.hasAttribute("data-max-width")) {
            const maxWidth = this.element.getAttribute("data-max-width");
            this.maxWidth = Number(maxWidth);
        }

        if (this.element.hasAttribute("data-empty-text")) {
            this.emptyText = this.element.getAttribute("data-empty-text")!;
        }

        if (this.element.hasAttribute("data-allow-empty")) {
            const allowEmpty = this.element.getAttribute("data-allow-empty")!.toLowerCase();
            this.allowEmpty = allowEmpty === "true";
        }
    }

    private _buildOptionFromOptionItem(optionItem: SelectorOptionItem): HTMLOptionElement {
        const element = document.createElement("option");
        element.innerText = optionItem.text?.trim() ?? "";
        element.value = optionItem.value ?? "";
        element.selected = optionItem.selected === true;
        element.disabled = optionItem.disabled === true;

        if (optionItem.subText) {
            element.setAttribute("data-subtext", optionItem.subText);
        }

        if (optionItem.isAllOption === true) {
            element.setAttribute("data-all", "true");
        }

        if (optionItem.isDefaultOption === true) {
            element.setAttribute("data-default", "true");
        }

        if (optionItem.isExclusive === true) {
            element.setAttribute("data-exclusive", "true");
        }

        return element;
    }

    private _buildOptionGroupFromOptionItem(optionItem: SelectorOptionItem): HTMLOptGroupElement {
        const element = document.createElement("optgroup");
        element.label = optionItem.text ?? "";
        element.disabled = optionItem.disabled ?? false;

        if (optionItem.children && optionItem.children.length > 0) {
            optionItem.children
                .filter(childOptions => !!childOptions)
                .forEach(childOptions => {
                    element.appendChild(childOptions.type === "OPTGROUP" ?
                        this._buildOptionGroupFromOptionItem(childOptions) :
                        this._buildOptionFromOptionItem(childOptions));
                });
        }

        return element;
    }

    private _updateButton(): void {
        if (this.multiple) {
            let totalSelectedCount = 0;
            const selectedOptionNames: string[] = [];
            this.children.forEach(child => {
                if (child.type === "OPTION" && child.selected) {
                    totalSelectedCount++;
                    selectedOptionNames.push(child.text);
                } else if (child.type === "OPTGROUP" && child.selectedCount > 0) {
                    totalSelectedCount += child.selectedCount;
                    child.listSelectedOption().forEach(option => selectedOptionNames.push(option.text));
                }
            });

            if (this.buttonText && this.button) {
                if (totalSelectedCount === 1) {
                    this.buttonText.innerText = selectedOptionNames[0];
                    this.button.title = selectedOptionNames[0];
                } else {
                    if (totalSelectedCount === 0) {
                        this.buttonText.innerText = this.emptyText;
                        this.button.title = this.emptyText;
                    } else {
                        this.buttonText.innerText = !this.showAllItemText ? `共選擇 ${totalSelectedCount} 個項目` : selectedOptionNames.join(", ");
                        this.button.title = selectedOptionNames.join(", ");
                    }
                }
            }
        } else {
            let text = this.emptyText;
            for (let i = 0; i < this.children.length; i++) {
                const child = this.children[i];
                if (child.type === "OPTION") {
                    if (child.selected) {
                        text = child.text;
                        break;
                    }
                } else if (child.type === "OPTGROUP") {
                    const list = child.listSelectedOption();
                    if (list.length > 0) {
                        text = list[0].text;
                        break;
                    }
                }
            }

            if (this.buttonText && this.button) {
                this.buttonText.innerText = text;
                this.button.title = text;
            }
        }
    }

    private async _updateDropdownAsync(): Promise<void> {
        if (this.dropdown) {
            await this.dropdown.updateAsync();
        }
    }

    private _updateChildren(): void {
        this.children.forEach(child => child.update());
    }

    private _updateWarning(): void {
        if (this.warningShowing) {
            if (this.warningGroup) {
                this.warningGroup.innerText = "選擇的數量不可超過 " + this.max + " 個";
                this.warningGroup.classList.remove("selector-hidden");
            }
            
            this.warningShowing = false;
        } else {
            this.warningGroup?.classList.add("selector-hidden");
        }
    }

    private _processSelectElement(): void {
        if (this.multiple) {
            const selectedOptionElements = this.element.querySelectorAll("option:checked");
            let selectedCount = 0;
            for (let i = 0; i < selectedOptionElements.length; i++) {
                if (this.max !== undefined && this.max > 0 && i >= this.max) {
                    const option = <HTMLOptionElement>selectedOptionElements.item(i);
                    option.selected = false;
                } else {
                    selectedCount++;
                }
            }

            this.selectedCount = selectedCount;
        } else if (!this.multiple) {
            this.selectedCount = 1;
        }
    }
    
    setAllOption(option: SelectorOption): void {
        if (!this.allOption) {
            this.allOption = option;
        }
    }

    setAll(selected: boolean): void {
        if (selected) {
            if (this.allOption && this.allOption.isExclusive) {
                this.allOption.set(true);
                this.children.forEach(child => child.set(false));
            } else {
                this.children.forEach(child => child.set(true));
            }
        } else {
            this.children.forEach(child => child.set(false));
        }
    }

    unselectExclusiveOptions(): void {
        this.children.forEach(child => {
            if (child.type === "OPTION" && child.isExclusive) {
                child.set(false);
            } else if (child.type === "OPTGROUP") {
                child.unselectExclusiveOptions();
            }
        });
    }

    async searchAsync(text: string): Promise<void> {
        if (text) {
            const searchText = text.toLowerCase();

            if (this.dropdown) {
                this.dropdown.element.style.minWidth = (this.button?.clientWidth ?? 0) + "px";
            }
            
            this.children.forEach((child) => {
                if (child.type === "OPTION") {
                    child.show(child.isMatch(searchText));
                } else if (child.type === "OPTGROUP") {
                    if (child.isMatch(searchText)) {
                        child.show();
                        child.options.forEach(option => option.show());
                    } else {
                        let matchCount = 0;
                        child.options.forEach(option => {
                            const match = option.isMatch(searchText);
                            if (match) {
                                matchCount++;
                            }
                            option.show(match);
                        });

                        child.show(matchCount > 0);
                    }
                }
            });
        } else {
            if (this.dropdown) {
                this.dropdown.element.style.minWidth = "";
            }
            
            this.children.forEach(child => {
                child.show();
                if (child.type === "OPTGROUP") {
                    child.options.forEach(option => option.show());
                }
            });
        }

        await this._updateDropdownAsync();
    }

    searchValues(texts: string[]): (SelectorOption | SelectorOptionGroup)[] {
        const matchs: (SelectorOption | SelectorOptionGroup)[] = [];
        this.children.forEach(child => {
            if (child.type === "OPTION") {
                if (child.isMatchValues(texts)) {
                    matchs.push(child);
                }
            } else if (child.type === "OPTGROUP") {
                child.searchValues(texts).forEach(option => matchs.push(option));
            }
        });

        return matchs;
    }

    async triggerAsync(): Promise<void> {
        await this.dropdown?.openAsync(!!this.button && !this.button.disabled && !this.element.disabled && !this.dropdown.opened);
    }

    isAllowSelect(): boolean {
        return !this.multiple || this.max === 0 || this.max > 0 && this.selectedCount < this.max;
    }

    showWarning(value: boolean): void {
        this.warningShowing = value !== false;
    }

    getValue(): string | string[] | undefined {
        if (this.multiple) {
            const values: string[] = [];
            const selectedOptionElements = this.element.querySelectorAll("option:checked");
            for (let i = 0; i < selectedOptionElements.length; i++) {
                const option = <HTMLOptionElement>selectedOptionElements.item(i);
                const value = option.value;
                const text = option.innerText;
                values.push(value !== undefined ? value : text);
            }

            return values;
        } else {
            const selectedOptionElements = this.element.querySelectorAll("option:checked");
            const option = <HTMLOptionElement>(selectedOptionElements.length > 0 ? selectedOptionElements.item(0) : undefined);
            if (option) {
                return option.value !== undefined ? option.value : option.innerText;
            } else {
                return undefined;
            }
        }
    }

    async setValueAsync(value: string | string[] | undefined): Promise<void> {
        const newValues = value ? (typeof value === "string" ? [value] : value) : [];

        if (this.multiple) {
            this.children.forEach(child => {
                if (child.type === "OPTION") {
                    const isMatchs = child.isMatchValues(newValues);
                    if (child.selected !== isMatchs) {
                        child.set(isMatchs);
                    }
                } else if (child.type === "OPTGROUP") {
                    child.options.forEach(option => {
                        const isMatchs = option.isMatchValues(newValues);
                        if (option.selected !== isMatchs) {
                            option.set(isMatchs);
                        }
                    });
                }
            });

            await this.updateAsync();
        } else {
            let matchChildren = this.searchValues(newValues);
            if (matchChildren.length > 0) {
                matchChildren[0].set(true);
            } else if (!this.allowEmpty) {
                this._getFlatItems().forEach((item, index) => item.set(index === 0));
            } else {
                this.element.value = "";
            }
            
            await this.updateAsync();
        }
    }

    async setDisableAsync(value?: boolean): Promise<void> {
        if (this.button) {
            this.button.disabled = value !== false;
        }

        this.element.disabled = value !== false;

        if (this.dropdown) {
            this.dropdown.disabled = value !== false;
            if (this.dropdown.opened) {
                await this.dropdown.openAsync(false);
            }
        }
    }

    cancelFocus(): void {
        if (this._focused) {
            this._focused.blur();
            this._focused = undefined;
        }
    }

    focusDown(): void {
        const next = this._findNext(this._focused);

        if (this._focused) {
            this._focused.blur();
            this._focused = undefined;
        }

        if (next) {
            this._focused = next;
            this._focused.focus();
        }
    }

    focusUp(): void {
        const prev = this._findPrev(this._focused);

        if (this._focused) {
            this._focused.blur();
            this._focused = undefined;
        }

        if (prev) {
            this._focused = prev;
            this._focused.focus();
        }
    }

    onChildFocus(child: SelectorOption | SelectorOptionGroup): void {
        if (this._focused) {
            this._focused.blur();
        }

        this._focused = child;
        this._focused.focus();
    }

    onChildBlur(child: SelectorOption | SelectorOptionGroup): void {
        child.blur();

        if (this._focused && this._focused.isSameNode(child)) {
            this._focused.blur();
            this._focused = undefined;
        }
    }

    private _getFlatItems(): (SelectorOption | SelectorOptionGroup)[] {
        const list: (SelectorOption | SelectorOptionGroup)[] = [];
        this.children.forEach(child => {
            list.push(child);
            if (child.type === "OPTGROUP") {
                child.options.forEach(o => list.push(o));
            }
        });
        return list;
    }

    private _findNext(current?: SelectorOption | SelectorOptionGroup): SelectorOption | SelectorOptionGroup | undefined {
        const flatOptionItems = this._getFlatItems();
        if (current) {
            let index = -1;
            for (let i = 0; i < flatOptionItems.length; i++) {
                if (flatOptionItems[i].isSameNode(current)) {
                    index = i;
                    break;
                }
            }

            if (index >= 0) {
                for (let i = index + 1; i < flatOptionItems.length; i++) {
                    if (flatOptionItems[i].isSelectable()) {
                        return flatOptionItems[i];
                    }
                }
            }
        }

        for (let i = 0; i < flatOptionItems.length; i++) {
            if (flatOptionItems[i].isSelectable()) {
                return flatOptionItems[i];
            }
        }
    }

    private _findPrev(current?: SelectorOption | SelectorOptionGroup): SelectorOption | SelectorOptionGroup | undefined {
        const flatOptionItems = this._getFlatItems();
        if (current) {
            let index = -1;
            for (let i = 0; i < flatOptionItems.length; i++) {
                if (flatOptionItems[i].isSameNode(current)) {
                    index = i;
                    break;
                }
            }

            if (index >= 0) {
                for (let i = index - 1; i >= 0; i--) {
                    if (flatOptionItems[i].isSelectable()) {
                        return flatOptionItems[i];
                    }
                }
            }
        }

        for (let i = flatOptionItems.length - 1; i >= 0; i--) {
            if (flatOptionItems[i].isSelectable()) {
                return flatOptionItems[i];
            }
        }
    }

    getChild(index: number): SelectorOption | SelectorOptionGroup | undefined {
        return this.children.length <= index || index < 0 ? undefined : this.children[index];
    }

    getOption(value: string): SelectorOption | undefined;
    getOption(index: number): SelectorOption | undefined;
    getOption(value: string | number): SelectorOption | undefined {
        if (typeof value === "string") {
            const matchs = <SelectorOption[]>this.children.filter(o => o.type === "OPTION" && o.value === value);
            return matchs.length > 0 ? matchs[0] : undefined;
        } else {
            const options = <SelectorOption[]>this.children.filter(child => child.type === "OPTION");
            return options.length <= value || value < 0 ? undefined : options[value];
        }
    }

    getOptionGroup(index: number): SelectorOptionGroup | undefined {
        const groups = <SelectorOptionGroup[]>this.children.filter(child => child.type === "OPTGROUP");
        return groups.length <= index || index < 0 ? undefined : groups[index];
    }

    getOptionIndex(value: string): number {
        return this.children.findIndex(o => o.type === "OPTION" && o.value === value);
    }

    insertOption(index: number, value: string, html: string, subtext?: string, exclusive?: boolean): SelectorOption {
        const optionElement = document.createElement("option");
        optionElement.value = value;
        optionElement.innerHTML = html;

        if (subtext) {
            optionElement.setAttribute("data-subtext", subtext);
        }

        if (exclusive === true) {
            optionElement.setAttribute("data-exclusive", "true");
        }

        const refChild = this.getChild(index);
        if (refChild) {
            this.element.insertBefore(optionElement, refChild.element);
        } else {
            this.element.appendChild(optionElement);
        }

        const option = new SelectorOption(this, optionElement, {
            type: "OPTION",
            value,
            text: html,
            subText: subtext ?? "",
            isExclusive: exclusive === true
        });
        option.init();

        if (this.dropdown && option.menuElement) {
            if (refChild && refChild.menuElement) {
                this.dropdown.body.insertBefore(option.menuElement, refChild.menuElement);
                this.children.splice(index, 0, option);
            } else {
                this.dropdown.body.appendChild(option.menuElement);
                this.children.push(option);
            }
        }

        option.onHoverFuncs.push((c: SelectorOption | SelectorOptionGroup) => this.onChildFocus(c));
        option.onBlurFuncs.push((c: SelectorOption | SelectorOptionGroup) => this.onChildBlur(c));

        return option;
    }

    insertOptionGroup(index: number, text: string): SelectorOptionGroup {
        const optionGroupElement = document.createElement("optgroup");
        optionGroupElement.label = text;

        const refChild = this.getChild(index);
        if (refChild) {
            this.element.insertBefore(optionGroupElement, refChild.element);
        } else {
            this.element.appendChild(optionGroupElement);
        }

        const optionGroup = new SelectorOptionGroup(this, <HTMLOptGroupElement>optionGroupElement);
        optionGroup.init();

        if (this.dropdown && optionGroup.menuElement) {
            if (refChild && refChild.menuElement) {
                this.dropdown.body.insertBefore(optionGroup.menuElement, refChild.menuElement);
                this.children.splice(index, 0, optionGroup);
            } else {
                this.dropdown.body.appendChild(optionGroup.menuElement);
                this.children.push(optionGroup);
            }
        }

        optionGroup.onHoverFuncs.push((c: SelectorOption | SelectorOptionGroup) => this.onChildFocus(c));
        optionGroup.onBlurFuncs.push((c: SelectorOption | SelectorOptionGroup) => this.onChildBlur(c));
        optionGroup.options.forEach(child => {
            child.onHoverFuncs.push(c => this.onChildFocus(c));
            child.onBlurFuncs.push(c => this.onChildBlur(c));
        });

        return optionGroup;
    }

    removeChild(index: number): void {
        const option = this.getChild(index);
        if (!option) {
            return;
        }

        this.children.splice(index, 1);
        option.remove();

        this.updateAsync();
    }

    async clearChildAsync(): Promise<void> {
        this.children.forEach(child => child.remove());
        this.children = [];
        await this.updateAsync();
    }
}
