import Selector from "Selector";
import SelectorOptions from "SelectorOptions";

export default class SelectorController {

    private _currentId: number = 0;

    private _selectors: { [id: string]: Selector } = {};

    checkIconSvg: string = "<svg aria-hidden=\"true\" focusable=\"false\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 512 512\">" +
        "<path d=\"M173.898 439.404l-166.4-166.4c-9.997-9.997-9.997-26.206 0-36.204l36.20" +
        "3-36.204c9.997-9.998 26.207-9.998 36.204 0L192 312.69 432.095 72.596c9.997-9.997 26.207-9.997 36.20" +
        "4 0l36.203 36.204c9.997 9.997 9.997 26.206 0 36.204l-294.4 294.401c-9.998 9.997-26.207 9.997-36.204" +
        "-.001z\"></path></svg>";

    searchIconSvg: string = "<svg aria-hidden=\"true\" focusable=\"false\"xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 512 512\">" +
        "<path d=\"M505 442.7L405.3 343c-4.5-4.5-10.6-7-17-7H372c27.6-35.3 44-79.7 44-128C416 93.1 322.9 0 208 " +
        "0S0 93.1 0 208s93.1 208 208 208c48.3 0 92.7-16.4 128-44v16.3c0 6.4 2.5 12.5 7 17l99.7 99.7c9.4 9.4 24.6 9.4 33.9 0l28.3-2" +
        "8.3c9.4-9.4 9.4-24.6.1-34zM208 336c-70.7 0-128-57.2-128-128 0-70.7 57.2-128 128-128 70.7 0 128 57.2 128 128 0 70.7-57.2 12" +
        "8-128 128z\"></path></svg>";

    private _getNewId(): number {
        return this._currentId++;
    }

    async scanAsync(): Promise<HTMLSelectElement[]> {
        const selectElements: HTMLSelectElement[] = [];
        const matchs = document.querySelectorAll("select.selector");
        for (let i = 0; i < matchs.length; i++) {
            selectElements.push(<HTMLSelectElement>(matchs.item(i)));
        }

        return selectElements;
    }

    async scanAndBuildAsync(): Promise<Selector[]> {
        const elements = await this.scanAsync();
        return this.buildAsync(elements);
    }

    get(id: number): Selector;
    get(element: HTMLElement): Selector;
    get(arg0: number | HTMLElement): Selector | undefined {
        if (typeof arg0 === "number") {
            return this._selectors[String(arg0)];
        } else {
            const ids = Object.keys(this._selectors);
            for (let i = 0; i < ids.length; i++) {
                if (this._selectors[ids[i]].element.isSameNode(arg0)) {
                    return this._selectors[ids[i]];
                }
            }
        }
    }

    list(): Selector[];
    list(id: number): Selector[];
    list(element: HTMLElement): Selector[];
    list(idOrElements: (number | HTMLElement)[]): Selector[];
    list(arg0?: number | HTMLElement | (number | HTMLElement)[]): Selector[] {
        if (!arg0) {
            return Object.keys(this._selectors).map(id => this._selectors[id]);
        } else if (typeof arg0 === "number") {
            return [this._selectors[String(arg0)]].filter(selector => !!selector);
        } else if (Array.isArray(arg0)) {
            return arg0
                .map(item => {
                    if (typeof item === "number") {
                        return this._selectors[String(item)];
                    } else {
                        return this.get(item);
                    }
                })
                .filter(selector => !!selector);
        } else {
            const selectors: Selector[] = [];
            const ids = Object.keys(this._selectors);
            for (let i = 0; i < ids.length; i++) {
                if (this._selectors[ids[i]].element.isSameNode(arg0)) {
                    selectors.push(this._selectors[ids[i]]);
                }
            }

            return selectors;
        }
    }

    buildAsync(options: SelectorOptions): Promise<Selector[]>;
    buildAsync(element: HTMLSelectElement): Promise<Selector[]>;
    buildAsync(elements: HTMLSelectElement[]): Promise<Selector[]>;
    async buildAsync(arg0: SelectorOptions | HTMLSelectElement | HTMLSelectElement[]): Promise<Selector[]> {
        if ("select" in arg0) {
            if (!arg0.select) {
                return [];
            }

            const exists = this.get(arg0.select);
            if (exists) {
                return [exists];
            }

            const id = this._getNewId();
            const selector = new Selector(arg0.select, id, arg0);
            selector.init();
            await selector.updateAsync();
            this._selectors[String(id)] = selector;

            if (selector.options && selector.options.onBuild) {
                selector.options.onBuild(selector);
            }

            return [selector];
        } else {
            const selectors: Selector[] = [];
            const elements = Array.isArray(arg0) ? arg0 : [arg0];
            for (let i = 0; i < elements.length; i++) {
                if (!elements[i]) {
                    continue;
                }

                const exists = this.get(elements[i]);
                if (exists) {
                    selectors.push(exists);
                    continue;
                }

                const id = this._getNewId();
                const selector = new Selector(elements[i], id);
                selector.init();
                await selector.updateAsync();
                this._selectors[String(id)] = selector;

                selectors.push(selector);

                if (selector.options && selector.options.onBuild) {
                    selector.options.onBuild(selector);
                }
            }

            return selectors;
        }
    }

    updateAsync(): Promise<void>;
    updateAsync(id: number): Promise<void>;
    updateAsync(element: HTMLSelectElement): Promise<void>;
    updateAsync(idOrElements: (number | HTMLElement)[]): Promise<void>;
    async updateAsync(arg0?: number | HTMLSelectElement | (number | HTMLElement)[]): Promise<void> {
        await Promise.all(this.list(<any>arg0).map(selector => selector.updateAsync()));
    }

    rebuildAsync(): Promise<void>;
    rebuildAsync(id: number): Promise<void>;
    rebuildAsync(element: HTMLSelectElement): Promise<void>;
    rebuildAsync(idOrElements: (number | HTMLElement)[]): Promise<void>;
    async rebuildAsync(arg0?: number | HTMLSelectElement | (number | HTMLElement)[]): Promise<void> {
        await Promise.all(this.list(<any>arg0).map(async selector => {
            const id = selector.id;
            const element = selector.element;
            await selector.removeAsync();
            
            const newSelector = new Selector(element, id);
            newSelector.init();
            await newSelector.updateAsync();
            this._selectors[String(id)] = newSelector;
        }));
    }

    removeAsync(): Promise<void>;
    removeAsync(id: number): Promise<void>;
    removeAsync(element: HTMLSelectElement): Promise<void>;
    removeAsync(idOrElements: (number | HTMLElement)[]): Promise<void>;
    async removeAsync(arg0?: number | HTMLSelectElement | (number | HTMLElement)[]): Promise<void> {
        await Promise.all(this.list(<any>arg0).map(async selector => {
            const id = selector.id;
            await selector.removeAsync();
            delete this._selectors[id];
        }));
    }
}

export const selectorController = new SelectorController();
(<any>window).selectorController = selectorController;
selectorController.scanAndBuildAsync();