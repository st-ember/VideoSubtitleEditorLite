export default interface SelectorOptionOptions {
    value: string;
    text: string;
    subText?: string;
    selected?: boolean;
    isAllOption?: boolean;
    isDefaultOption?: boolean;
    isExclusive?: boolean;
}
