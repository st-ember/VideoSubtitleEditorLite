import Selector from "Selector";
import { selectorController } from "SelectorController";
import SelectorOptionGroup from "SelectorOptionGroup";
import SelectorOptionItem from "SelectorOptionItem";

export default class SelectorOption {

    type: "OPTION" = "OPTION";
    value?: string;
    text: string = "";
    subText: string = "";
    selected: boolean = false;
    hidden: boolean = false;
    isAllOption: boolean = false;
    isDefaultOption: boolean = false;
    isExclusive: boolean = false;

    searchTexts: string[] = [];
    selector: Selector;
    element: HTMLOptionElement;
    parentElement: HTMLElement;
    isUnderGroup: boolean = false;
    menuElement?: HTMLSpanElement;

    onHoverFuncs: ((option: SelectorOption) => void)[] = [];
    onBlurFuncs: ((option: SelectorOption) => void)[] = [];

    constructor(selector: Selector, optionElement: HTMLOptionElement, options?: SelectorOptionItem) {
        this.selector = selector;
        this.element = optionElement;

        if (!optionElement.parentElement) {
            throw "parentElement = undefined";
        }

        this.parentElement = optionElement.parentElement;
        this.isUnderGroup = optionElement.parentElement.tagName === "OPTGROUP";

        if (options) {
            this._updateOptionsFromInput(options);
        } else {
            this._updateOptions();
        }

        if (this.subText) {
            this.searchTexts.push(this.subText.toLowerCase());
        }
    }

    init(): void {
        this._initMenuItem();
        this._initEvents();
        if (this.isAllOption) {
            this.selector.setAllOption(this);
        }
    }

    private _updateOptionsFromInput(options: SelectorOptionItem): void {
        this.value = options.value;
        this.text = options.text ?? "";
        this.searchTexts.push(this.text.toLowerCase());

        if (options.subText) {
            this.subText = options.subText;
        }
        
        if (options.selected) {
            this.selected = options.selected;
        }
        
        if (options.isAllOption) {
            this.isAllOption = options.isAllOption;
        }
        
        if (options.isDefaultOption) {
            this.isDefaultOption = options.isDefaultOption;
        }

        if (options.isExclusive) {
            this.isExclusive = options.isExclusive;
        }
    }

    private _updateOptions(): void {
        this.value = this.element.value;
        this.text = this.element.innerText.trim();
        this.subText = this.element.hasAttribute("data-subtext") ? this.element.getAttribute("data-subtext") ?? "" : "";
        this.selected = this.element.selected;
        this.isAllOption = this.element.hasAttribute("data-all") && this.element.getAttribute("data-all") === "true";
        this.isDefaultOption = this.element.hasAttribute("data-default") && this.element.getAttribute("data-default") === "true";
        this.isExclusive = this.element.hasAttribute("data-exclusive") && this.element.getAttribute("data-exclusive") === "true";

        if (this.element.innerText) {
            this.searchTexts.push(this.element.innerText.toLowerCase());
        }
    }

    update(): void {
        this._updateValue();
        this._updateElement();
    }

    modifyText(html: string): void {
        if (this.text === html) { return; }
        this.element.innerHTML = html;
        this.text = html;

        if (this.menuElement) {
            this.menuElement.innerHTML = "<span class=\"selector-text\">" + this.text + "</span>" +
                (this.subText ? "<span class=\"selector-subtext\">" + this.subText + "</span>" : "") + selectorController.checkIconSvg;
        }

        if (this.selected) {
            this.selector.updateAsync();
        }
    }

    modifySubText(html: string): void {
        if (this.subText === html) { return; }
        this.element.setAttribute("data-subtext", html);
        this.subText = html;

        if (this.menuElement) {
            this.menuElement.innerHTML = "<span class=\"selector-text\">" + this.text + "</span>" +
                (this.subText ? "<span class=\"selector-subtext\">" + this.subText + "</span>" : "") + selectorController.checkIconSvg;
        }

        if (this.selected) {
            this.selector.updateAsync();
        }
    }

    remove(): void {
        this.element.remove();
        this.menuElement?.remove();
    }

    private _initMenuItem(): void {
        const menuElement = document.createElement("span");
        menuElement.className = "selector-option";
        menuElement.innerHTML = "<span class=\"selector-text\">" + this.text + "</span>" +
            (this.subText ? "<span class=\"selector-subtext\">" + this.subText + "</span>" : "") + selectorController.checkIconSvg;
        this.menuElement = menuElement;
    }

    private _initEvents(): void {
        this.menuElement?.addEventListener("click", () => this.clickAsync());
        this.menuElement?.addEventListener("mouseenter", () => this.onHover());
        this.menuElement?.addEventListener("mouseleave", () => this.onBlur());
    }

    private _updateValue(): void {
        this.selected = this.element.selected;
    }

    private _updateElement(): void {
        if (this.selected) {
            this.menuElement?.classList.add("selector-selected");
        } else {
            this.menuElement?.classList.remove("selector-selected");
        }

        if (this.element.disabled) {
            this.menuElement?.classList.add("selector-disabled");
        } else {
            this.menuElement?.classList.remove("selector-disabled");
        }
    }

    async clickAsync(update?: boolean): Promise<void> {
        if (this.selector.multiple) {
            if (!this.selected) {
                if (this.isAllOption) {
                    this.selector.setAll(true);
                } else if (this.isExclusive) {
                    this.selector.setAll(false);
                    this.set(true);
                } else {
                    if (this.selector.allOption && this.selector.allOption.isExclusive) {
                        this.selector.allOption.set(false);
                    }
                    this.selector.unselectExclusiveOptions();
                    this.set(true);
                }
            } else {
                if (!this.isAllOption) {
                    if (this.selector.allOption && !this.selector.allOption.isExclusive) {
                        this.selector.allOption.set(false);
                    }
                    this.set(false);
                }
            }
        } else {
            this.selector.setAll(false);
            this.set(true);
        }
        
        if (update !== false) {
            await this.selector.changeAsync();
            if (!this.selector.multiple) {
                await this.selector.triggerAsync();
            }
        }
    }

    onHover(): void {
        this.onHoverFuncs.forEach(func => func(this));
    }

    onBlur(): void {
        this.onBlurFuncs.forEach(func => func(this));
    }

    focus(): void {
        this.menuElement?.classList.add("focus");
    }

    blur(): void {
        this.menuElement?.classList.remove("focus");
    }

    set(selected: boolean): void {
        if (this.hidden) {
            if (this.selected) {
                this.selector.selectedCount--;
                this.element.selected = false;
            }
        } else {
            if (this.selected !== selected) {
                if (selected && this.isAllOption) {
                    this.selector.selectedCount++;
                    this.element.selected = true;
                } else if (selected) {
                    if (this.selector.isAllowSelect()) {
                        this.selector.selectedCount++;
                        this.element.selected = true;
                    } else {
                        this.selector.showWarning(true);
                    }
                } else {
                    this.selector.selectedCount--;
                    this.element.selected = false;
                }
            }
        }
    }

    show(value?: boolean): void {
        if (value !== false) {
            this.menuElement?.classList.remove("selector-hidden");
            this.hidden = false;
        } else {
            this.menuElement?.classList.add("selector-hidden");
            this.hidden = true;
        }
    }

    isMatch(text: string): boolean {
        return this.searchTexts.filter(value => value.indexOf(text) >= 0).length > 0;
    }

    isMatchValues(texts: string[]): boolean {
        const value = this.value !== undefined ? this.value : this.text;
        return texts.filter(text => text === value).length > 0;
    }

    isSelectable(): boolean {
        if (this.isUnderGroup) {
            const group = this._getOptionGroup()!;
            return !this.hidden && !this.element.disabled && !group.element.disabled && !group.hidden;
        } else {
            return !this.hidden && !this.element.disabled;
        }
    }

    isSameNode(target: SelectorOption | SelectorOptionGroup): boolean {
        return this.element.isSameNode(target.element);
    }

    private _getOptionGroup(): SelectorOptionGroup | undefined {
        if (this.isUnderGroup) {
            for (let i = 0; i < this.selector.children.length; i++) {
                if (this.selector.children[i].element.isSameNode(this.parentElement)) {
                    return <SelectorOptionGroup>this.selector.children[i];
                }
            }
        }
    }
}
