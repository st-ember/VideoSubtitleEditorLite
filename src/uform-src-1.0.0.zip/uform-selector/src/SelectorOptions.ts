import Selector from "Selector";
import SelectorOptionItem from "SelectorOptionItem";

export default interface SelectorOptions {
    select: HTMLSelectElement;
    multiple?: boolean;
    /** 是否在按鈕上顯示所有已選項目的文字。如果為 False，選擇多於一個項目時會改為顯示「已選擇 X 個項目」。 */
    showAllItemText?: boolean;
    max?: number;
    /** 是否強制啟用或關閉搜尋功能。預設只有在項目超過十個時才會自動啟用。 */
    search?: boolean;
    /** 按鈕的最大寬度 */
    maxWidth?: number;
    /** 只有在關閉下拉選單時才觸發 Change 事件。 */
    changeWhenClose?: boolean;
    /** 未選擇任何項目時的預設文字。 */
    emptyText?: string;
    /** 在單選的狀態下是否允許無值的狀態。 */
    allowEmpty?: boolean;

    items?: SelectorOptionItem[];

    onBuild?: (selector: Selector) => void;
    onOpen?: (selector: Selector) => void;
    onClose?: (selector: Selector) => void;
    onChange?: (selector: Selector) => void;
}