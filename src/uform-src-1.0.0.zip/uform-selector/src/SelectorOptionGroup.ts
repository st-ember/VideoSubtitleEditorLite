import Selector from "Selector";
import { selectorController } from "SelectorController";
import SelectorOption from "SelectorOption";
import SelectorOptionItem from "SelectorOptionItem";

export default class SelectorOptionGroup {

    type: "OPTGROUP" = "OPTGROUP";
    text: string = "";
    searchTexts: string[] = [];
    hidden: boolean = false;
    /** 選擇狀態，0: 未選擇，1: 部分選擇，2: 全部選擇 */
    selectStatus: 0 | 1 | 2 = 0;
    selectedCount: number = 0;

    selector: Selector;
    element: HTMLOptGroupElement;

    options: SelectorOption[] = [];
    menuElement?: HTMLDivElement;
    trigger?: HTMLSpanElement;

    onHoverFuncs: ((optionGroup: SelectorOptionGroup) => void)[] = [];
    onBlurFuncs: ((optionGroup: SelectorOptionGroup) => void)[] = [];

    protected _selectorOptionGroupOptions?: SelectorOptionItem;
    
    constructor(selector: Selector, optionGroupElement: HTMLOptGroupElement, options?: SelectorOptionItem) {
        this.selector = selector;
        this.element = optionGroupElement;

        if (options) {
            this._selectorOptionGroupOptions = options;
            this._updateOptionsFromInput(options);
        } else {
            this._updateOptions();
        }
    }

    init(): void {
        this._initChildren();
        this._initMenuItem();
        this._initEvents();
    }

    private _updateOptionsFromInput(options: SelectorOptionItem): void {
        this.text = options.text ?? "";
        this.searchTexts.push(this.text.toLowerCase());
    }

    private _updateOptions(): void {
        this.text = this.element.label.trim();
        this.searchTexts = [this.element.label.toLowerCase()];
    }

    update(): void {
        this._updateChildren();
        this._updateValue();
        this._updateElement();
    }

    remove(): void {
        this.element.remove();
        this.menuElement?.remove();
    }

    private _initChildren(): void {
        const children = this.element.children;
        if (children.length === 0 && this._selectorOptionGroupOptions && this._selectorOptionGroupOptions.children) {
            for (let i = 0; i < this._selectorOptionGroupOptions.children.length; i++) {
                const optionOptions = this._selectorOptionGroupOptions.children[i];
                if (optionOptions.type === "OPTGROUP") {
                    continue;
                }
                
                const optionElement = document.createElement("option");
                this.element.appendChild(optionElement);

                const option = new SelectorOption(this.selector, optionElement, optionOptions);
                option.init();
                this.options.push(option);
            }
        } else {
            for (let i = 0; i < children.length; i++) {
                const optionElement = <HTMLOptionElement>children.item(i);
                const option = new SelectorOption(this.selector, optionElement);
                option.init();
                this.options.push(option);
            }
        }
    }

    private _initMenuItem(): void {
        const menuElement = document.createElement("div");
        menuElement.className = "selector-group";

        const trigger = document.createElement("span");
        trigger.className = "selector-group-head";
        trigger.innerHTML = "<span class=\"selector-text\">" + this.text + "</span>" + selectorController.checkIconSvg;

        menuElement.appendChild(trigger);

        this.options
            .filter(option => !!option.menuElement)
            .forEach(option => menuElement.appendChild(option.menuElement!));

        this.menuElement = menuElement;
        this.trigger = trigger;
    }

    private _initEvents(): void {
        this.trigger?.addEventListener("click", () => this.clickAsync());
        this.trigger?.addEventListener("mouseenter", () => this.onHover());
        this.trigger?.addEventListener("mouseleave", () => this.onBlur());
    }

    private _updateValue(): void {
        let totalSelectedCount = 0;
        this.options.forEach(option => {
            if (option.selected) {
                totalSelectedCount++;
            }
        });

        this.selectStatus = totalSelectedCount > 0 && totalSelectedCount < this.options.length ?
            1 : totalSelectedCount === this.options.length ? 2 : 0;
        this.selectedCount = totalSelectedCount;
    }

    private _updateChildren(): void {
        this.options.forEach(option => option.update());
    }

    private _updateElement(): void {
        if (this.selectStatus === 1) {
            this.menuElement?.classList.add("selector-part-selected");
            this.menuElement?.classList.remove("selector-selected");
        } else if (this.selectStatus === 2) {
            this.menuElement?.classList.remove("selector-part-selected");
            this.menuElement?.classList.add("selector-selected");
        } else {
            this.menuElement?.classList.remove("selector-part-selected");
            this.menuElement?.classList.remove("selector-selected");
        }

        if (this.element.disabled) {
            this.menuElement?.classList.add("selector-disabled");
        } else {
            this.menuElement?.classList.remove("selector-disabled");
        }
    }

    async clickAsync(): Promise<void> {
        const notExclusivedOptions = this.options.filter(o => !o.isExclusive);
        if (this.selectStatus === 1) {
            notExclusivedOptions.forEach(option => option.set(true));
        } else {
            for (let i = 0; i < notExclusivedOptions.length; i++) {
                await notExclusivedOptions[i].clickAsync(false);
            }
        }

        // if (this.selectStatus !== 2) {
        //     this.selector.setAll(false);
        // }

        await this.selector.changeAsync();
    }

    onHover(): void {
        this.onHoverFuncs.forEach(func => func(this));
    }

    onBlur(): void {
        this.onBlurFuncs.forEach(func => func(this));
    }

    focus(): void {
        this.trigger?.classList.add("focus");
    }

    blur(): void {
        this.trigger?.classList.remove("focus");
    }

    set(selected: boolean): void {
        if (this.element.disabled) {
            this.options.forEach(option => option.set(false));
        } else {
            this.options.forEach(option => {
                if (!option.hidden && !option.isExclusive) {
                    option.set(selected);
                } else {
                    option.set(false);
                }
            });
        }
    }

    unselectExclusiveOptions(): void {
        this.options.forEach(option => {
            if (option.isExclusive) {
                option.set(false);
            }
        });
    }

    listSelectedOption(): SelectorOption[] {
        return this.options.filter(option => option.selected);
    }

    isMatch(text: string): boolean {
        return this.searchTexts[0].indexOf(text) >= 0;
    }

    isSelectable(): boolean {
        return !this.hidden && !this.element.disabled;
    }

    isSameNode(target: SelectorOption | SelectorOptionGroup): boolean {
        return this.element.isSameNode(target.element);
    }

    search(text: string): SelectorOption[] {
        return this.options.filter(option => option.isMatch(text));
    }
    
    searchValues(texts: string[]): SelectorOption[] {
        return this.options.filter(option => option.isMatchValues(texts));
    }

    show(value?: boolean): void {
        if (value !== false) {
            this.menuElement?.classList.remove("selector-hidden");
            this.hidden = false;
        } else {
            this.menuElement?.classList.add("selector-hidden");
            this.hidden = true;
        }
    }

    getOption(value: string): SelectorOption;
    getOption(index: number): SelectorOption;
    getOption(value: string | number): SelectorOption | undefined {
        if (typeof value === "string") {
            const matchs = this.options.filter(o => o.value === value);
            return matchs.length > 0 ? matchs[0] : undefined;
        } else {
            return this.options.length <= value || value < 0 ? undefined : this.options[value];
        }
    }

    getOptionIndex(value: string): number {
        return this.options.findIndex(o => o.value === value);
    }

    insertOption(index: number, value: string, html: string, subtext?: string, exclusive?: boolean): SelectorOption {
        const optionElement = document.createElement("option");
        optionElement.value = value;
        optionElement.innerHTML = html;

        if (subtext) {
            optionElement.setAttribute("data-subtext", subtext);
        }

        if (exclusive === true) {
            optionElement.setAttribute("data-exclusive", "true");
        }

        const refOption = this.getOption(index);
        if (refOption) {
            this.element.insertBefore(optionElement, refOption.element);
        } else {
            this.element.appendChild(optionElement);
        }

        const option = new SelectorOption(this.selector, optionElement);
        option.init();

        if (this.menuElement && option.menuElement) {
            if (refOption && refOption.menuElement) {
                this.menuElement.insertBefore(option.menuElement, refOption.menuElement);
                this.options.splice(index, 0, option);
            } else {
                this.menuElement.appendChild(option.menuElement);
                this.options.push(option);
            }
        }

        option.onHoverFuncs.push(c => this.selector.onChildFocus(c));
        option.onBlurFuncs.push(c => this.selector.onChildBlur(c));

        return option;
    }

    removeChild(value: string): void;
    removeChild(index: number): void;
    removeChild(value: string | number): void {
        const index = typeof value === "string" ? this.getOptionIndex(value) : value;
        const option = this.getOption(index);
        if (!option) {
            return;
        }

        this.options.splice(index, 1);
        option.remove();

        this.selector.updateAsync();
    }
}
