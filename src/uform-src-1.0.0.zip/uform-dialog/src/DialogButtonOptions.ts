
export default interface DialogButtonOptions {
    text: string;
    icon?: string;
    type?: "default" | "action" | "primary" | "success" | "warning" | "danger" | string;
    className?: string;
    align?: "left" | "center" | "right";
    keybindings?: string | string[];
    callback?: () => void;
}