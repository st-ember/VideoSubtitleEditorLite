import Dialog from "Dialog";
import DialogButtonOptions from "DialogButtonOptions";
import DialogOptions from "DialogOptions";

export default class DialogController {

    zIndexBase: number = 440;
    modalIndex: number = 0;
    dialogs: Dialog[] = [];

    quickDialogWidth: string | number = 400;

    get anyDialogShowing(): boolean { return this.dialogs.filter(o => o.showing).length > 0; }

    get(name: string): Dialog | undefined {
        const matchs = this.dialogs.filter(dialog => dialog.name === name);
        return matchs.length > 0 ? matchs[0] : undefined;
    }

    async showAsync(name: string, option?: DialogOptions): Promise<Dialog | undefined> {
        if (!name) {
            console.log("invalid name");
            return;
        }
    
        const existedDialog = this.get(name);
        if (existedDialog) {
            await existedDialog.showAsync();
            return existedDialog;
        };

        const dialog = new Dialog(name, option);
        await dialog.buildAsync();
        this.dialogs.push(dialog);

        this.update();

        await dialog.showAsync();

        return dialog;
    }

    update(): void {
        this.dialogs.filter(dialog => dialog.closed && dialog.options.closeAction === "delete")
            .forEach(dialog => {
                dialog.deleted = true;
                dialog.container.remove();
            });

        this.dialogs = this.dialogs.filter(dialog => !dialog.deleted);
        this.dialogs.forEach((o, index) => o.container.style.zIndex = String(index + this.zIndexBase));
    }

    async closeAsync(input: string | Dialog | undefined): Promise<void> {
        if (input === undefined) {
            return new Promise(resolve => resolve());
        }

        const name = input instanceof Dialog ? input.name : input;
        const dialog = this.get(name);

        if (!dialog) {
            console.log("invalid name: " + name);
            return;
        };

        await dialog.closeAsync();
    }

    async clearAsync(): Promise<void> {
        await Promise.all(this.dialogs.map(dialog => this.closeAsync(dialog)));
    }

    async showLoadingAsync(title: string, html: string): Promise<Dialog> {
        const body = document.createElement("div");
        body.style.whiteSpace = "break-spaces";
        body.style.overflowWrap = "break-word";
        body.innerHTML = `<i class=\"fa fa-gear fa-spin\"></i>&nbsp;${html ? html : ""}`;
        
        return (await this.showAsync(`info${this.modalIndex++}`, { type: "info", title, body, headerCloseButton: false, buttons: [] }))!;
    };

    async showInfoAsync(title: string, html: string, autoCloseTime?: number): Promise<Dialog> {
        const dialog = await this.showAsync(`info${this.modalIndex++}`, this._buildOptions("info", title, html, [{ text: "關閉", keybindings: ["Enter", "Escape"] }]));

        if (autoCloseTime && autoCloseTime > 0) {
            setTimeout(() => dialog!.closeAsync(), autoCloseTime);
        }

        return dialog!;
    };

    async showSuccessAsync(title: string, html: string, autoCloseTime?: number): Promise<Dialog> {
        const dialog = await this.showAsync(`success${this.modalIndex++}`, this._buildOptions("success", title, html, [{ text: "關閉", keybindings: ["Enter", "Escape"] }]));

        if (autoCloseTime && autoCloseTime > 0) {
            setTimeout(() => dialog!.closeAsync(), autoCloseTime);
        }

        return dialog!;
    };
    
    async showWarningAsync(title: string, html: string, autoCloseTime?: number): Promise<Dialog> {
        const dialog = await this.showAsync(`warning${this.modalIndex++}`, this._buildOptions("warning", title, html, [{ text: "關閉", keybindings: ["Enter", "Escape"] }]));

        if (autoCloseTime && autoCloseTime > 0) {
            setTimeout(() => dialog!.closeAsync(), autoCloseTime);
        }

        return dialog!;
    };
    
    async showErrorAsync(title: string, html: string, autoCloseTime?: number): Promise<Dialog> {
        const dialog = await this.showAsync(`error${this.modalIndex++}`, this._buildOptions("error", title, html, [{ text: "關閉", keybindings: ["Enter", "Escape"] }]));

        if (autoCloseTime && autoCloseTime > 0) {
            setTimeout(() => dialog!.closeAsync(), autoCloseTime);
        }

        return dialog!;
    };
    
    confirmInfoAsync(title: string, html: string): Promise<boolean> {
        const name = "info" + this.modalIndex++;
        return new Promise(resolve =>
            this.showAsync(name, 
                this._buildOptions("info", title, html, [
                    { 
                        text: "確認", 
                        type: "primary", 
                        keybindings: ["Enter"],
                        callback: () => { 
                            dialogController.closeAsync(name);
                            resolve(true);
                        } 
                    },
                    { 
                        text: "取消", 
                        keybindings: ["Escape"],
                        callback: () => { 
                            dialogController.closeAsync(name);
                            resolve(false);
                        } 
                    }
                ])
            )
        );
    };

    confirmSuccessAsync(title: string, html: string): Promise<boolean> {
        const name = `success${this.modalIndex++}`;
        return new Promise(resolve =>
            this.showAsync(name, 
                this._buildOptions("success", title, html, [
                    { 
                        text: "確認", 
                        type: "success", 
                        keybindings: ["Enter"],
                        callback: () => { 
                            dialogController.closeAsync(name);
                            resolve(true);
                        } 
                    },
                    { 
                        text: "取消", 
                        keybindings: ["Escape"],
                        callback: () => { 
                            dialogController.closeAsync(name);
                            resolve(false);
                        } 
                    }
                ])
            )
        );
    };
    
    confirmWarningAsync(title: string, html: string): Promise<boolean> {
        const name = `warning${this.modalIndex++}`;
        return new Promise(resolve => 
            this.showAsync(name, 
                this._buildOptions("warning", title, html, [
                    { 
                        text: "確認", 
                        type: "warning", 
                        keybindings: ["Enter"],
                        callback: () => { 
                            dialogController.closeAsync(name);
                            resolve(true);
                        } 
                    },
                    { 
                        text: "取消", 
                        keybindings: ["Escape"],
                        callback: () => { 
                            dialogController.closeAsync(name);
                            resolve(false);
                        } 
                    }
                ])
            )
        );
    };
    
    confirmErrorAsync(title: string, html: string): Promise<boolean> {
        const name = `error${this.modalIndex++}`;
        return new Promise(resolve => 
            this.showAsync(name, 
                this._buildOptions("error", title, html, [
                    { 
                        text: "確認", 
                        type: "danger", 
                        keybindings: ["Enter"],
                        callback: () => { 
                            dialogController.closeAsync(name);
                            resolve(true);
                        } 
                    },
                    { 
                        text: "取消", 
                        keybindings: ["Escape"],
                        callback: () => { 
                            dialogController.closeAsync(name);
                            resolve(false);
                        } 
                    }
                ])
            )
        );
    };

    private _buildBody(html: string): HTMLDivElement {
        const body = document.createElement("div");
        body.style.whiteSpace = "break-spaces";
        body.style.overflowWrap = "break-word";
        body.innerHTML = html;
        return body;
    }

    private _buildOptions(type: "info" | "success" | "warning" | "error", title: string, html: string, buttons: DialogButtonOptions[]): DialogOptions {
        return {
            type,
            closeAction: "delete",
            width: this.quickDialogWidth,
            title,
            body: this._buildBody(html),
            headerCloseButton: false,
            backdropClose: false,
            keyboardClose: false,
            buttons
        };
    }
}

export const dialogController = new DialogController();