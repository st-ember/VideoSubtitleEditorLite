import DialogButtonOptions from "DialogButtonOptions";
import DialogOptions from "DialogOptions";
import Dialog from "Dialog";
import DialogController, { dialogController } from "DialogController";

export default dialogController;
export {
    dialogController,
    DialogButtonOptions,
    DialogOptions,
    Dialog,
    DialogController
}