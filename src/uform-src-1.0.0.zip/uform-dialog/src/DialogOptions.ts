import DialogButtonOptions from "DialogButtonOptions";

export default interface DialogOptions {
    width?: string | number;
    closeAction?: "hide" | "delete";
    headerCloseButton?: boolean;
    title?: string;
    type?: "info" | "success" | "warning" | "error";
    icon?: string;
    className?: string;
    bodyPadding?: boolean;
    body?: HTMLElement;
    buttons?: DialogButtonOptions[];
    onBuildAsync?: (() => Promise<void>) | (() => Promise<any>);
    onShowAsync?: (() => Promise<void>) | (() => Promise<any>);
    onCloseAsync?: (() => Promise<void>) | (() => Promise<any>);
    keyboardClose?: boolean;
    backdropClose?: boolean;
}