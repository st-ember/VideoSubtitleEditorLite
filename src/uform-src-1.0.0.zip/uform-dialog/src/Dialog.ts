import { dialogController } from "DialogController";
import DialogOptions from "DialogOptions";
import Utility from "uform-utility";

export default class Dialog {
    
    name: string;
    container: HTMLDivElement = document.createElement("div");
    options: DialogOptions;

    private _defaultOptions: DialogOptions = {
        width: dialogController.quickDialogWidth,
        bodyPadding: true,
        closeAction: "delete",
        headerCloseButton: false,
        backdropClose: false,
        keyboardClose: false,
        title: "",
        buttons: [{ text: "關閉", type: "default", callback: () => dialogController.closeAsync(this.name), keybindings: "Escape" }]
    };

    element: HTMLDivElement = document.createElement("div");
    backdrop: HTMLDivElement = document.createElement("div");
    modal: HTMLDivElement = document.createElement("div");
    header: HTMLDivElement = document.createElement("div");
    body: HTMLElement = document.createElement("div");
    footer: HTMLDivElement = document.createElement("div");
    footerLeftGroup: HTMLDivElement = document.createElement("div");
    footerCenterGroup: HTMLDivElement = document.createElement("div");
    footerRightGroup: HTMLDivElement = document.createElement("div");
    headerCloseBtn?: HTMLButtonElement;
    headerTitle: HTMLDivElement = document.createElement("div");
    headerIcon: HTMLElement = document.createElement("i");
    buttons: HTMLButtonElement[] = [];

    get builded(): boolean { return this._status === "builded" || this._status === "showing" || this._status === "closed"; }
    get showing(): boolean { return this._status === "showing"; }
    get closed(): boolean { return this._status === "closed"; }
    get deleted(): boolean { return this._status === "deleted"; }
    set deleted(value: boolean) { if (value) { this._status = "deleted"; } }

    private _footerButtons: number = 0;
    private _status: "building" | "builded" | "showing" | "closed" | "deleted" = "building";
    private _buttonKeybindings: { callback: () => void, keybindings?: string | string[] }[] = [];

    onBuildAsync?: () => Promise<void>;
    onShowAsync?: () => Promise<void>;
    onCloseAsync?: () => Promise<void>;

    constructor(name: string, option?: DialogOptions) {
        this.name = name;
        this.options = option ?? <any>{};
    }

    async buildAsync(): Promise<void> {
        this._initOptions();
        this._buildContainer();
        this._buildDialog();
        this._buildHeader();
        this._buildBody();
        this._buildFooter();
        this._combinate();

        if (this.onBuildAsync) {
            await this.onBuildAsync();
        }

        this._status = "builded";
    }

    private _initOptions(): void {
        const defaultOptions = { ...this._defaultOptions };
        if (!this.options || Object.keys(this.options).length === 0) {
            this.options = defaultOptions;
        } else {
            Object.keys(defaultOptions).forEach(key => {
                if ((<any>this.options)[key] === undefined) {
                    (<any>this.options)[key] = (<any>defaultOptions)[key];
                }
            });
        }

        if (this.options.onBuildAsync) {
            this.onBuildAsync = this.options.onBuildAsync;
        }

        if (this.options.onShowAsync) {
            this.onShowAsync = this.options.onShowAsync;
        }

        if (this.options.onCloseAsync) {
            this.onCloseAsync = this.options.onCloseAsync;
        }
    }

    private _buildContainer(): void {
        this.container.className = "modal-container";
        document.body.appendChild(this.container);
    }

    private _buildDialog(): void {
        this.element.className = "modal-element";
        this.container.appendChild(this.element);

        if (this.options.backdropClose) {
            this.backdrop.className = "modal-backdrop";
            this.container.appendChild(this.backdrop);

            this.backdrop.addEventListener("click", () => dialogController.closeAsync(this));
        }

        this.modal.className = "modal";
        this.modal.setAttribute("name", this.name);
        this.modal.classList.add("modal-" + this.options.type);
        this.element.appendChild(this.modal);

        if (this.options.className) {
            this.modal.className = `${this.modal.className} ${this.options.className}`;
        }

        this._updateWidth();
    }

    private _buildHeader(): void {
        this.header.classList.add("modal-header");

        this._buildHeaderCloseBtn();
        this._buildHeaderTitle();

        if (this.options.icon) {
            this.headerIcon.classList.add(this.options.icon);
        }
    }

    private _buildHeaderCloseBtn(): void {
        if (this.options.headerCloseButton) {
            const button = document.createElement("button");
            button.setAttribute("type", "button");
            button.className = "header-close-button";
            button.innerHTML = "<span>&times;</span>";
            this.headerCloseBtn = button;
            this.header.appendChild(button);

            button.addEventListener("click", () => dialogController.closeAsync(this));
        }
    }

    private _buildHeaderTitle(): void {
        this.headerTitle.className = "modal-header-title";

        this.headerIcon.className = "modal-header-icon";
        this.headerTitle.appendChild(this.headerIcon);

        const titleText = document.createElement("h2");
        titleText.className = "modal-header-title-text";
        this.headerTitle.appendChild(titleText);

        if (this.options.title) {
            titleText.innerHTML = this.options.title;
        }

        this.header.appendChild(this.headerTitle);
    }

    private _buildBody(): void {
        this.body.className = "modal-body";
        
        if (this.options.bodyPadding === false) {
            this.body.classList.add("without-padding");
        }

        if (this.options.body) {
            this.body.appendChild(this.options.body);
        } else {
            this.body.style.display = "none";
        }
    }

    private _buildFooter(): void {
        this.footer.className = "modal-footer";

        if (this.options.buttons) {
            if (this.options.buttons.filter(o => o.align === "left").length > 0) {
                this.footerLeftGroup.className = "footer-left-group";
                this.footer.appendChild(this.footerLeftGroup);
            }

            if (this.options.buttons.filter(o => o.align === "left").length > 0) {
                this.footerCenterGroup.className = "footer-center-group";
                this.footer.appendChild(this.footerCenterGroup);
            }

            if (this.options.buttons.filter(o => o.align === "right" || !o.align).length > 0) {
                this.footerRightGroup.className = "footer-right-group";
                this.footer.appendChild(this.footerRightGroup);
            }

            this.options.buttons.forEach(item => this._addButtonToFooter(item.text, item.callback, item.type, item.icon, item.align, item.keybindings));
        }
    }

    private _addButtonToFooter(text: string, callback?: () => void, type?: string, icon?: string, align?: "left" | "center" | "right", keybindings?: string | string[]): void {
        const button = document.createElement("button");
        button.setAttribute("type", "button");
        button.innerHTML = !icon ? text : `<i class=\"${icon}\"></i>${text}`;
        button.classList.add(type ?? "default");

        this._buttonKeybindings.push({ 
            callback: callback ? callback : () => dialogController.closeAsync(this),
            keybindings
        });

        button.addEventListener("click", () => {
            if (callback) {
                callback();
            } else {
                dialogController.closeAsync(this);
            }
        });

        this.buttons.push(button);
        
        if (align === "left") {
            this.footerLeftGroup.appendChild(button);
        } else if (align === "center") {
            this.footerCenterGroup.appendChild(button);
        } else {
            this.footerRightGroup.appendChild(button);
        }

        this._footerButtons++;
    }

    private _combinate(): void {
        this.modal.appendChild(this.header);
        this.modal.appendChild(this.body);

        if (this._footerButtons > 0) {
            this.modal.appendChild(this.footer);
        }
    }

    private _initEvents(): void {
        this._onKeyUpAsync = this._onKeyUpAsync.bind(this);
        window.addEventListener("keyup", this._onKeyUpAsync);

        this._onResizeAsync = this._onResizeAsync.bind(this);
        window.addEventListener("resize", this._onResizeAsync);
    }

    private _removeEvents(): void {
        window.removeEventListener("keyup", this._onKeyUpAsync);
        window.removeEventListener("resize", this._onResizeAsync);
    }

    private _updateWidth(): void {
        if (typeof this.options.width === "string") {
            this.element.style.width = this.options.width;
        } else {
            const width = Number(this.options.width);
            if (!isNaN(width)) {
                this.element.style.width = `${width}px`;
            }
        }

        if (this.element.clientWidth > window.innerWidth - 40) {
            this.element.style.width = "calc(100% - 40px)";
        }
    }

    private async _onResizeAsync(): Promise<void> {
        this._updateWidth();
    }

    private async _onKeyUpAsync(event: KeyboardEvent): Promise<void> {
        const matchedKeybindings = this._buttonKeybindings.filter(o => 
            o.keybindings !== undefined && o.keybindings !== null && 
            (typeof o.keybindings === "string" && o.keybindings === event.key || o.keybindings instanceof Array && o.keybindings.indexOf(event.key) >= 0) 
            );
            
        if (matchedKeybindings.length > 0) {
            matchedKeybindings.forEach(o => o.callback());
        } else if (event.key === "Escape" && this.options.keyboardClose) {
            await dialogController.closeAsync(this.name);
        }
    }

    async showAsync(): Promise<void> {
        this.container.classList.add("existed");
        await Utility.wait(0);
        this.container.classList.add("show");
        
        if (this.onShowAsync) {
            await this.onShowAsync();
        }

        this._initEvents();
        this._status = "showing";

        await Utility.wait(200);
    }

    async closeAsync(): Promise<void> {
        this.container.classList.remove("show");
        this._removeEvents();
        
        await Utility.wait(200);

        if (this.onCloseAsync) {
            await this.onCloseAsync();
        }

        this._status = "closed";
        this.container.classList.remove("existed");
        dialogController.update();
    }
}