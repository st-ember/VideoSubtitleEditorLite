﻿import DatepickerCalendar from "DatepickerCalendar";
import { datepickerController } from "DatepickerController";
import DatepickerOptions from "DatepickerOptions";
import DatepickerRangeStatus from "DatepickerRangeStatus";
import DatepickerYearMonthSelector from "DatepickerYearMonthSelector";
import dropdownController, { Dropdown, DropdownController } from "uform-dropdown";

export default class Datepicker {

    private _initialized: boolean = false;

    id: number;
    element: HTMLInputElement;
    yearMonthSelector?: DatepickerYearMonthSelector;
    calendar?: DatepickerCalendar;
    buttonContainer?: HTMLDivElement;
    todayButton?: HTMLButtonElement;
    clearButton?: HTMLButtonElement;

    dropdown?: Dropdown;

    rangeMode: "none" | "start" | "end" = "none";
    rangeOppsInput?: Datepicker;

    option: DatepickerOptions = <DatepickerOptions><any>{
        input: undefined,
        format: "yyyy/MM/dd",
        firstDayOfWeek: 0,
        mode: "date",
        showTodayButton: true,
        todayText: "\u4eca\u5929",
        allowEmpty: false,
        showClearButton: false
    };

    onChangeFuncs: (() => Promise<void>)[] = [];

    isEmpty: boolean = true;
    year?: number;
    month?: number;
    date?: number;
    dayOfWeek?: number;
    
    defaultFormat: string = "yyyy/MM/dd";

    constructor(input: HTMLInputElement, id: number, option?: DatepickerOptions) {
        this.id = id;
        this.element = input;

        const attrValue = this.element.value;
        if (attrValue) {
            this.option.value = new Date(attrValue);
        }

        this.updateOptionAsync(option);
    }

    async initAsync(): Promise<void> {
        if (this._initialized) { return; }

        this._initValue();
        this._initTextInput();
        this._initDropdown();
        this._initYearMonthSelector();
        this._initCalendar();
        this._initButtons();

        await this.updateAsync();
    }

    private _initValue(): void {
        this.isEmpty = this.option.allowEmpty === true && (!this.option || !this.option.value);

        if (!this.isEmpty) {
            let value: Date = this.option && this.option.value ? this.option.value : new Date();

            if (!value && !this.option.allowEmpty) {
                value = new Date();
            }
    
            if (isNaN(Number(value)) && !this.option.allowEmpty) {
                value = new Date();
            }

            this.year = value.getFullYear();
            this.month = value.getMonth();
            this.date = value.getDate();
            this.dayOfWeek = value.getDay();
        }
    }

    private _initTextInput(): void {
        this._onTextInputChange = this._onTextInputChange.bind(this);
        this.element.addEventListener("change", this._onTextInputChange);
        this._onTextInputClickAsync = this._onTextInputClickAsync.bind(this);
        this.element.addEventListener("click", this._onTextInputClickAsync);
    }

    private _onTextInputChange(): void {
        this.setAsync(this.element.value);
    }

    private async _onTextInputClickAsync(): Promise<void> {
        await this.updateAsync();
    }

    private _initDropdown(): void {
        if (!this.dropdown) {
            this.dropdown = dropdownController.add({
                tag: "datepicker",
                container: this.option && this.option.container ? this.option.container() : undefined, 
                target: this.element,
                marginTop: 2
            });
        }
    }

    private _initYearMonthSelector(): void {
        this.yearMonthSelector = new DatepickerYearMonthSelector(this.option);
        this.yearMonthSelector.init();
        this.dropdown?.head.appendChild(this.yearMonthSelector.element);
        this.yearMonthSelector.set(!this.isEmpty && this.year !== undefined && this.month !== undefined && this.date !== undefined ? new Date(this.year, this.month, this.date) : new Date());
        this.yearMonthSelector.onSelectFuncs.push((year, month) => {
            if (this.calendar) {
                this.calendar.year = year;
                this.calendar.month = month;
                this.calendar.updateAsync();
            }
        });

        this.dropdown?.onMouseWheelUpFuncs.push(() => this.yearMonthSelector?.nextMonth());
        this.dropdown?.onMouseWheelDownFuncs.push(() => this.yearMonthSelector?.prevMonth());
    }

    private _initCalendar(): void {
        this.calendar = new DatepickerCalendar(this.option);
        this.calendar.init();
        this.dropdown?.body.appendChild(this.calendar.element);
        this.calendar.onSelectFuncs.push(date => this.setDateAsync(date));
    }

    private _initButtons(): void {
        if (!this.buttonContainer) {
            this.buttonContainer = document.createElement("table");
            this.buttonContainer.className = "button-container";
            this.dropdown?.bottom.appendChild(this.buttonContainer);
        }

        if (this.option.showTodayButton) {
            const td = document.createElement("td");
            this.buttonContainer.appendChild(td);

            this.todayButton = document.createElement("button");
            this.todayButton.className = "today-button";
            this.todayButton.type = "button";
            this.todayButton.innerText = this.option.todayText ? this.option.todayText : "\u4eca\u5929";
            this.todayButton.addEventListener("click", () => {
                const today = new Date();

                if (this.calendar) {
                    this.calendar.year = today.getFullYear();
                    this.calendar.month = today.getMonth();
                    this.calendar.updateAsync();
                }
                
                if (this.yearMonthSelector) {
                    this.yearMonthSelector.setYearMonth(today.getFullYear(), today.getMonth());
                }
            });

            td.appendChild(this.todayButton);
        }

        if (this.option.showClearButton) {
            const td = document.createElement("td");
            this.buttonContainer.appendChild(td);

            this.clearButton = document.createElement("button");
            this.clearButton.className = "clear-button";
            this.clearButton.type = "button";
            this.clearButton.innerText = this.option.clearText ? this.option.clearText : "\u6e05\u7a7a";
            this.clearButton.addEventListener("click", () => this.clearAsync());

            td.appendChild(this.clearButton);
        }
    }

    async initRangeAsync(): Promise<void> {
        if (this.option.rangeStart) {
            const rangeStartInput = this.option.rangeStart.indexOf("#") === 0 ?
                <HTMLInputElement>document.getElementById(this.option.rangeStart.replace("#", "")) :
                <HTMLInputElement>document.querySelector(this.option.rangeStart);
            const rangeStart = datepickerController.get(rangeStartInput);
            if (rangeStart) {
                this.rangeMode = "end";
                this.rangeOppsInput = rangeStart;
                
                if (this.rangeOppsInput && this.year !== undefined && this.month !== undefined && this.date !== undefined) {
                    await this.rangeOppsInput.rangeUpdateAsync({ value: new Date(this.year, this.month, this.date) });
                }
            }
        } else if (this.option.rangeEnd) {
            const rangeEndInput = this.option.rangeEnd.indexOf("#") === 0 ?
                <HTMLInputElement>document.getElementById(this.option.rangeEnd.replace("#", "")) :
                <HTMLInputElement>document.querySelector(this.option.rangeEnd);
            const rangeEnd = datepickerController.get(rangeEndInput);
            if (rangeEnd) {
                this.rangeMode = "start";
                this.rangeOppsInput = rangeEnd;

                if (this.rangeOppsInput && this.year !== undefined && this.month !== undefined && this.date !== undefined){
                    await this.rangeOppsInput.rangeUpdateAsync({ value: new Date(this.year, this.month, this.date) });
                }
            }
        }
    }

    async updateAsync(): Promise<void> {
        let value: Date | undefined;
        if (this.isEmpty) {
            value = undefined;

            if (this.calendar) {
                this.calendar.value = value;
                await this.calendar.updateAsync();
            }
            

            this.applyText("");
        } else if (this.year !== undefined && this.month !== undefined && this.date !== undefined) {
            value = new Date(this.year, this.month, this.date);

            if (this.calendar) {
                this.calendar.value = value;
                this.calendar.year = this.year;
                this.calendar.month = this.month;
                await this.calendar.updateAsync();
            }
    
            if (this.yearMonthSelector) {
                this.yearMonthSelector.setYearMonth(this.year, this.month);
            }

            this.applyText(this.format(value, this.option.format ?? this.defaultFormat));
        }

        if (this.rangeMode !== "none" && this.rangeOppsInput && value) {
            await this.rangeOppsInput.rangeUpdateAsync({ value });
        }
    }

    async updateOptionAsync(option?: DatepickerOptions): Promise<void> {
        if (option) {
            Object.keys(option).forEach(key => (<any>this.option)[key] = (<any>option)[key]);
        } else {
            this.option.input = this.element;

            const attrFormat = this.element.getAttribute("data-format");
            if (attrFormat) {
                this.option.format = attrFormat;
            }

            const attrFirstDayOfWeek = this.element.getAttribute("data-firstDayOfWeek");
            if (attrFirstDayOfWeek && !isNaN(Number(attrFirstDayOfWeek))) {
                this.option.firstDayOfWeek = <any>Number(attrFirstDayOfWeek);
            }

            const attrStartYear = this.element.getAttribute("data-start-year");
            if (attrStartYear) {
                this.option.startYear = !isNaN(Number(attrStartYear)) && attrStartYear.indexOf("+") < 0 && attrStartYear.indexOf("-") < 0 ? 
                    Number(attrStartYear) : attrStartYear;
            }

            const attrEndYear = this.element.getAttribute("data-end-year");
            if (attrEndYear) {
                this.option.endYear = !isNaN(Number(attrEndYear)) && attrEndYear.indexOf("+") < 0 && attrEndYear.indexOf("-") < 0 ? 
                    Number(attrEndYear) : attrEndYear;
            }

            const attrMode = this.element.getAttribute("data-mode");
            if (attrMode) {
                this.option.mode = <any>attrMode;
            }

            const attrStart = this.element.getAttribute("data-start");
            if (attrStart) {
                this.option.start = new Date(attrStart);
            }

            const attrEnd = this.element.getAttribute("data-end");
            if (attrEnd) {
                this.option.end = new Date(attrEnd);
            }

            const attrShowTodayButton = this.element.getAttribute("data-show-today-button");
            if (attrShowTodayButton) {
                this.option.showTodayButton = attrShowTodayButton.toLowerCase() === "true";
            }

            const attrTodayText = this.element.getAttribute("data-today-text");
            if (attrTodayText) {
                this.option.todayText = attrTodayText;
            }

            const attrRangeStart = this.element.getAttribute("range-start");
            const attrRangeEnd = this.element.getAttribute("range-end");
            const rangeStartInput = attrRangeStart && attrRangeStart.indexOf("#") === 0 ?
                <HTMLInputElement>document.getElementById(attrRangeStart.replace("#", "")) :
                attrRangeStart ? <HTMLInputElement>document.querySelector(attrRangeStart) : undefined;
            const rangeEndInput = attrRangeEnd && attrRangeEnd.indexOf("#") === 0 ?
                <HTMLInputElement>document.getElementById(attrRangeEnd.replace("#", "")) :
                attrRangeEnd ? <HTMLInputElement>document.querySelector(attrRangeEnd) : undefined;

            if (rangeStartInput) {
                this.option.rangeStart = attrRangeStart!;
            } else if (rangeEndInput) {
                this.option.rangeEnd = attrRangeEnd!;
            }

            const attrAllowEmpty = this.element.getAttribute("allow-empty");
            if (attrAllowEmpty) {
                this.option.allowEmpty = attrAllowEmpty.toLowerCase() === "true";
            }
            
            const attrShowClearButton = this.element.getAttribute("show-clear-button");
            if (attrShowClearButton && this.option.allowEmpty) {
                this.option.showClearButton = attrShowClearButton.toLowerCase() === "true";
            } else if (!this.option.allowEmpty) {
                this.option.showClearButton = false;
            }

            const attrClearText = this.element.getAttribute("data-clear-text");
            if (attrClearText) {
                this.option.clearText = attrClearText;
            }
        }

        if (this.calendar) {
            this.calendar.updateOption(this.option);
            await this.calendar.updateAsync();
        }

        if (this.yearMonthSelector) {
            this.yearMonthSelector.updateOption(this.option);
            this.yearMonthSelector.update();
        }
    }

    async rangeUpdateAsync(status: DatepickerRangeStatus): Promise<void> {
        if (this.calendar) {
            this.calendar.updateRange(this.rangeMode, status.value);
            await this.calendar.updateAsync();
        }
    }

    setAsync(value?: string | Date, silent?: boolean): Promise<void> {
        return value ? 
            this.setDateAsync(typeof value === "string" ? this.parse(value) : value, silent) :
            this.setDateAsync(undefined, silent);
    }

    async setDateAsync(date?: Date, silent?: boolean): Promise<void> {
        if (this.option.allowEmpty && !date) {
            this.isEmpty = true;
            this.year = undefined;
            this.month = undefined;
            this.date = undefined;
            this.dayOfWeek = undefined;
        } else {
            if (!date || isNaN(Number(date))) {
                this.applyText(!this.isEmpty && this.year !== undefined && this.month !== undefined && this.date !== undefined ? 
                    this.format(new Date(this.year, this.month, this.date), this.option.format ?? this.defaultFormat) : "");
                return;
            }
            
            this.isEmpty = false;
            this.year = date.getFullYear();
            this.month = date.getMonth();
            this.date = date.getDate();
            this.dayOfWeek = date.getDay();
        }

        if (!silent) {
            await Promise.all(this.onChangeFuncs.map(func => func()));
        }
        
        await this.updateAsync();

        if (this.rangeMode === "start" && this.dropdown && this.rangeOppsInput && this.dropdown.opened) {
            await this.dropdown.openAsync(false);
            if (this.rangeOppsInput.getDate() < this.getDate()) {
                await this.rangeOppsInput.setAsync(this.get());
            }

            setTimeout(() => this.rangeOppsInput?.dropdown?.openAsync(true), 100);
        }
    }

    get(): string {
        return this.format(this.getDate(), this.option.format ?? this.defaultFormat);
    }

    getDate(): Date {
        return this.year !== undefined && this.month !== undefined && this.date !== undefined ? new Date(this.year, this.month, this.date) : new Date();
    }

    format(date: Date, format: string): string {
        return datepickerController.format(date, format, this.option.yearFormater, this.option.monthFormater);
    }

    parse(value: string): Date {
        return datepickerController.parse(value, this.option.dateParser);
    }

    applyText(value?: string): void {
        this.element.value = value ? value : "";
    }

    async clearAsync(): Promise<void> {
        this.setAsync("");
    }

    async removeAsync(): Promise<void> {
        this.element.removeEventListener("change", this._onTextInputChange);
        this.element.removeEventListener("click", this._onTextInputClickAsync);
        await dropdownController.removeAsync(this.element, "datepicker");
    }

    async setDisableAsync(value?: boolean): Promise<void> {
        this.element.disabled = value !== false;

        if (this.dropdown) {
            this.dropdown.disabled = value !== false;

            if (this.dropdown.opened) {
                await this.dropdown.openAsync(false);
            }
        }
    }
}