﻿import Datepicker from "Datepicker";
import DatepickerOptions from "DatepickerOptions";
import Utility from "uform-utility";

export default class DatepickerController {

    private _currentId: number = 0;

    private _datepickers: { [id: string]: Datepicker } = {};

    private _getNewId(): number {
        return this._currentId++;
    }

    async scanAsync(): Promise<HTMLInputElement[]> {
        const selectElements: HTMLInputElement[] = [];
        const matchs = document.querySelectorAll("input.datepicker");
        for (let i = 0; i < matchs.length; i++) {
            selectElements.push(<HTMLInputElement>(matchs.item(i)));
        }

        return selectElements;
    }

    async scanAndBuildAsync(): Promise<Datepicker[]> {
        const elements = await this.scanAsync();
        const datepickers = await this.buildAsync(elements);

        const rangeMap: { start?: Datepicker, end?: Datepicker }[] = [];
        datepickers
            .filter(datepicker => datepicker.element.id && (datepicker.option.rangeStart || datepicker.option.rangeEnd))
            .forEach(datepicker => {
                const id = datepicker.element.id;
                const matchs = rangeMap.filter(pair => 
                    pair.start?.option?.rangeEnd?.replace("#", "") === id || pair.end?.option?.rangeStart?.replace("#", "") === id
                    );
                
                if (matchs.length > 0) {
                    if (datepicker.option.rangeStart) {
                        matchs[0].end = datepicker;
                    } else {
                        matchs[0].start = datepicker;
                    }
                } else {
                    if (datepicker.option.rangeStart) {
                        rangeMap.push({ start: undefined, end: datepicker });
                    } else {
                        rangeMap.push({ start: datepicker, end: undefined });
                    }
                }
            });

        rangeMap
            .filter(pair => pair.start && pair.end)
            .forEach(pair => pair.start?.initRangeAsync().then(() => pair.end?.initRangeAsync()));

        return datepickers;
    }

    get(id: number): Datepicker | undefined;
    get(element: HTMLElement): Datepicker | undefined;
    get(arg0: number | HTMLElement): Datepicker | undefined {
        if (typeof arg0 === "number") {
            return this._datepickers[String(arg0)];
        } else {
            const ids = Object.keys(this._datepickers);
            for (let i = 0; i < ids.length; i++) {
                if (this._datepickers[ids[i]].element.isSameNode(arg0)) {
                    return this._datepickers[ids[i]];
                }
            }
        }
    }

    list(): Datepicker[];
    list(id: number): Datepicker[];
    list(element: HTMLElement): Datepicker[];
    list(idOrElements: (number | HTMLElement)[]): Datepicker[];
    list(arg0?: number | HTMLElement | (number | HTMLElement)[]): Datepicker[] {
        if (!arg0) {
            return Object.keys(this._datepickers).map(id => this._datepickers[id]);
        } else if (typeof arg0 === "number") {
            return [this._datepickers[String(arg0)]].filter(datepicker => !!datepicker);
        } else if (Array.isArray(arg0)) {
            return arg0
                .map(item => {
                    if (typeof item === "number") {
                        return this._datepickers[String(item)];
                    } else {
                        return this.get(item);
                    }
                })
                .filter(datepicker => !!datepicker)
                .map(datepicker => datepicker!);
        } else {
            const datepickers: Datepicker[] = [];
            const ids = Object.keys(this._datepickers);
            for (let i = 0; i < ids.length; i++) {
                if (this._datepickers[i].element.isSameNode(arg0)) {
                    datepickers.push(this._datepickers[i]);
                }
            }

            return datepickers;
        }
    }

    buildAsync(options: DatepickerOptions): Promise<Datepicker[]>;
    buildAsync(element: HTMLInputElement): Promise<Datepicker[]>;
    buildAsync(elements: HTMLInputElement[]): Promise<Datepicker[]>;
    async buildAsync(arg0: DatepickerOptions | HTMLInputElement | HTMLInputElement[]): Promise<Datepicker[]> {
        if ("input" in arg0) {
            if (!arg0.input) {
                return [];
            }

            const exists = this.get(arg0.input);
            if (exists) {
                return [exists];
            }

            const id = this._getNewId();
            const datepicker = new Datepicker(arg0.input, id, arg0);
            await datepicker.initAsync();
            await datepicker.updateAsync();
            this._datepickers[String(id)] = datepicker;

            return [datepicker];
        } else {
            const datepickers: Datepicker[] = [];
            const elements = Array.isArray(arg0) ? arg0 : [arg0];
            for (let i = 0; i < elements.length; i++) {
                if (!elements[i]) {
                    continue;
                }

                const exists = this.get(elements[i]);
                if (exists) {
                    datepickers.push(exists);
                    continue;
                }

                const id = this._getNewId();
                const datepicker = new Datepicker(elements[i], id);
                await datepicker.initAsync();
                await datepicker.updateAsync();
                this._datepickers[String(id)] = datepicker;

                datepickers.push(datepicker);
            }

            return datepickers;
        }
    }

    updateAsync(): Promise<void>;
    updateAsync(id: number): Promise<void>;
    updateAsync(element: HTMLSelectElement): Promise<void>;
    updateAsync(idOrElements: (number | HTMLElement)[]): Promise<void>;
    async updateAsync(arg0?: number | HTMLSelectElement | (number | HTMLElement)[]): Promise<void> {
        await Promise.all(this.list(<any>arg0).map(datepicker => datepicker.updateAsync()));
    }

    rebuildAsync(): Promise<void>;
    rebuildAsync(id: number): Promise<void>;
    rebuildAsync(element: HTMLSelectElement): Promise<void>;
    rebuildAsync(idOrElements: (number | HTMLElement)[]): Promise<void>;
    async rebuildAsync(arg0?: number | HTMLSelectElement | (number | HTMLElement)[]): Promise<void> {
        await Promise.all(this.list(<any>arg0).map(async datepicker => {
            const id = datepicker.id;
            const element = datepicker.element;
            await datepicker.removeAsync();

            const newDatepicker = new Datepicker(element, id);
            await newDatepicker.initAsync();
            await newDatepicker.updateAsync();
        }));
    }

    removeAsync(): Promise<void>;
    removeAsync(id: number): Promise<void>;
    removeAsync(element: HTMLSelectElement): Promise<void>;
    removeAsync(idOrElements: (number | HTMLElement)[]): Promise<void>;
    async removeAsync(arg0?: number | HTMLSelectElement | (number | HTMLElement)[]): Promise<void> {
        await Promise.all(this.list(<any>arg0).map(async datepicker => {
            const id = datepicker.id;
            await datepicker.removeAsync();
            delete this._datepickers[id];
        }));
    }

    async buildRangeAsync(
        startElement: HTMLInputElement, endElement: HTMLInputElement,
        startOption?: DatepickerOptions, endOption?: DatepickerOptions
        ): Promise<{ start: Datepicker, end: Datepicker } | undefined>
    {
        let startId = this._getElementId(startElement);
        let endId = this._getElementId(endElement);
        
        if (startId === -1) {
            const datepickers = await (startOption && "input" in startOption ? this.buildAsync(startOption) : this.buildAsync(startElement));
            startId = datepickers.length > 0 ? datepickers[0].id : -1;
        }

        if (endId === -1) {
            const datepickers = await (endOption && "input" in endOption ? this.buildAsync(endOption) : this.buildAsync(endElement));
            endId = datepickers.length > 0 ? datepickers[0].id : -1;
        }

        if (startId === -1 || endId === -1) {
            console.log("failed to build range.");
            return;
        }

        const start = this.get(startId);
        const end = this.get(endId);

        if (start && end) {
            const timer = setInterval(() => {
                const startAppended = Utility.isAppendedToDocument(start.element);
                if (!startAppended) {
                    return;
                }
                const endAppended = Utility.isAppendedToDocument(end.element);
                if (!endAppended) {
                    return;
                }
    
                clearInterval(timer);
                start.initRangeAsync().then(() => end.initRangeAsync());
            }, 100);
    
            return { start, end };
        }
    }

    format(date: Date, format: string, yearFormater?: (year: number) => string, monthFormater?: (month: number) => string): string {
        const year = date.getFullYear();
        const month = date.getMonth();
        const day = date.getDate();

        let result = String(format);
        if (format.indexOf("yyyy") >= 0) {
            result = result.replace("yyyy", yearFormater ? yearFormater(year) : String(year));
        }

        if (format.indexOf("MM") >= 0) {
            const m = month + 1;
            result = result.replace("MM", monthFormater ? monthFormater(m) : String(m < 10 ? "0" + m : m));
        } else if (format.indexOf("M") >= 0) {
            result = result.replace("M", monthFormater ? monthFormater(month + 1) : String(month + 1));
        }

        if (format.indexOf("dd") >= 0) {
            result = result.replace("dd", String(day < 10 ? "0" + day : day));
        } else if (format.indexOf("d") >= 0) {
            result = result.replace("d", String(day));
        }

        if (result.indexOf("NaN") >= 0) {
            return "";
        }

        return result;
    }

    parse(value: string, dateParser?: (text: string) => Date): Date {
        return !dateParser ? new Date(value) : dateParser(value);
    }

    private _getElementId(element?: HTMLInputElement): number {
        if (element) {
            const ids = Object.keys(this._datepickers);
            for (let i = 0; i < ids.length; i++) {
                const id = ids[i];
                if (this._datepickers[id].element.isSameNode(element)) {
                    return Number(id);
                }
            }
        }
        return -1;
    }
}

export const datepickerController = new DatepickerController();
(<any>window).datepickerController = datepickerController;

datepickerController.scanAndBuildAsync();