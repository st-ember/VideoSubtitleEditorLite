﻿
export default interface DatepickerOptions {
    container?: () => HTMLElement;
    input: HTMLInputElement;
    format?: string;
    firstDayOfWeek?: 0 | 1 | 2 | 3 | 4 | 5 | 6;
    monthFormater?: (month: number) => string;
    startYear?: number | string;
    endYear?: number | string;
    yearFormater?: (year: number) => string;
    dateParser?: (text: string) => Date;
    weekTexts?: string[];
    mode?: "date" | "week" | "weekend";
    start?: Date;
    end?: Date;
    value?: Date;
    rangeStart?: string;
    rangeEnd?: string;
    showTodayButton?: boolean;
    todayText?: string;
    allowEmpty?: boolean;
    showClearButton?: boolean;
    clearText?: string;
}