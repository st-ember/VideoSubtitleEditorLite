﻿import DatepickerOptions from "DatepickerOptions";

export default class DatepickerYearMonthSelector {

    element: HTMLDivElement = document.createElement("div");

    lastMonthButton: HTMLButtonElement = document.createElement("button");
    nextMonthButton: HTMLButtonElement = document.createElement("button");
    monthSelector?: HTMLSelectElement;
    yearSelector?: HTMLSelectElement;

    onSelectFuncs: ((year: number, month: number) => void)[] = [];

    monthFormater: (month: number) => string = 
        (month: number) => [
            "\u4e00\u6708", "\u4e8c\u6708", "\u4e09\u6708", "\u56db\u6708", "\u4e94\u6708", "\u516d\u6708", 
            "\u4e03\u6708", "\u516b\u6708", "\u4e5d\u6708", "\u5341\u6708", "\u5341\u4e00\u6708", "\u5341\u4e8c\u6708"][month];

    startYear: number | string = 2010;
    endYear: number | string = "0";

    yearFormater: (year: number) => string = (year: number) => String(year);

    month: number;
    year: number;

    constructor(option: DatepickerOptions) {
        this.updateOption(option);
        this.year = new Date().getFullYear();
        this.month = new Date().getMonth();

        this.nextMonth = this.nextMonth.bind(this);
        this.prevMonth = this.prevMonth.bind(this);
    }

    init(): void {
        this.element.className = "year-month-selector";

        this.lastMonthButton.type = "button";
        this.lastMonthButton.className = "last-button";
        this.lastMonthButton.innerText = "\u00ab";
        this.element.appendChild(this.lastMonthButton);

        this._initYearSelector();
        this._initMonthSelector();

        this.nextMonthButton.type = "button";
        this.nextMonthButton.className = "next-button";
        this.nextMonthButton.innerText = "\u00bb";
        this.element.appendChild(this.nextMonthButton);

        this.lastMonthButton.addEventListener("click", this.prevMonth);
        this.nextMonthButton.addEventListener("click", this.nextMonth);
    }

    private _initMonthSelector(): void {
        if (this.monthSelector) {
            while (this.monthSelector.lastChild) {
                this.monthSelector.removeChild(this.monthSelector.lastChild);
            }
        } else {
            this.monthSelector = document.createElement("select");
            this.monthSelector.className = "month-select";
            this.monthSelector.title = "Month";
            this.element.appendChild(this.monthSelector);
            this.monthSelector.addEventListener("change", () => this._onSelect());
        }

        for (let i = 0; i < 12; i++) {
            const option = document.createElement("option");
            option.value = String(i);
            option.innerHTML = this.monthFormater(i);
            this.monthSelector.appendChild(option);

            if (i === this.month) {
                option.selected = true;
            }
        }
    }

    private _initYearSelector(): void {
        if (this.yearSelector) {
            while (this.yearSelector.lastChild) {
                this.yearSelector.removeChild(this.yearSelector.lastChild);
            }
        } else {
            this.yearSelector = document.createElement("select");
            this.yearSelector.className = "year-select";
            this.yearSelector.title = "Year";
            this.element.appendChild(this.yearSelector);
            this.yearSelector.addEventListener("change", () => this._onSelect());
        }

        const thisYear = new Date().getFullYear();

        let startYear: number | undefined = undefined;
        if (typeof this.startYear === "string") {
            if (this.startYear.indexOf("+") === 0) {
                const diff = Number(this.startYear.substring(1));
                if (!isNaN(diff) && diff >= 0) {
                    startYear = thisYear + diff;
                }
            } else if (this.startYear.indexOf("-") === 0) {
                const diff = Number(this.startYear.substring(1));
                if (!isNaN(diff) && diff >= 0) {
                    startYear = thisYear - diff;
                }
            }
        } else {
            startYear = this.startYear;
        }

        if (startYear === undefined) {
            startYear = 2010;
        }

        let endYear: number | undefined = undefined;
        if (typeof this.endYear === "string") {
            if (this.endYear.indexOf("+") === 0) {
                const diff = Number(this.endYear.substring(1));
                if (!isNaN(diff) && diff >= 0) {
                    endYear = thisYear + diff;
                }
            } else if (this.endYear.indexOf("-") === 0) {
                const diff = Number(this.endYear.substring(1));
                if (!isNaN(diff) && diff >= 0) {
                    endYear = thisYear - diff;
                }
            }
        } else {
            endYear = this.endYear;
        }
        
        if (endYear === undefined) {
            endYear = thisYear;
        }

        if (startYear > endYear) {
            endYear = startYear;
        }

        for (let i = 0; i < endYear - startYear + 1; i++) {
            const year = startYear + i;
            const option = document.createElement("option");
            option.value = String(year);
            option.innerHTML = this.yearFormater(year);
            this.yearSelector.appendChild(option);

            if (year === this.year) {
                option.selected = true;
            }
        }
    }

    private _onSelect(): void {
        this.year = this.getYear();
        this.month = this.getMonth();
        this.onSelectFuncs.forEach(func => func(this.year, this.month));
    }

    getYear(): number {
        return Number(this.yearSelector?.value ?? new Date().getFullYear());
    }

    getMonth(): number {
        return Number(this.monthSelector?.value ?? new Date().getMonth());
    }

    getDate(): Date {
        return new Date(this.getYear + "-" + String(this.getMonth() + 1) + "-1");
    }

    setYear(year: number): void {
        this.year = year;
        if (this.yearSelector) {
            this.yearSelector.value = String(year);
        }
    }

    setMonth(month: number): void {
        this.month = month;
        if (this.monthSelector) {
            this.monthSelector.value = String(month);
        }
    }

    setYearMonth(year: number, month: number): void {
        this.setYear(year);
        this.setMonth(month);
    }

    set(date: Date): void {
        const year = date.getFullYear();
        const month = date.getMonth();

        this.setYear(year);
        this.setMonth(month);
        this.onSelectFuncs.forEach(func => func(year, month));
    }

    update(): void {
        this.setYear(this.year);
        this.setMonth(this.month);
    }

    updateOption(option: DatepickerOptions): void {
        if (option.monthFormater) {
            this.monthFormater = option.monthFormater;
        }

        if (option.startYear !== undefined && option.startYear !== null) {
            this.startYear = option.startYear;
        }

        if (option.endYear !== undefined && option.endYear !== null) {
            this.endYear = option.endYear;
        }

        if (option.yearFormater) {
            this.yearFormater = option.yearFormater;
        }

        if (this.yearSelector) {
            this._initYearSelector();
        }

        if (this.monthSelector) {
            this._initMonthSelector();
        }
    }

    nextMonth(): void {
        const year = this.getYear();
        const month = this.getMonth();
        if (this.monthSelector && this.yearSelector) {
            if (month === 11) {
                this.monthSelector.value = "0";
                this.yearSelector.value = String(year + 1);
            } else {
                this.monthSelector.value = String(month + 1);
            }
        }

        this._onSelect();
    }

    prevMonth(): void {
        const year = this.getYear();
        const month = this.getMonth();
        if (this.monthSelector && this.yearSelector) {
            if (month === 0) {
                this.monthSelector.value = "11";
                this.yearSelector.value = String(year - 1);
            } else {
                this.monthSelector.value = String(month - 1);
            }
        }

        this._onSelect();
    }
}