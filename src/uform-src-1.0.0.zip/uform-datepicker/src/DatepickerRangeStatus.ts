﻿
export default interface DatepickerRangeStatus {
    value: Date;
}