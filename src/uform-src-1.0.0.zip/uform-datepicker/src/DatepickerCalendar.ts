﻿import DatepickerOptions from "DatepickerOptions";

export default class DatepickerCalendar {

    element: HTMLDivElement = document.createElement("div");

    year: number;
    month: number;
    firstDayOfWeek: number = 0;
    value?: Date;
    start?: Date;
    end?: Date;
    rangeMode: "none" | "start" | "end" = "none";
    rangeValue?: Date;
    mode: "date" | "week" | "weekend" = "date";

    rows: HTMLDivElement[] = [];

    onSelectFuncs: ((date: Date) => Promise<void>)[] = [];

    weekTexts: string[] = ["\u65e5", "\u4e00", "\u4e8c", "\u4e09", "\u56db", "\u4e94", "\u516d"];

    constructor(option: DatepickerOptions) {
        this.updateOption(option);

        this.year = new Date().getFullYear();
        this.month = new Date().getMonth();
    }

    init(): void {
        this.element.className = "date-calendar";

        this._initWeekRow();
        this._initWeeks();
    }

    private _initWeekRow(): void {
        const weekRow = document.createElement("div");
        weekRow.className = "week-row week-head-row";
        this.element.appendChild(weekRow);

        for (let i = 0; i < 7; i++) {
            const cell = document.createElement("div");
            cell.className = "week-cell";

            const weekTextIndex = i + this.firstDayOfWeek;
            const weekText = weekTextIndex < this.weekTexts.length ?
                this.weekTexts[weekTextIndex] : this.weekTexts[weekTextIndex - this.weekTexts.length];

            cell.innerHTML = "<span>" + weekText + "</span>";
            weekRow.appendChild(cell);
        }
    }

    private _initWeeks(): void {
        const start = this._getStart();
        const end = this._getEnd();
        const today = new Date();
        const date = new Date(this.year, this.month, 1);
        const dayOfWeek = date.getDay();
        const dayIndex = dayOfWeek !== 0 ? this.firstDayOfWeek - dayOfWeek : (this.firstDayOfWeek === 0 ? 0 : 0 - (dayOfWeek + 7));
        const valueText = this.value ? this._formatToString(this.value) : undefined;
        const rangeValueText = this.rangeValue ? this._formatToString(this.rangeValue) : undefined;
        date.setDate(dayIndex + 1);

        const todayYear = today.getFullYear();
        const todayMonth = today.getMonth();
        const todayDate = today.getDate();

        for (let i = 0; i < 6; i++) {
            const weekDate = this._formatToString(date);
            const row = document.createElement("div");
            row.className = "week-row";
            row.setAttribute("data-week", weekDate);
            row.addEventListener("mouseenter", () => this._onWeekFocus(row));
            row.addEventListener("mouseleave", () => this._onWeekBlur(row));
            row.addEventListener("click", () => this._onWeekSelect(row));

            if (this.mode !== "date" && valueText === weekDate) {
                row.classList.add("selected");
            }

            let lastDate: string | undefined = undefined;
            let validDateCount: number = 0;
            for (let j = 0; j < 7; j++) {
                const cell = document.createElement("div");
                cell.className = "week-cell";

                const y = date.getFullYear();
                const m = date.getMonth();
                const d = date.getDate();
                if (m !== this.month) {
                    cell.classList.add("off");
                }

                if (todayYear === y && todayMonth === m && todayDate === d) {
                    cell.classList.add("today");
                }

                lastDate = this._formatToString(date);

                if (this.mode === "weekend" && j < 4 || start && start > date || end && end < date) {
                    cell.classList.add("disabled");
                } else {
                    validDateCount++;
                    if (this.rangeMode === "start" && this.value && this.value <= date && this.rangeValue && date <= this.rangeValue || 
                        this.rangeMode === "end" && this.rangeValue && this.rangeValue <= date && this.value && date <= this.value) {
                            cell.classList.add("ranged");
                    }

                    if (this.rangeMode === "start" && valueText === lastDate || this.rangeMode === "end" && rangeValueText === lastDate) {
                        cell.classList.add("range-start");
                    }

                    if (this.rangeMode === "end" && valueText === lastDate || this.rangeMode === "start" && rangeValueText === lastDate) {
                        cell.classList.add("range-end");
                    }
                }

                if (this.mode === "date" && valueText === lastDate) {
                    cell.classList.add("selected");
                }

                cell.innerHTML = "<span>" + String(d) + "</span>";
                cell.setAttribute("data-date", lastDate);
                cell.addEventListener("mouseenter", () => this._onDateFocus(cell));
                cell.addEventListener("mouseleave", () => this._onDateBlur(cell));
                cell.addEventListener("click", () => this._onDateSelect(cell));

                date.setDate(d + 1);
                row.appendChild(cell);
            }

            if (this.mode !== "date" && validDateCount === 0) {
                row.classList.add("disabled");
            }

            row.setAttribute("data-last-date", lastDate ?? "");
            this.element.appendChild(row);
            this.rows.push(row);
        }
    }

    private _onDateFocus(cell: HTMLDivElement): void {
        if (this.mode !== "date" || cell.classList.contains("disabled")) { return; }
        cell.classList.add("focus");
    }

    private _onDateBlur(cell: HTMLDivElement): void {
        if (this.mode !== "date") { return; }
        cell.classList.remove("focus");
    }

    private _onDateSelect(cell: HTMLDivElement): void {
        if (this.mode !== "date" || cell.classList.contains("disabled")) { return; }
        this.setAsync(cell.getAttribute("data-date")!);
    }

    private _onWeekFocus(row: HTMLDivElement): void {
        if (this.mode === "date" || row.classList.contains("disabled")) { return; }
        row.classList.add("focus");
    }

    private _onWeekBlur(row: HTMLDivElement): void {
        if (this.mode === "date") { return; }
        row.classList.remove("focus");
    }

    private _onWeekSelect(row: HTMLDivElement): void {
        if (this.mode === "date" || row.classList.contains("disabled")) { return; }
        this.setAsync(row.getAttribute("data-week")!);
    }

    setAsync(value: string | Date): Promise<void> {
        return this.setDateAsync(typeof value === "string" ? new Date(value) : value);
    }

    async setDateAsync(date: Date): Promise<void> {
        this.value = date;
        for (let i = 0; i < this.onSelectFuncs.length; i++) {
            await this.onSelectFuncs[i](date);
        }
    }

    async updateAsync(): Promise<void> {
        this.rows.forEach(row => row.remove());
        this.rows = [];

        if (!this.value) {
            this._initWeeks();
            return;
        }

        const start = this._getStart();
        const end = this._getEnd();
        if (this.mode === "date") {
            if (end && end < this.value || start && start > this.value) {
                if (!end && start) {
                    this.value = new Date(start.getFullYear(), start.getMonth(), start.getDate());
                } else if (end) {
                    this.value = new Date(end.getFullYear(), end.getMonth(), end.getDate());
                }

                await this.setDateAsync(this.value);
            } else {
                this._initWeeks();
            }
        } else {
            const weekStart = this.value;
            const weekEnd = new Date(weekStart.getFullYear(), weekStart.getMonth(), weekStart.getDate() + 6);
            if (end && end < weekStart || start && start > weekEnd) {
                if (!this.end && this.start && start) {
                    this.value = new Date(start.getFullYear(), start.getMonth(), start.getDate());
                } else if (end) {
                    this.value = new Date(end.getFullYear(), end.getMonth(), end.getDate());
                }
            }

            const firstDayOfWeek = this._formatToString(this._findFirstDayOfWeek(this.value));
            if (this._formatToString(this.value) !== firstDayOfWeek) {
                await this.setAsync(firstDayOfWeek);
            } else {
                this._initWeeks();
            }
        }
    }

    updateOption(option: DatepickerOptions): void {
        if (option.mode) {
            this.mode = option.mode;
        }

        if (option.weekTexts && option.weekTexts.length === 7) {
            this.weekTexts = option.weekTexts;
        }

        if (option.firstDayOfWeek) {
            this.firstDayOfWeek = option.firstDayOfWeek;
        }

        this.start = option.start ? option.start : undefined;
        this.end = option.end ? option.end : undefined;

        if (this.start && this.end && this.start > this.end) {
            this.start = new Date(this.end.getFullYear(), this.end.getMonth(), this.end.getDate());
        }
    }

    updateRange(mode: "none" | "start" | "end", value?: Date): void {
        this.rangeMode = mode;
        this.rangeValue = value;
    }

    private _getStart(): Date | undefined {
        if (this.rangeMode === "end" && !this.start) {
            return this.rangeValue;
        } else if (this.rangeMode === "end" && this.start) {
            return this.rangeValue && this.rangeValue > this.start ? this.rangeValue : this.start;
        } else {
            return undefined;
        }
    }

    private _getEnd(): Date | undefined {
        return this.rangeMode !== "start" && this.end ? this.end : undefined;
    }

    private _findFirstDayOfWeek(date: Date): Date {
        const value = new Date(date.getFullYear(), date.getMonth(), date.getDate());
        while (value.getDay() !== this.firstDayOfWeek) {
            value.setDate(value.getDate() - 1);
        }
        return value;
    }

    private _formatToString(date: Date): string {
        const month = date.getMonth() + 1;
        const day = date.getDate();
        return String(date.getFullYear()) + "-" + (month < 10 ? "0" + month : month) + "-" + (day > 10 ? day : "0" + day);
    }
}