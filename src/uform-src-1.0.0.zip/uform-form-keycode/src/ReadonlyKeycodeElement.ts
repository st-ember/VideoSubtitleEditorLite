import { FormElementGeneric, FormElementOptions } from "uform-form";
import KeycodeData from "./KeycodeData";

export default class ReadonlyKeycodeElement extends FormElementGeneric<KeycodeData> implements FormElementOptions {

    element: HTMLElement = document.createElement("div");
    codeContainer: HTMLElement = document.createElement("div");

    private _emptyKeycodeData: KeycodeData = {
        keyCodes: [],
        withCtrl: false,
        withShift: false,
        withAlt: false
    };

    private static _keyTextMap: {[key: string]: string} = {
        " ": "Space",
        "ArrowUp": "↑",
        "ArrowRight": "→",
        "ArrowDown": "↓",
        "ArrowLeft": "←",
    };

    private _keycodeData: KeycodeData;

    constructor(options?: FormElementOptions) {
        super(options);
        this.bindOptions(options);
        this._keycodeData = { ...this._emptyKeycodeData };
    }

    static fromAsync(options?: FormElementOptions): Promise<ReadonlyKeycodeElement> {
        return <Promise<ReadonlyKeycodeElement>>new ReadonlyKeycodeElement(options).buildAsync();
    }

    protected async buildElementAsync(): Promise<void> {
        this.element.className = "keycode-input readonly-keycode-input";
        this.container.appendChild(this.element);

        this.codeContainer.className = "keycode-container";
        this.element.appendChild(this.codeContainer);
    }

    private _updateCodeContainer(): void {
        this.codeContainer.innerHTML = ReadonlyKeycodeElement.convertKeycodeDataToHtml(this._keycodeData);
    }

    static convertKeycodeDataToHtml(keycodeData: KeycodeData): string {
        const keys = Object.keys(this._keyTextMap);
        const adoptedKeycodes = keycodeData.keyCodes.map(o => keys.indexOf(o) >= 0 ? this._keyTextMap[o] : o);
        return adoptedKeycodes.length > 0 ?
            `${(keycodeData.withCtrl ? `<span class="key-code">Ctrl</span><span class="key-code-plus">+</span>` : "")}
            ${(keycodeData.withShift ? `<span class="key-code">Shift</span><span class="key-code-plus">+</span>` : "")}
            ${(keycodeData.withAlt ? `<span class="key-code">Alt</span><span class="key-code-plus">+</span>` : "")}
            ${adoptedKeycodes.map(o => `<span class="key-code">${o.length === 1 ? o.toUpperCase() : o}</span>`).join("")}` : 
            "";
    }

    async rebuildAsync(): Promise<void> { }

    async deleteAsync(): Promise<void> { }

    async validateAsync(): Promise<boolean> {
        return this._keycodeData.keyCodes && this._keycodeData.keyCodes.length > 0;
    }

    async setDisableAsync(disable?: boolean | undefined): Promise<void> { }

    async clearAsync(): Promise<void> {
        this._keycodeData = { ...this._emptyKeycodeData };
        this._updateCodeContainer();
    }

    async setValueAsync(value: KeycodeData): Promise<void> {
        this._keycodeData = { ...value };
        this._updateCodeContainer();
    }

    async getValueAsync(): Promise<KeycodeData> {
        return { ...this._keycodeData };
    }
}