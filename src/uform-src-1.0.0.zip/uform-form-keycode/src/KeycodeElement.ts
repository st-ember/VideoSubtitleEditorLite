import { FormElementGeneric } from "uform-form";
import KeycodeData from "./KeycodeData";
import KeycodeElementOptions from "./KeycodeElementOptions";

export default class KeycodeElement extends FormElementGeneric<KeycodeData> implements KeycodeElementOptions {
    multipleKey?: boolean = false;
    allowCtrl?: boolean = true;
    allowShift?: boolean = true;
    allowAlt?: boolean = true;
    triggerButtonText?: string = "設定";
    finishButtonText?: string = "完成";
    cancelButtonText?: string = "取消";
    listenModeText?: string = "側錄中，按下鍵盤按鍵來設定！";

    element: HTMLElement = document.createElement("div");
    codeContainer: HTMLElement = document.createElement("div");
    triggerButton: HTMLButtonElement = document.createElement("button");
    cancelButton: HTMLButtonElement = document.createElement("button");

    private _emptyKeycodeData: KeycodeData = {
        keyCodes: [],
        withCtrl: false,
        withShift: false,
        withAlt: false
    };

    private static _keyTextMap: {[key: string]: string} = {
        " ": "Space",
        "ArrowUp": "↑",
        "ArrowRight": "→",
        "ArrowDown": "↓",
        "ArrowLeft": "←",
    };

    private _keycodeData: KeycodeData;
    private _keycodeDataBackup: KeycodeData;

    private _setupMode: boolean = false;
    private _keyboardListenMode: boolean = false;
    private _listenStates: { key: string, keydown: boolean }[] = [];

    constructor(options?: KeycodeElementOptions) {
        super(options);
        this.bindOptions(options);
        this._keycodeData = { ...this._emptyKeycodeData };
        this._keycodeDataBackup = { ...this._emptyKeycodeData };
    }

    static fromAsync(options?: KeycodeElementOptions): Promise<KeycodeElement> {
        return <Promise<KeycodeElement>>new KeycodeElement(options).buildAsync();
    }

    protected async buildElementAsync(): Promise<void> {
        this.element.className = "keycode-input";
        this.container.appendChild(this.element);

        this.codeContainer.className = "keycode-container";
        this.element.appendChild(this.codeContainer);

        this.triggerButton.className = "setup-button small-button";
        this.triggerButton.type = "button";
        this.triggerButton.title = this.triggerButtonText ?? "設定";
        this.triggerButton.innerText = this.triggerButtonText ?? "設定";
        this.triggerButton.disabled = this.disabled !== false;
        this.element.appendChild(this.triggerButton);

        this.cancelButton.className = "cancel-button small-button default";
        this.cancelButton.type = "button";
        this.cancelButton.title = this.cancelButtonText ?? "取消";
        this.cancelButton.innerText = this.cancelButtonText ?? "取消";
        this.cancelButton.style.display = "none";
        this.element.appendChild(this.cancelButton);

        this._onKeyDown = this._onKeyDown.bind(this);
        this._onKeyUp = this._onKeyUp.bind(this);
        this._bindEvents();
    }

    private _bindEvents(): void {
        this.triggerButton.addEventListener("click", () => {
            this.setSetupModeAsync(!this._setupMode);
            this.triggerButton.blur();
        });

        this.cancelButton.addEventListener("click", () => {
            this._keycodeData = { ...this._keycodeDataBackup };
            this.setSetupModeAsync(false);
            this.cancelButton.blur();
        });
    }

    private _onKeyDown(keyboardEvent: KeyboardEvent): void {
        keyboardEvent.preventDefault();

        if (!this._keyboardListenMode) {
            this._keyboardListenMode = true;
            this._keycodeData = { ...this._emptyKeycodeData };
            this._listenStates = [];
        }

        const matchs = this._listenStates.filter(o => o.key === keyboardEvent.key);
        if (matchs.length === 0) {
            this._listenStates.push({ key: keyboardEvent.key, keydown: true });
        } else {
            matchs[0].keydown = true;
        }

        this._updateKeycodeDataFromListenStates();
        this._updateCodeContainer();
    }

    private _onKeyUp(keyboardEvent: KeyboardEvent): void {
        keyboardEvent.preventDefault();
        
        const matchs = this._listenStates.filter(o => o.key === keyboardEvent.key);
        if (matchs.length === 0) {
            this._listenStates.push({ key: keyboardEvent.key, keydown: false });
        } else {
            matchs[0].keydown = false;
        }

        if (this._listenStates.filter(o => o.keydown).length === 0) {
            this._keyboardListenMode = false;
        }

        this._updateKeycodeDataFromListenStates();
        this._updateCodeContainer();
    }

    private _updateKeycodeDataFromListenStates(): void {
        const adoptedKeycodes = this._listenStates.filter(o => o.key !== "Control" && o.key !== "Shift" && o.key !== "Alt").map(o => o.key);
        this._keycodeData = {
            keyCodes: !this.multipleKey && adoptedKeycodes.length > 0 ? [adoptedKeycodes[0]] : adoptedKeycodes,
            withCtrl: this.allowCtrl !== false && this._listenStates.filter(o => o.key === "Control").length > 0,
            withShift: this.allowShift !== false && this._listenStates.filter(o => o.key === "Shift").length > 0,
            withAlt: this.allowAlt !== false && this._listenStates.filter(o => o.key === "Alt").length > 0
        };
    }

    private _updateCodeContainer(): void {
        if (!this._keycodeData || !this._keycodeData.keyCodes) {
            this.codeContainer.innerHTML = "";
            return;
        }

        const html = KeycodeElement.convertKeycodeDataToHtml(this._keycodeData);
        this.codeContainer.innerHTML = html ? html : (this._setupMode ? `<span class="placeholder">${this.listenModeText}</span>` : "");
    }

    static convertKeycodeDataToHtml(keycodeData: KeycodeData): string {
        const keys = Object.keys(this._keyTextMap);
        const adoptedKeycodes = keycodeData.keyCodes.map(o => keys.indexOf(o) >= 0 ? this._keyTextMap[o] : o);
        return adoptedKeycodes.length > 0 ?
            `${(keycodeData.withCtrl ? `<span class="key-code">Ctrl</span><span class="key-code-plus">+</span>` : "")}
            ${(keycodeData.withShift ? `<span class="key-code">Shift</span><span class="key-code-plus">+</span>` : "")}
            ${(keycodeData.withAlt ? `<span class="key-code">Alt</span><span class="key-code-plus">+</span>` : "")}
            ${adoptedKeycodes.map(o => `<span class="key-code">${o.length === 1 ? o.toUpperCase() : o}</span>`).join("")}` : 
            "";
    }

    async setSetupModeAsync(trigger: boolean): Promise<void> {
        if (this._setupMode === trigger) {
            return;
        }

        this._setupMode = trigger;

        if (this._setupMode) {
            this.cancelButton.style.display = "";
            this.triggerButton.innerText = this.finishButtonText ?? "完成";
            this.triggerButton.classList.add("primary");
            this._keycodeDataBackup = { ...this._keycodeData };
            this._keycodeData = { ...this._emptyKeycodeData };

            window.addEventListener("keydown", this._onKeyDown);
            window.addEventListener("keyup", this._onKeyUp);
        } else {
            this.cancelButton.style.display = "none";
            this.triggerButton.innerText = this.triggerButtonText ?? "設定";
            this.triggerButton.classList.remove("primary");
            window.removeEventListener("keydown", this._onKeyDown);
            window.removeEventListener("keyup", this._onKeyUp);
            await this.changeAsync();
        }

        this._updateCodeContainer();
    }

    async rebuildAsync(): Promise<void> { }

    async deleteAsync(): Promise<void> {
        await this.setSetupModeAsync(false);
    }

    async validateAsync(): Promise<boolean> {
        return this._keycodeData.keyCodes && this._keycodeData.keyCodes.length > 0;
    }

    async setDisableAsync(disable?: boolean | undefined): Promise<void> {
        if (disable !== false) {
            await this.setSetupModeAsync(false);
        }

        this.triggerButton.disabled = this.disabled !== false;
    }

    async clearAsync(): Promise<void> {
        this._keycodeData = { ...this._emptyKeycodeData };
        this._updateCodeContainer();
    }

    async setValueAsync(value: KeycodeData): Promise<void> {
        this._keycodeData = { ...value };
        this._updateCodeContainer();
    }

    async getValueAsync(): Promise<KeycodeData> {
        return { ...this._keycodeData };
    }
}