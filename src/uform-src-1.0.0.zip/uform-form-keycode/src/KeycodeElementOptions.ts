import { FormElementOptions } from "uform-form";

export default interface KeycodeElementOptions extends FormElementOptions {
    multipleKey?: boolean;
    allowCtrl?: boolean;
    allowShift?: boolean;
    allowAlt?: boolean;
    triggerButtonText?: string;
    finishButtonText?: string;
    cancelButtonText?: string;
    listenModeText?: string;
}