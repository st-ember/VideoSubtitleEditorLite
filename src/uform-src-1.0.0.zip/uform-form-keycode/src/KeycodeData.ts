
export default interface KeycodeData {
    keyCodes: string[];
    withCtrl: boolean;
    withShift: boolean;
    withAlt: boolean;
}