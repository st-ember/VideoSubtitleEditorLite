import { Form } from "uform-form";
import KeycodeElement from "./KeycodeElement";
import ReadonlyKeycodeElement from "./ReadonlyKeycodeElement";

async function testAsync(): Promise<void> {
    const target = document.getElementById("test-form-0");
    if (target) {
        const form = new TestForm(target);
        await form.buildAsync();
    }
}

class TestForm extends Form {
    
    async buildChildrenAsync(): Promise<void> {
        
        const keycodeInput = await KeycodeElement.fromAsync({
            multipleKey: true,
            label: "鍵盤按鍵",
            disabled: false,
            allowShift: false
        });
        await this.appendAsync(keycodeInput);

        const readonlyKeycodeInput = await ReadonlyKeycodeElement.fromAsync({
            label: "唯讀"
        });
        await this.appendAsync(readonlyKeycodeInput);

        keycodeInput.addChangeFunc(async () => {
            const value = await keycodeInput.getValueAsync();
            readonlyKeycodeInput.setValueAsync(value);
        });
    }
}

testAsync();