﻿define("KeycodeData", ["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
});
define("KeycodeElementOptions", ["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
});
define("KeycodeElement", ["require", "exports", "uform-form"], function (require, exports, uform_form_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    class KeycodeElement extends uform_form_1.FormElementGeneric {
        constructor(options) {
            super(options);
            this.multipleKey = false;
            this.allowCtrl = true;
            this.allowShift = true;
            this.allowAlt = true;
            this.triggerButtonText = "設定";
            this.finishButtonText = "完成";
            this.cancelButtonText = "取消";
            this.listenModeText = "側錄中，按下鍵盤按鍵來設定！";
            this.element = document.createElement("div");
            this.codeContainer = document.createElement("div");
            this.triggerButton = document.createElement("button");
            this.cancelButton = document.createElement("button");
            this._emptyKeycodeData = {
                keyCodes: [],
                withCtrl: false,
                withShift: false,
                withAlt: false
            };
            this._keyTextMap = {
                " ": "Space",
                "ArrowUp": "↑",
                "ArrowRight": "→",
                "ArrowDown": "↓",
                "ArrowLeft": "←",
            };
            this._setupMode = false;
            this._keyboardListenMode = false;
            this._listenStates = [];
            this.bindOptions(options);
            this._keycodeData = Object.assign({}, this._emptyKeycodeData);
            this._keycodeDataBackup = Object.assign({}, this._emptyKeycodeData);
        }
        static fromAsync(options) {
            return new KeycodeElement(options).buildAsync();
        }
        async buildElementAsync() {
            var _a, _b, _c, _d;
            this.element.className = "keycode-input";
            this.container.appendChild(this.element);
            this.codeContainer.className = "code-container";
            this.element.appendChild(this.codeContainer);
            this.triggerButton.className = "setup-button small-button";
            this.triggerButton.type = "button";
            this.triggerButton.title = (_a = this.triggerButtonText) !== null && _a !== void 0 ? _a : "設定";
            this.triggerButton.innerText = (_b = this.triggerButtonText) !== null && _b !== void 0 ? _b : "設定";
            this.triggerButton.disabled = this.disabled !== false;
            this.element.appendChild(this.triggerButton);
            this.cancelButton.className = "cancel-button small-button default";
            this.cancelButton.type = "button";
            this.cancelButton.title = (_c = this.cancelButtonText) !== null && _c !== void 0 ? _c : "取消";
            this.cancelButton.innerText = (_d = this.cancelButtonText) !== null && _d !== void 0 ? _d : "取消";
            this.cancelButton.style.display = "none";
            this.element.appendChild(this.cancelButton);
            this._onKeyDown = this._onKeyDown.bind(this);
            this._onKeyUp = this._onKeyUp.bind(this);
            this._bindEvents();
        }
        _bindEvents() {
            this.triggerButton.addEventListener("click", () => {
                this.setSetupModeAsync(!this._setupMode);
                this.triggerButton.blur();
            });
            this.cancelButton.addEventListener("click", () => {
                this._keycodeData = Object.assign({}, this._keycodeDataBackup);
                this.setSetupModeAsync(false);
                this.cancelButton.blur();
            });
        }
        _onKeyDown(keyboardEvent) {
            keyboardEvent.preventDefault();
            if (!this._keyboardListenMode) {
                this._keyboardListenMode = true;
                this._keycodeData = Object.assign({}, this._emptyKeycodeData);
                this._listenStates = [];
            }
            const matchs = this._listenStates.filter(o => o.key === keyboardEvent.key);
            if (matchs.length === 0) {
                this._listenStates.push({ key: keyboardEvent.key, keydown: true });
            }
            else {
                matchs[0].keydown = true;
            }
            this._updateKeycodeDataFromListenStates();
            this._updateCodeContainer();
        }
        _onKeyUp(keyboardEvent) {
            keyboardEvent.preventDefault();
            const matchs = this._listenStates.filter(o => o.key === keyboardEvent.key);
            if (matchs.length === 0) {
                this._listenStates.push({ key: keyboardEvent.key, keydown: false });
            }
            else {
                matchs[0].keydown = false;
            }
            if (this._listenStates.filter(o => o.keydown).length === 0) {
                this._keyboardListenMode = false;
            }
            this._updateKeycodeDataFromListenStates();
            this._updateCodeContainer();
        }
        _updateKeycodeDataFromListenStates() {
            const adoptedKeycodes = this._listenStates.filter(o => o.key !== "Control" && o.key !== "Shift" && o.key !== "Alt").map(o => o.key);
            this._keycodeData = {
                keyCodes: !this.multipleKey && adoptedKeycodes.length > 0 ? [adoptedKeycodes[0]] : adoptedKeycodes,
                withCtrl: this.allowCtrl !== false && this._listenStates.filter(o => o.key === "Control").length > 0,
                withShift: this.allowShift !== false && this._listenStates.filter(o => o.key === "Shift").length > 0,
                withAlt: this.allowAlt !== false && this._listenStates.filter(o => o.key === "Alt").length > 0
            };
        }
        _updateCodeContainer() {
            const keys = Object.keys(this._keyTextMap);
            const adoptedKeycodes = this._keycodeData.keyCodes.map(o => keys.indexOf(o) >= 0 ? this._keyTextMap[o] : o);
            this.codeContainer.innerHTML = adoptedKeycodes.length > 0 ?
                `${(this._keycodeData.withCtrl ? `<span class="key-code">Ctrl</span><span class="key-code-plus">+</span>` : "")}
            ${(this._keycodeData.withShift ? `<span class="key-code">Shift</span><span class="key-code-plus">+</span>` : "")}
            ${(this._keycodeData.withAlt ? `<span class="key-code">Alt</span><span class="key-code-plus">+</span>` : "")}
            ${adoptedKeycodes.map(o => `<span class="key-code">${o.length === 1 ? o.toUpperCase() : o}</span>`).join("")}` :
                (this._setupMode ? `<span class="placeholder">${this.listenModeText}</span>` : "");
        }
        async setSetupModeAsync(trigger) {
            var _a, _b;
            if (this._setupMode === trigger) {
                return;
            }
            this._setupMode = trigger;
            if (this._setupMode) {
                this.cancelButton.style.display = "";
                this.triggerButton.innerText = (_a = this.finishButtonText) !== null && _a !== void 0 ? _a : "完成";
                this.triggerButton.classList.add("primary");
                this._keycodeDataBackup = Object.assign({}, this._keycodeData);
                this._keycodeData = Object.assign({}, this._emptyKeycodeData);
                window.addEventListener("keydown", this._onKeyDown);
                window.addEventListener("keyup", this._onKeyUp);
            }
            else {
                this.cancelButton.style.display = "none";
                this.triggerButton.innerText = (_b = this.triggerButtonText) !== null && _b !== void 0 ? _b : "設定";
                this.triggerButton.classList.remove("primary");
                window.removeEventListener("keydown", this._onKeyDown);
                window.removeEventListener("keyup", this._onKeyUp);
                await this.changeAsync();
            }
            this._updateCodeContainer();
        }
        async rebuildAsync() { }
        async deleteAsync() {
            await this.setSetupModeAsync(false);
        }
        async validateAsync() {
            return this._keycodeData.keyCodes && this._keycodeData.keyCodes.length > 0;
        }
        async setDisableAsync(disable) {
            if (disable !== false) {
                await this.setSetupModeAsync(false);
            }
            this.triggerButton.disabled = this.disabled !== false;
        }
        async clearAsync() {
            this._keycodeData = Object.assign({}, this._emptyKeycodeData);
            this._updateCodeContainer();
        }
        async setValueAsync(value) {
            this._keycodeData = Object.assign({}, value);
            this._updateCodeContainer();
        }
        async getValueAsync() {
            return Object.assign({}, this._keycodeData);
        }
    }
    exports.default = KeycodeElement;
});
define("ReadonlyKeycodeElement", ["require", "exports", "uform-form"], function (require, exports, uform_form_2) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    class ReadonlyKeycodeElement extends uform_form_2.FormElementGeneric {
        constructor(options) {
            super(options);
            this.element = document.createElement("div");
            this.codeContainer = document.createElement("div");
            this._emptyKeycodeData = {
                keyCodes: [],
                withCtrl: false,
                withShift: false,
                withAlt: false
            };
            this._keyTextMap = {
                " ": "Space",
                "ArrowUp": "↑",
                "ArrowRight": "→",
                "ArrowDown": "↓",
                "ArrowLeft": "←",
            };
            this.bindOptions(options);
            this._keycodeData = Object.assign({}, this._emptyKeycodeData);
        }
        static fromAsync(options) {
            return new ReadonlyKeycodeElement(options).buildAsync();
        }
        async buildElementAsync() {
            this.element.className = "keycode-input readonly-keycode-input";
            this.container.appendChild(this.element);
            this.codeContainer.className = "code-container";
            this.element.appendChild(this.codeContainer);
        }
        _updateCodeContainer() {
            const keys = Object.keys(this._keyTextMap);
            const adoptedKeycodes = this._keycodeData.keyCodes.map(o => keys.indexOf(o) >= 0 ? this._keyTextMap[o] : o);
            this.codeContainer.innerHTML = adoptedKeycodes.length > 0 ?
                `${(this._keycodeData.withCtrl ? `<span class="key-code">Ctrl</span><span class="key-code-plus">+</span>` : "")}
            ${(this._keycodeData.withShift ? `<span class="key-code">Shift</span><span class="key-code-plus">+</span>` : "")}
            ${(this._keycodeData.withAlt ? `<span class="key-code">Alt</span><span class="key-code-plus">+</span>` : "")}
            ${adoptedKeycodes.map(o => `<span class="key-code">${o.toUpperCase()}</span>`).join("")}` :
                "";
        }
        async rebuildAsync() { }
        async deleteAsync() { }
        async validateAsync() {
            return this._keycodeData.keyCodes && this._keycodeData.keyCodes.length > 0;
        }
        async setDisableAsync(disable) { }
        async clearAsync() {
            this._keycodeData = Object.assign({}, this._emptyKeycodeData);
            this._updateCodeContainer();
        }
        async setValueAsync(value) {
            this._keycodeData = Object.assign({}, value);
            this._updateCodeContainer();
        }
        async getValueAsync() {
            return Object.assign({}, this._keycodeData);
        }
    }
    exports.default = ReadonlyKeycodeElement;
});
define("test", ["require", "exports", "uform-form", "KeycodeElement", "ReadonlyKeycodeElement"], function (require, exports, uform_form_3, KeycodeElement_1, ReadonlyKeycodeElement_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    async function testAsync() {
        const target = document.getElementById("test-form-0");
        if (target) {
            const form = new TestForm(target);
            await form.buildAsync();
        }
    }
    class TestForm extends uform_form_3.Form {
        async buildChildrenAsync() {
            const keycodeInput = await KeycodeElement_1.default.fromAsync({
                multipleKey: true,
                label: "鍵盤按鍵",
                disabled: false,
                allowShift: false
            });
            await this.appendAsync(keycodeInput);
            const readonlyKeycodeInput = await ReadonlyKeycodeElement_1.default.fromAsync({
                label: "唯讀"
            });
            await this.appendAsync(readonlyKeycodeInput);
            keycodeInput.addChangeFunc(async () => {
                const value = await keycodeInput.getValueAsync();
                readonlyKeycodeInput.setValueAsync(value);
            });
        }
    }
    testAsync();
});
define("uform-form-keycode", ["require", "exports", "KeycodeElement", "ReadonlyKeycodeElement"], function (require, exports, KeycodeElement_2, ReadonlyKeycodeElement_2) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.ReadonlyKeycodeElement = exports.KeycodeElement = void 0;
    exports.KeycodeElement = KeycodeElement_2.default;
    exports.ReadonlyKeycodeElement = ReadonlyKeycodeElement_2.default;
});
//# sourceMappingURL=test.js.map