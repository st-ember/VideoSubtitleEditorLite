﻿declare module "KeycodeData" {
    export default interface KeycodeData {
        keyCodes: string[];
        withCtrl: boolean;
        withShift: boolean;
        withAlt: boolean;
    }
}
declare module "KeycodeElementOptions" {
    import { FormElementOptions } from "uform-form";
    export default interface KeycodeElementOptions extends FormElementOptions {
        multipleKey?: boolean;
        allowCtrl?: boolean;
        allowShift?: boolean;
        allowAlt?: boolean;
        triggerButtonText?: string;
        finishButtonText?: string;
        cancelButtonText?: string;
        listenModeText?: string;
    }
}
declare module "KeycodeElement" {
    import { FormElementGeneric } from "uform-form";
    import KeycodeData from "KeycodeData";
    import KeycodeElementOptions from "KeycodeElementOptions";
    export default class KeycodeElement extends FormElementGeneric<KeycodeData> implements KeycodeElementOptions {
        multipleKey?: boolean;
        allowCtrl?: boolean;
        allowShift?: boolean;
        allowAlt?: boolean;
        triggerButtonText?: string;
        finishButtonText?: string;
        cancelButtonText?: string;
        listenModeText?: string;
        element: HTMLElement;
        codeContainer: HTMLElement;
        triggerButton: HTMLButtonElement;
        cancelButton: HTMLButtonElement;
        private _emptyKeycodeData;
        private _keyTextMap;
        private _keycodeData;
        private _keycodeDataBackup;
        private _setupMode;
        private _keyboardListenMode;
        private _listenStates;
        constructor(options?: KeycodeElementOptions);
        static fromAsync(options?: KeycodeElementOptions): Promise<KeycodeElement>;
        protected buildElementAsync(): Promise<void>;
        private _bindEvents;
        private _onKeyDown;
        private _onKeyUp;
        private _updateKeycodeDataFromListenStates;
        private _updateCodeContainer;
        setSetupModeAsync(trigger: boolean): Promise<void>;
        rebuildAsync(): Promise<void>;
        deleteAsync(): Promise<void>;
        validateAsync(): Promise<boolean>;
        setDisableAsync(disable?: boolean | undefined): Promise<void>;
        clearAsync(): Promise<void>;
        setValueAsync(value: KeycodeData): Promise<void>;
        getValueAsync(): Promise<KeycodeData>;
    }
}
declare module "ReadonlyKeycodeElement" {
    import { FormElementGeneric, FormElementOptions } from "uform-form";
    import KeycodeData from "KeycodeData";
    export default class ReadonlyKeycodeElement extends FormElementGeneric<KeycodeData> implements FormElementOptions {
        element: HTMLElement;
        codeContainer: HTMLElement;
        private _emptyKeycodeData;
        private _keyTextMap;
        private _keycodeData;
        constructor(options?: FormElementOptions);
        static fromAsync(options?: FormElementOptions): Promise<ReadonlyKeycodeElement>;
        protected buildElementAsync(): Promise<void>;
        private _updateCodeContainer;
        rebuildAsync(): Promise<void>;
        deleteAsync(): Promise<void>;
        validateAsync(): Promise<boolean>;
        setDisableAsync(disable?: boolean | undefined): Promise<void>;
        clearAsync(): Promise<void>;
        setValueAsync(value: KeycodeData): Promise<void>;
        getValueAsync(): Promise<KeycodeData>;
    }
}
declare module "test" { }
declare module "uform-form-keycode" {
    import KeycodeData from "KeycodeData";
    import KeycodeElement from "KeycodeElement";
    import ReadonlyKeycodeElement from "ReadonlyKeycodeElement";
    import KeycodeElementOptions from "KeycodeElementOptions";
    export { KeycodeData, KeycodeElement, ReadonlyKeycodeElement, KeycodeElementOptions };
}
