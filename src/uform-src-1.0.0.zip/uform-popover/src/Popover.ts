import PopoverOptions from "PopoverOptions";
import dropdownController, { Dropdown } from "uform-dropdown";
import Utility from "uform-utility";

export default class Popover {

    id: number;
    options: PopoverOptions;

    target: HTMLElement;
    dropdown?: Dropdown;
    title?: HTMLDivElement;
    content: HTMLDivElement = document.createElement("div");

    private _mouseOnTarget: boolean = false;
    private _mouseInDropdown: boolean = false;

    onShowFuncs: (() => void)[] = [];
    onHideFuncs: (() => void)[] = [];

    constructor(options: PopoverOptions, id: number) {
        this.id = id;
        this.options = options;
        this.target = options.target;
        this._updateOptions();
    }

    init(): void {
        this._initDropdown();
        this._initElement();
        this._initHooks();
    }

    private _updateOptions(): void {
        if (this.target.hasAttribute("data-title")) {
            this.options.title = this.target.getAttribute("data-title")!;
        }

        if (this.target.hasAttribute("data-content")) {
            this.options.content = this.target.getAttribute("data-content")!;
        }

        if (this.target.hasAttribute("data-only-trigger-by-click")) {
            this.options.onlyTriggerByClick = this.target.getAttribute("data-only-trigger-by-click")!.toLowerCase() === "true";
        }

        if (this.target.hasAttribute("data-width")) {
            const width = this.target.getAttribute("data-width") ?? "";
            this.options.width = !isNaN(Number(width)) ? Number(width) : width;
        }

        if (this.options.content === undefined || this.options.content === null) {
            this.options.content = "";
        }

        if (this.options.onlyTriggerByClick === undefined || this.options.onlyTriggerByClick === null) {
            this.options.onlyTriggerByClick = false;
        }
    }

    private _initDropdown(): void {
        if (!this.dropdown) {
            this.dropdown = dropdownController.add({
                tag: "popover",
                container: this.options.container, 
                target: this.options.target,
                paddingTop: 0,
                paddingBottom: 0,
                showArrow: true
            });

            this.dropdown.frame.classList.add("popover-dropdown-frame");
        }
    }

    private _initElement(): void {
        if (!this.dropdown) {
            return;
        }

        if (this.options.title !== undefined && this.options.title !== null) {
            const titleElem = document.createElement("div");
            titleElem.className = "popover-title";
            this.dropdown.head?.appendChild(titleElem);
            this.title = titleElem;

            if (typeof this.options.title === "string") {
                this.title.innerHTML = this.options.title;
            } else {
                this.title.appendChild(this.options.title);
            }

            this.dropdown.element.classList.add("popover-with-head");
        } else {
            if (this.dropdown.head) {
                this.dropdown.head.style.display = "none";
            }
            
            this.dropdown.element.classList.add("popover-without-head");
        }

        this.content.className = "popover-content";
        this.dropdown.body?.appendChild(this.content);

        if (typeof this.options.content === "string") {
            this.content.innerHTML = this.options.content;
        } else if (this.options.content) {
            this.content.appendChild(this.options.content);
        }

        this.dropdown.bottom.style.display = "none";
    }

    private _initHooks(): void {
        if (!this.options.onlyTriggerByClick) {
            this._onMouseEnterTarget = this._onMouseEnterTarget.bind(this);
            this._onMouseLeaveTarget = this._onMouseLeaveTarget.bind(this);
            this.target.addEventListener("mouseenter", this._onMouseEnterTarget);
            this.target.addEventListener("mouseleave", this._onMouseLeaveTarget);

            this.dropdown?.onMouseEnterFuncs.push(() => this._onMouseEnter());
            this.dropdown?.onMouseLeaveFuncs.push(() => this._onMouseLeave());
        }
    }

    async updateAsync(): Promise<void> {
        if (this.options.width && this.options.width !== "auto") {
            this.content.style.width = typeof this.options.width === "number" ? `${this.options.width}px` : this.options.width;
        } else {
            this.content.style.position = "absolute";
            this.content.style.whiteSpace = "nowrap";
            this.content.style.width = "";
    
            const currentWidth = this.content.clientWidth;
            this.content.style.width = currentWidth > 300 ? "300px" : `${currentWidth + 1}px`;

            this.content.style.position = "";
            this.content.style.whiteSpace = "";
        }
    }

    async setTitleAsync(title?: string | HTMLElement): Promise<void> {
        this.options.title = title;

        if (this.options.title !== undefined && this.options.title !== null) {
            if (!this.title) {
                const titleElem = document.createElement("div");
                titleElem.className = "popover-title";
                this.title = titleElem;

                if (this.dropdown) {
                    this.dropdown.head.appendChild(titleElem);
                    this.dropdown.element.classList.remove("popover-without-head");
                    this.dropdown.element.classList.add("popover-with-head");
                }
            }

            if (typeof this.options.title === "string") {
                this.title.innerHTML = this.options.title;
            } else {
                this.title.innerHTML = "";
                this.title.appendChild(this.options.title);
            }
        } else {
            if (this.dropdown) {
                this.dropdown.head.style.display = "none";
                this.dropdown.element.classList.remove("popover-with-head");
                this.dropdown.element.classList.add("popover-without-head");
            }

            if (this.title) {
                this.title.remove();
            }
        }

        await this.updateAsync();
    }

    async setContentAsync(content?: string | HTMLElement): Promise<void> {
        this.options.content = content !== undefined && content !== null ? content : "";
        if (typeof this.options.content === "string") {
            this.content.innerHTML = this.options.content;
        } else {
            this.content.innerHTML = "";
            this.content.appendChild(this.options.content);
        }

        await this.updateAsync();
    }

    async removeAsync(): Promise<void> {
        if (!this.options.onlyTriggerByClick) {
            this.target.removeEventListener("mouseenter", this._onMouseEnterTarget);
            this.target.removeEventListener("mouseleave", this._onMouseLeaveTarget);
        }

        await this.dropdown?.removeAsync();
    }

    async openAsync(): Promise<void> {
        await this.dropdown?.openAsync(true);
    }

    async closeAsync(): Promise<void> {
        await this.dropdown?.openAsync(false);
    }

    private _onMouseEnterTarget(): void {
        this._mouseOnTarget = true;
        if (this.dropdown && !this.dropdown.opened) {
            this.dropdown.frame.style.zIndex = "1000";
            this.dropdown.openAsync(true);
            Utility.wait(200).then(() => {
                if (this.dropdown) {
                    this.dropdown.frame.style.zIndex = "";
                }
            });
        }
    }

    private _onMouseLeaveTarget(): void {
        this._mouseOnTarget = false;
        setTimeout(async () => {
            if (this.dropdown && this.dropdown.opened && !this._mouseInDropdown && !this._mouseOnTarget) {
                this.dropdown.frame.classList.add("fade-out");
                await Utility.wait(200);
                this.dropdown.openAsync(false);
                this.dropdown.frame.classList.remove("fade-out");
            }
        }, 200);
    }

    private _onMouseEnter(): void {
        this._mouseInDropdown = true;
    }

    private _onMouseLeave(): void {
        this._mouseInDropdown = false;

        setTimeout(async () => {
            if (this.dropdown && this.dropdown.opened && !this._mouseOnTarget) {
                this.dropdown.frame.classList.add("fade-out");
                await Utility.wait(200);
                this.dropdown.openAsync(false);
                this.dropdown.frame.classList.remove("fade-out");
            }
        }, 200);
    }
}