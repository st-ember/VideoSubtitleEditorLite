import Popover from "Popover";
import PopoverOptions from "PopoverOptions";

export default class PopoverController {
    private _currentId: number = 0;

    private _popovers: { [id: string]: Popover } = {};

    private _getNewId(): number {
        return this._currentId++;
    }

    async scanAsync(): Promise<HTMLElement[]> {
        const selectElements: HTMLElement[] = [];
        const matchs = document.querySelectorAll(".popover");
        for (let i = 0; i < matchs.length; i++) {
            selectElements.push(<HTMLElement>(matchs.item(i)));
        }

        return selectElements;
    }

    async scanAndBuildAsync(): Promise<Popover[]> {
        const elements = await this.scanAsync();
        return this.buildAsync(elements);
    }

    get(id: number): Popover;
    get(element: HTMLElement): Popover;
    get(arg0: number | HTMLElement): Popover | undefined {
        if (typeof arg0 === "number") {
            return this._popovers[String(arg0)];
        } else {
            const ids = Object.keys(this._popovers);
            for (let i = 0; i < ids.length; i++) {
                if (this._popovers[ids[i]].target.isSameNode(arg0)) {
                    return this._popovers[i];
                }
            }
        }
    }

    list(): Popover[];
    list(id: number): Popover[];
    list(element: HTMLElement): Popover[];
    list(idOrElements: (number | HTMLElement)[]): Popover[];
    list(arg0?: number | HTMLElement | (number | HTMLElement)[]): Popover[] {
        if (!arg0) {
            return Object.keys(this._popovers).map(id => this._popovers[id]);
        } else if (typeof arg0 === "number") {
            return [this._popovers[String(arg0)]].filter(popover => !!popover);
        } else if (Array.isArray(arg0)) {
            return arg0
                .map(item => {
                    if (typeof item === "number") {
                        return this._popovers[String(item)];
                    } else {
                        return this.get(item);
                    }
                })
                .filter(popover => !!popover);
        } else {
            const popovers: Popover[] = [];
            const ids = Object.keys(this._popovers);
            for (let i = 0; i < ids.length; i++) {
                if (this._popovers[i].target.isSameNode(arg0)) {
                    popovers.push(this._popovers[i]);
                }
            }

            return popovers;
        }
    }

    buildAsync(options: PopoverOptions): Promise<Popover[]>;
    buildAsync(element: HTMLElement): Promise<Popover[]>;
    buildAsync(elements: HTMLElement[]): Promise<Popover[]>;
    async buildAsync(arg0: PopoverOptions | HTMLElement | HTMLElement[]): Promise<Popover[]> {
        if ("target" in arg0) {
            if (!arg0.target) {
                return [];
            }

            const exists = this.get(arg0.target);
            if (exists) {
                return [exists];
            }

            const id = this._getNewId();
            const popover = new Popover(arg0, id);
            popover.init();
            await popover.updateAsync();
            this._popovers[String(id)] = popover;

            return [popover];
        } else {
            const popovers: Popover[] = [];
            const elements = Array.isArray(arg0) ? arg0 : [arg0];
            for (let i = 0; i < elements.length; i++) {
                if (!elements[i]) {
                    continue;
                }

                const exists = this.get(elements[i]);
                if (exists) {
                    popovers.push(exists);
                    continue;
                }

                const id = this._getNewId();
                const popover = new Popover({ target: elements[i] }, id);
                popover.init();
                await popover.updateAsync();
                this._popovers[String(id)] = popover;

                popovers.push(popover);
            }

            return popovers;
        }
    }

    updateAsync(): Promise<void>;
    updateAsync(id: number): Promise<void>;
    updateAsync(element: HTMLElement): Promise<void>;
    updateAsync(idOrElements: (number | HTMLElement)[]): Promise<void>;
    async updateAsync(arg0?: number | HTMLElement | (number | HTMLElement)[]): Promise<void> {
        await Promise.all(this.list(<any>arg0).map(popover => popover.updateAsync()));
    }

    rebuildAsync(): Promise<void>;
    rebuildAsync(id: number): Promise<void>;
    rebuildAsync(element: HTMLElement): Promise<void>;
    rebuildAsync(idOrElements: (number | HTMLElement)[]): Promise<void>;
    async rebuildAsync(arg0?: number | HTMLElement | (number | HTMLElement)[]): Promise<void> {
        await Promise.all(this.list(<any>arg0).map(async popover => {
            const id = popover.id;
            const options = { ...popover.options };
            await popover.removeAsync();

            const newPopover = new Popover(options, id);
            newPopover.init();
        }));
    }

    removeAsync(): Promise<void>;
    removeAsync(id: number): Promise<void>;
    removeAsync(element: HTMLElement): Promise<void>;
    removeAsync(idOrElements: (number | HTMLElement)[]): Promise<void>;
    async removeAsync(arg0?: number | HTMLElement | (number | HTMLElement)[]): Promise<void> {
        await Promise.all(this.list(<any>arg0).map(async popover => {
            const id = popover.id;
            await popover.removeAsync();
            delete this._popovers[id];
        }));
    }

    async closeAllAsync(): Promise<void> {
        await Promise.all(Object.keys(this._popovers).map(id => this._popovers[id].closeAsync()));
    }
}

export const popoverController = new PopoverController();
(<any>window).popoverController = popoverController;
popoverController.scanAndBuildAsync();