
export default interface PopoverOptions {
    container?: HTMLElement;
    target: HTMLElement;
    title?: HTMLElement | string;
    content?: HTMLElement | string;
    onlyTriggerByClick?: boolean;
    width?: number | string;
}