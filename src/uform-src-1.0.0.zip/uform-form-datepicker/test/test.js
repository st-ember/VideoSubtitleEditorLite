﻿define("options/DateElementOptions", ["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
});
define("DateElement", ["require", "exports", "uform-datepicker", "uform-form"], function (require, exports, uform_datepicker_1, uform_form_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    class DateElement extends uform_form_1.FormElementGeneric {
        constructor(options) {
            super(options);
            this.allowEmpty = true;
            this.mode = "date";
            this.format = "yyyy/MM/dd";
            this.element = document.createElement("input");
            this.bindOptions(options);
        }
        static fromAsync(options) {
            return (new DateElement(options).buildAsync());
        }
        async buildElementAsync() {
            if (this.name) {
                this.element.name = this.name;
            }
            if (this.label) {
                this.element.title = this.label;
            }
            this.element.id = this.id;
            this.element.type = "text";
            this.element.autocomplete = "off";
            this.container.appendChild(this.element);
            this.messageAnchor = this.element;
            const addon = document.createElement("label");
            addon.setAttribute("for", this.id);
            addon.className = "date-input-addon";
            this.container.appendChild(addon);
            await this.buildDateInput();
        }
        async buildDateInput() {
            const datepickers = await uform_datepicker_1.default.buildAsync({
                input: this.element,
                mode: this.mode,
                format: this.format,
                allowEmpty: this.allowEmpty,
                showClearButton: this.allowEmpty,
                showTodayButton: true,
                startYear: this.startYear,
                endYear: this.endYear,
                yearFormater: this.yearFormater,
                dateParser: this.dateParser
            });
            this.datepicker = datepickers[0];
            this.datepicker.onChangeFuncs.push(async () => this.changeAsync());
        }
        async rebuildAsync() {
            if (this.datepicker) {
                await uform_datepicker_1.default.removeAsync(this.datepicker.id);
                this.datepicker = undefined;
            }
            await this.buildDateInput();
            await this.clearAsync();
        }
        async deleteAsync() {
            await this.removeMessageAsync();
            if (this.datepicker) {
                await uform_datepicker_1.default.removeAsync(this.datepicker.id);
                this.datepicker = undefined;
            }
            this.container.remove();
        }
        async validateAsync() {
            this.validated = true;
            const valid = !this.needToCheckRequire() || !!(await this.getValueAsync());
            await this.showInvalidEffectAsync(!valid, "此項目為必填！");
            return valid;
        }
        async setDisableAsync(disable) {
            var _a;
            this.disabled = disable !== false;
            await ((_a = this.datepicker) === null || _a === void 0 ? void 0 : _a.setDisableAsync(this.disabled));
        }
        async clearAsync() {
            var _a;
            await ((_a = this.datepicker) === null || _a === void 0 ? void 0 : _a.clearAsync());
        }
        async getValueAsync() {
            var _a;
            return (_a = this.datepicker) === null || _a === void 0 ? void 0 : _a.get();
        }
        async getDateValueAsync() {
            var _a;
            return (_a = this.datepicker) === null || _a === void 0 ? void 0 : _a.getDate();
        }
        async getNumberValueAsync() {
            var _a;
            return Number((_a = this.datepicker) === null || _a === void 0 ? void 0 : _a.getDate());
        }
        async setValueAsync(value) {
            var _a, _b;
            await (typeof value === "number" ? (_a = this.datepicker) === null || _a === void 0 ? void 0 : _a.setAsync(new Date(value)) : (_b = this.datepicker) === null || _b === void 0 ? void 0 : _b.setAsync(value));
        }
    }
    exports.default = DateElement;
});
define("models/DateRange", ["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
});
define("models/FormattedDateRange", ["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
});
define("models/NumberDateRange", ["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
});
define("options/DateRangeElementOptions", ["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
});
define("DateRangeElement", ["require", "exports", "uform-datepicker", "uform-form", "uform-utility"], function (require, exports, uform_datepicker_2, uform_form_2, uform_utility_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    class DateRangeElement extends uform_form_2.FormElementGeneric {
        constructor(options) {
            super(options);
            this.allowEmpty = true;
            this.mode = "date";
            this.format = "yyyy/MM/dd";
            this.textBetween = "到";
            this.element = undefined;
            this.startElement = undefined;
            this.endElement = undefined;
            this.bindOptions(options);
        }
        static fromAsync(options) {
            return (new DateRangeElement(options).buildAsync());
        }
        async buildElementAsync() {
            this.container.classList.add("date-range-container");
            const startElement = document.createElement("input");
            startElement.name = this.name + "-start";
            startElement.id = this.id + "-start";
            startElement.type = "text";
            startElement.className = "datepicker";
            this.element = startElement;
            this.startElement = startElement;
            this.container.appendChild(startElement);
            if (this.label) {
                this.startElement.title = this.label;
            }
            this.messageAnchor = this.startElement;
            const startLabel = document.createElement("label");
            startLabel.className = "date-input-addon";
            startLabel.setAttribute("for", startElement.id);
            this.container.appendChild(startLabel);
            const textElement = document.createElement("span");
            textElement.className = "form-text";
            textElement.innerHTML = this.textBetween;
            this.container.appendChild(textElement);
            const endElement = document.createElement("input");
            endElement.name = this.name + "-end";
            endElement.id = this.id + "-end";
            endElement.type = "text";
            endElement.className = "datepicker";
            this.endElement = endElement;
            this.container.appendChild(endElement);
            if (this.label) {
                this.endElement.title = this.label;
            }
            const endLabel = document.createElement("label");
            endLabel.className = "date-input-addon";
            endLabel.setAttribute("for", endElement.id);
            this.container.appendChild(endLabel);
        }
        async buildDateInputsAsync() {
            const range = await uform_datepicker_2.default.buildRangeAsync(this.startElement, this.endElement, {
                input: this.startElement,
                mode: this.mode,
                showTodayButton: true,
                allowEmpty: this.allowEmpty,
                showClearButton: this.allowEmpty,
                rangeEnd: "#" + this.id + "-end",
                startYear: this.startYear,
                endYear: this.endYear,
                yearFormater: this.yearFormater,
                dateParser: this.dateParser
            }, {
                input: this.endElement,
                mode: this.mode,
                showTodayButton: true,
                allowEmpty: this.allowEmpty,
                showClearButton: this.allowEmpty,
                rangeStart: "#" + this.id + "-start",
                startYear: this.startYear,
                endYear: this.endYear,
                yearFormater: this.yearFormater,
                dateParser: this.dateParser
            });
            if (range) {
                this.startDatepicker = range.start;
                this.endDatepicker = range.end;
                this.startDatepicker.onChangeFuncs.push(async () => this.changeAsync());
                this.endDatepicker.onChangeFuncs.push(async () => this.changeAsync());
            }
            else {
                console.error("failed to create date range");
            }
        }
        async onAppendAsync() {
            await this.buildDateInputsAsync();
        }
        async rebuildAsync() {
            this.state = 1;
            if (this.startDatepicker) {
                await uform_datepicker_2.default.removeAsync(this.startDatepicker.id);
                this.startDatepicker = undefined;
            }
            if (this.endDatepicker) {
                await uform_datepicker_2.default.removeAsync(this.endDatepicker.id);
                this.endDatepicker = undefined;
            }
            this.startElement.value = "";
            this.endElement.value = "";
            await this.buildDateInputsAsync();
            await this.clearAsync();
            this.state = 2;
        }
        async deleteAsync() {
            await this.removeMessageAsync();
            if (this.startDatepicker) {
                await uform_datepicker_2.default.removeAsync(this.startDatepicker.id);
                this.startDatepicker = undefined;
            }
            if (this.endDatepicker) {
                await uform_datepicker_2.default.removeAsync(this.endDatepicker.id);
                this.endDatepicker = undefined;
            }
            this.container.remove();
        }
        async validateAsync() {
            var _a, _b;
            this.validated = true;
            const valid = !this.needToCheckRequire() || !!((_a = this.startDatepicker) === null || _a === void 0 ? void 0 : _a.get()) && !!((_b = this.endDatepicker) === null || _b === void 0 ? void 0 : _b.get());
            await this.showInvalidEffectAsync(!valid, "您必須指定日期區間！");
            return valid;
        }
        async setDisableAsync(disable) {
            var _a, _b;
            this.disabled = disable !== false;
            await ((_a = this.startDatepicker) === null || _a === void 0 ? void 0 : _a.setDisableAsync(this.disabled));
            await ((_b = this.endDatepicker) === null || _b === void 0 ? void 0 : _b.setDisableAsync(this.disabled));
        }
        async clearAsync() {
            if (this.startDatepicker) {
                await this.startDatepicker.clearAsync();
            }
            if (this.endDatepicker) {
                await this.endDatepicker.clearAsync();
            }
        }
        async getValueAsync() {
            var _a, _b;
            await uform_utility_1.default.queueUntil(this, () => this.state === 2);
            return {
                start: (_a = this.startDatepicker) === null || _a === void 0 ? void 0 : _a.get(),
                end: (_b = this.endDatepicker) === null || _b === void 0 ? void 0 : _b.get()
            };
        }
        async getDateValueAsync() {
            var _a, _b;
            await uform_utility_1.default.queueUntil(this, () => this.state === 2);
            return {
                start: (_a = this.startDatepicker) === null || _a === void 0 ? void 0 : _a.getDate(),
                end: (_b = this.endDatepicker) === null || _b === void 0 ? void 0 : _b.getDate()
            };
        }
        async getNumberValueAsync() {
            await uform_utility_1.default.queueUntil(this, () => this.state === 2);
            return {
                start: this.startDatepicker ? Number(this.startDatepicker.getDate()) : undefined,
                end: this.endDatepicker ? Number(this.endDatepicker.getDate()) : undefined
            };
        }
        async setValueAsync(value) {
            var _a, _b, _c, _d;
            await uform_utility_1.default.queueUntil(this, () => this.state === 2);
            await this.clearAsync();
            if (value && value.start && value.end && (typeof value.start === "number" || typeof value.end === "number")) {
                await ((_a = this.startDatepicker) === null || _a === void 0 ? void 0 : _a.setAsync(new Date(value.start)));
                await ((_b = this.endDatepicker) === null || _b === void 0 ? void 0 : _b.setAsync(new Date(value.end)));
                return;
            }
            await ((_c = this.startDatepicker) === null || _c === void 0 ? void 0 : _c.setAsync(value === null || value === void 0 ? void 0 : value.start));
            await ((_d = this.endDatepicker) === null || _d === void 0 ? void 0 : _d.setAsync(value === null || value === void 0 ? void 0 : value.end));
        }
    }
    exports.default = DateRangeElement;
});
define("options/ReadonlyDateElementOption", ["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
});
define("ReadonlyDateElement", ["require", "exports", "uform-datepicker", "uform-form"], function (require, exports, uform_datepicker_3, uform_form_3) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    class ReadonlyDateElement extends uform_form_3.FormElementGeneric {
        constructor(options) {
            super(options);
            this.element = document.createElement("div");
            this.format = "yyyy/MM/dd";
            this.bindOptions(options);
        }
        static fromAsync(options) {
            return (new ReadonlyDateElement(options).buildAsync());
        }
        async buildElementAsync() {
            this.element.className = "readonly-input";
            this.element.id = this.id;
            this.container.appendChild(this.element);
            this.messageAnchor = this.element;
        }
        async rebuildAsync() {
            await this.clearAsync();
            this.element.remove();
            await this.buildElementAsync();
        }
        async deleteAsync() {
            this.container.remove();
        }
        async validateAsync() {
            this.validated = true;
            return true;
        }
        async setDisableAsync(disable) {
            this.disabled = disable !== false;
        }
        async clearAsync() {
            this.value = undefined;
            this.element.innerText = "";
        }
        async getValueAsync() {
            return this._getFormattedValue();
        }
        async setValueAsync(value) {
            let date;
            if (typeof value === "string" && this.dateParser) {
                date = this.dateParser(value);
            }
            else {
                date = !value ? undefined : typeof value === "string" || typeof value === "number" ? new Date(value) : value;
            }
            this.value = date;
            this.element.innerText = this._getFormattedValue();
            await this.changeAsync();
        }
        _getFormattedValue() {
            return this.value !== undefined ? uform_datepicker_3.default.format(this.value, this.format, this.yearFormater) : "";
        }
    }
    exports.default = ReadonlyDateElement;
});
define("options/ReadonlyDateRangeElementOptions", ["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
});
define("ReadonlyDateRangeElement", ["require", "exports", "uform-datepicker", "uform-form"], function (require, exports, uform_datepicker_4, uform_form_4) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    class ReadonlyDateRangeElement extends uform_form_4.FormElementGeneric {
        constructor(options) {
            super(options);
            this.element = document.createElement("div");
            this.format = "yyyy/MM/dd";
            this.textBetween = "到";
            this.bindOptions(options);
        }
        static fromAsync(options) {
            return (new ReadonlyDateRangeElement(options).buildAsync());
        }
        async buildElementAsync() {
            this.element.className = "readonly-input";
            this.element.id = this.id;
            this.container.appendChild(this.element);
            this.messageAnchor = this.element;
        }
        async rebuildAsync() {
            await this.clearAsync();
            this.element.remove();
            await this.buildElementAsync();
        }
        async deleteAsync() {
            this.container.remove();
        }
        async validateAsync() {
            this.validated = true;
            return true;
        }
        async setDisableAsync(disable) {
            this.disabled = disable !== false;
        }
        async clearAsync() {
            this.start = undefined;
            this.end = undefined;
            this.element.innerText = "";
        }
        async getValueAsync() {
            return this._getFormattedValue();
        }
        async setValueAsync(value) {
            let start;
            let end;
            if (value === undefined || value === null) {
                start = undefined;
                end = undefined;
            }
            else if (typeof value.start === "string" && typeof value.end === "string" && this.dateParser) {
                start = this.dateParser(value.start);
                end = this.dateParser(value.end);
            }
            else {
                start = typeof value.start === "string" || typeof value.start === "number" ? new Date(value.start) : value.start;
                end = typeof value.end === "string" || typeof value.end === "number" ? new Date(value.end) : value.end;
            }
            this.start = start;
            this.end = end;
            const formattedValue = this._getFormattedValue();
            this.element.innerText = `${formattedValue.start ? formattedValue.start : "-"}${this.textBetween ? ` ${this.textBetween} ` : ""}${formattedValue.end ? formattedValue.end : "-"}`;
            await this.changeAsync();
        }
        _getFormattedValue() {
            return {
                start: this.start ? uform_datepicker_4.default.format(this.start, this.format, this.yearFormater) : "",
                end: this.end ? uform_datepicker_4.default.format(this.end, this.format, this.yearFormater) : ""
            };
        }
    }
    exports.default = ReadonlyDateRangeElement;
});
define("test", ["require", "exports", "uform-form", "DateElement", "DateRangeElement", "ReadonlyDateElement", "ReadonlyDateRangeElement"], function (require, exports, uform_form_5, DateElement_1, DateRangeElement_1, ReadonlyDateElement_1, ReadonlyDateRangeElement_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    async function testAsync() {
        const target = document.getElementById("test-form-0");
        if (target) {
            const form = new TestForm(target);
            await form.buildAsync();
        }
    }
    class TestForm extends uform_form_5.Form {
        async buildChildrenAsync() {
            const dateInput = await DateElement_1.default.fromAsync({
                label: "日期",
                allowEmpty: false
            });
            await this.appendAsync(dateInput);
            const rangeInput = await DateRangeElement_1.default.fromAsync({
                label: "日期區間"
            });
            await this.appendAsync(rangeInput);
            const readonlyDateInput = await ReadonlyDateElement_1.default.fromAsync({
                label: "日期"
            });
            await this.appendAsync(readonlyDateInput);
            const readonlyRangeInput = await ReadonlyDateRangeElement_1.default.fromAsync({
                label: "日期區間"
            });
            await this.appendAsync(readonlyRangeInput);
            dateInput.addChangeFunc(async () => {
                const value = await dateInput.getValueAsync();
                await readonlyDateInput.setValueAsync(value);
            });
            rangeInput.addChangeFunc(async () => {
                const value = await rangeInput.getValueAsync();
                await readonlyRangeInput.setValueAsync(value);
            });
        }
    }
    testAsync();
});
define("uform-form-datepicker", ["require", "exports", "DateElement", "DateRangeElement", "ReadonlyDateElement", "ReadonlyDateRangeElement"], function (require, exports, DateElement_2, DateRangeElement_2, ReadonlyDateElement_2, ReadonlyDateRangeElement_2) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.ReadonlyDateRangeElement = exports.ReadonlyDateElement = exports.DateRangeElement = exports.DateElement = void 0;
    exports.DateElement = DateElement_2.default;
    exports.DateRangeElement = DateRangeElement_2.default;
    exports.ReadonlyDateElement = ReadonlyDateElement_2.default;
    exports.ReadonlyDateRangeElement = ReadonlyDateRangeElement_2.default;
});
//# sourceMappingURL=test.js.map