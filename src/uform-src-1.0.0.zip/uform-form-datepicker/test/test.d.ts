﻿declare module "options/DateElementOptions" {
    import { FormElementOptions } from "uform-form";
    export default interface DateElementOptions extends FormElementOptions {
        allowEmpty?: boolean;
        mode?: "date" | "week" | "weekend";
        format?: string;
        yearFormater?: (year: number) => string;
        dateParser?: (text: string) => Date;
    }
}
declare module "DateElement" {
    import DateElementOptions from "options/DateElementOptions";
    import { Datepicker } from "uform-datepicker";
    import { FormElementGeneric } from "uform-form";
    export default class DateElement extends FormElementGeneric<string | undefined> implements DateElementOptions {
        allowEmpty: boolean;
        mode: "date" | "week" | "weekend";
        format: string;
        startYear?: number | string;
        endYear?: number | string;
        yearFormater?: (year: number) => string;
        dateParser?: (text: string) => Date;
        element: HTMLInputElement;
        datepicker?: Datepicker;
        constructor(options?: DateElementOptions);
        static fromAsync(options: DateElementOptions): Promise<DateElement>;
        protected buildElementAsync(): Promise<void>;
        protected buildDateInput(): Promise<void>;
        rebuildAsync(): Promise<void>;
        deleteAsync(): Promise<void>;
        validateAsync(): Promise<boolean>;
        setDisableAsync(disable?: boolean): Promise<void>;
        clearAsync(): Promise<void>;
        getValueAsync(): Promise<string | undefined>;
        getDateValueAsync(): Promise<Date | undefined>;
        getNumberValueAsync(): Promise<number>;
        setValueAsync(value: number): Promise<void>;
        setValueAsync(value: Date): Promise<void>;
        setValueAsync(value: string): Promise<void>;
    }
}
declare module "models/DateRange" {
    export default interface DateRange {
        start?: Date;
        end?: Date;
    }
}
declare module "models/FormattedDateRange" {
    export default interface FormattedDateRange {
        start?: string;
        end?: string;
    }
}
declare module "models/NumberDateRange" {
    export default interface NumberDateRange {
        start?: number;
        end?: number;
    }
}
declare module "options/DateRangeElementOptions" {
    import DateElementOptions from "options/DateElementOptions";
    export default interface DateRangeElementOptions extends DateElementOptions {
        textBetween?: string;
        startYear?: number | string;
        endYear?: number | string;
    }
}
declare module "DateRangeElement" {
    import DateRange from "models/DateRange";
    import FormattedDateRange from "models/FormattedDateRange";
    import NumberDateRange from "models/NumberDateRange";
    import DateRangeElementOptions from "options/DateRangeElementOptions";
    import { Datepicker } from "uform-datepicker";
    import { FormElementGeneric } from "uform-form";
    export default class DateRangeElement extends FormElementGeneric<FormattedDateRange> implements DateRangeElementOptions {
        allowEmpty: boolean;
        mode: "date" | "week" | "weekend";
        format: string;
        textBetween: string;
        startYear?: number | string;
        endYear?: number | string;
        yearFormater?: (year: number) => string;
        dateParser?: (text: string) => Date;
        element: HTMLInputElement;
        startElement: HTMLInputElement;
        endElement: HTMLInputElement;
        startDatepicker?: Datepicker;
        endDatepicker?: Datepicker;
        constructor(options?: DateRangeElementOptions);
        static fromAsync(options: DateRangeElementOptions): Promise<DateRangeElement>;
        protected buildElementAsync(): Promise<void>;
        protected buildDateInputsAsync(): Promise<void>;
        onAppendAsync(): Promise<void>;
        rebuildAsync(): Promise<void>;
        deleteAsync(): Promise<void>;
        validateAsync(): Promise<boolean>;
        setDisableAsync(disable?: boolean): Promise<void>;
        clearAsync(): Promise<void>;
        getValueAsync(): Promise<FormattedDateRange>;
        getDateValueAsync(): Promise<DateRange>;
        getNumberValueAsync(): Promise<NumberDateRange>;
        setValueAsync(value: NumberDateRange): Promise<void>;
        setValueAsync(value: DateRange): Promise<void>;
        setValueAsync(value: FormattedDateRange): Promise<void>;
    }
}
declare module "options/ReadonlyDateElementOption" {
    import { FormElementOptions } from "uform-form";
    export default interface ReadonlyDateElementOptions extends FormElementOptions {
        format?: string;
        yearFormater?: (year: number) => string;
        dateParser?: (text: string) => Date;
    }
}
declare module "ReadonlyDateElement" {
    import ReadonlyDateElementOptions from "options/ReadonlyDateElementOption";
    import { FormElementGeneric } from "uform-form";
    export default class ReadonlyDateElement extends FormElementGeneric<string> implements ReadonlyDateElementOptions {
        element: HTMLDivElement;
        value?: Date;
        format: string;
        yearFormater?: (year: number) => string;
        dateParser?: (text: string) => Date;
        constructor(options?: ReadonlyDateElementOptions);
        static fromAsync(options: ReadonlyDateElementOptions): Promise<ReadonlyDateElement>;
        protected buildElementAsync(): Promise<void>;
        rebuildAsync(): Promise<void>;
        deleteAsync(): Promise<void>;
        validateAsync(): Promise<boolean>;
        setDisableAsync(disable?: boolean): Promise<void>;
        clearAsync(): Promise<void>;
        getValueAsync(): Promise<string>;
        setValueAsync(value: string | number | Date | undefined): Promise<void>;
        private _getFormattedValue;
    }
}
declare module "options/ReadonlyDateRangeElementOptions" {
    import ReadonlyDateElementOptions from "options/ReadonlyDateElementOption";
    export default interface ReadonlyDateRangeElementOptions extends ReadonlyDateElementOptions {
        textBetween?: string;
    }
}
declare module "ReadonlyDateRangeElement" {
    import DateRange from "models/DateRange";
    import FormattedDateRange from "models/FormattedDateRange";
    import NumberDateRange from "models/NumberDateRange";
    import ReadonlyDateRangeElementOptions from "options/ReadonlyDateRangeElementOptions";
    import { FormElementGeneric } from "uform-form";
    export default class ReadonlyDateRangeElement extends FormElementGeneric<FormattedDateRange> implements ReadonlyDateRangeElementOptions {
        element: HTMLDivElement;
        start?: Date;
        end?: Date;
        format: string;
        textBetween: string;
        yearFormater?: (year: number) => string;
        dateParser?: (text: string) => Date;
        constructor(options?: ReadonlyDateRangeElementOptions);
        static fromAsync(options: ReadonlyDateRangeElementOptions): Promise<ReadonlyDateRangeElement>;
        protected buildElementAsync(): Promise<void>;
        rebuildAsync(): Promise<void>;
        deleteAsync(): Promise<void>;
        validateAsync(): Promise<boolean>;
        setDisableAsync(disable?: boolean): Promise<void>;
        clearAsync(): Promise<void>;
        getValueAsync(): Promise<FormattedDateRange>;
        setValueAsync(value: NumberDateRange): Promise<void>;
        setValueAsync(value: DateRange): Promise<void>;
        setValueAsync(value: FormattedDateRange): Promise<void>;
        private _getFormattedValue;
    }
}
declare module "test" { }
declare module "uform-form-datepicker" {
    import DateElement from "DateElement";
    import DateRangeElement from "DateRangeElement";
    import ReadonlyDateElement from "ReadonlyDateElement";
    import ReadonlyDateRangeElement from "ReadonlyDateRangeElement";
    import DateRange from "models/DateRange";
    import FormattedDateRange from "models/FormattedDateRange";
    import NumberDateRange from "models/NumberDateRange";
    import DateElementOptions from "options/DateElementOptions";
    import DateRangeElementOptions from "options/DateRangeElementOptions";
    import ReadonlyDateElementOptions from "options/ReadonlyDateElementOption";
    import ReadonlyDateRangeElementOptions from "options/ReadonlyDateRangeElementOptions";
    export { DateElementOptions, DateRangeElementOptions, ReadonlyDateElementOptions, ReadonlyDateRangeElementOptions, DateElement, DateRangeElement, ReadonlyDateElement, ReadonlyDateRangeElement, DateRange, FormattedDateRange, NumberDateRange };
}
