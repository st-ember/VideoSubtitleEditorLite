import DateRange from "models/DateRange";
import FormattedDateRange from "models/FormattedDateRange";
import NumberDateRange from "models/NumberDateRange";
import ReadonlyDateRangeElementOptions from "options/ReadonlyDateRangeElementOptions";
import datepickerController from "uform-datepicker";
import { FormElementGeneric } from "uform-form";

export default class ReadonlyDateRangeElement extends FormElementGeneric<FormattedDateRange> implements ReadonlyDateRangeElementOptions {

    element: HTMLDivElement = document.createElement("div");

    start?: Date;
    end?: Date;

    format: string = "yyyy/MM/dd";
    textBetween: string = "到";
    yearFormater?: (year: number) => string;
    dateParser?: (text: string) => Date;
    
    constructor(options?: ReadonlyDateRangeElementOptions) {
        super(options);
        this.bindOptions(options);
    }

    static fromAsync(options: ReadonlyDateRangeElementOptions): Promise<ReadonlyDateRangeElement> {
        return <Promise<ReadonlyDateRangeElement>>(new ReadonlyDateRangeElement(options).buildAsync());
    }

    protected async buildElementAsync(): Promise<void> {
        this.element.className = "readonly-input";
        this.element.id = this.id;
        this.container.appendChild(this.element);

        this.messageAnchor = this.element;
    }

    async rebuildAsync(): Promise<void> {
        await this.clearAsync();
        this.element.remove();
        await this.buildElementAsync();
    }

    async deleteAsync(): Promise<void> {
        this.container.remove();
    }

    async validateAsync(): Promise<boolean> {
        this.validated = true;
        return true;
    }

    async setDisableAsync(disable?: boolean): Promise<void> {
        this.disabled = disable !== false;
    }

    async clearAsync(): Promise<void> {
        this.start = undefined;
        this.end = undefined;
        this.element.innerText = "";
    }

    async getValueAsync(): Promise<FormattedDateRange> {
        return this._getFormattedValue();
    }

    async setValueAsync(value: NumberDateRange): Promise<void>;
    async setValueAsync(value: DateRange): Promise<void>;
    async setValueAsync(value: FormattedDateRange): Promise<void>;
    async setValueAsync(value: NumberDateRange | DateRange | FormattedDateRange | undefined): Promise<void> {
        let start: Date | undefined;
        let end: Date | undefined;
        if (value === undefined || value === null) {
            start = undefined;
            end = undefined;
        } else if (typeof value.start === "string" && typeof value.end === "string" && this.dateParser) {
            start = this.dateParser(value.start);
            end = this.dateParser(value.end);
        } else {
            start = typeof value.start === "string" || typeof value.start === "number" ? new Date(value.start) : value.start;
            end = typeof value.end === "string" || typeof value.end === "number" ? new Date(value.end) : value.end;
        }

        this.start = start;
        this.end = end;

        const formattedValue = this._getFormattedValue();
        this.element.innerText = `${formattedValue.start ? formattedValue.start : "-"}${this.textBetween ? ` ${this.textBetween} ` : ""}${formattedValue.end ? formattedValue.end : "-"}`;
        
        await this.changeAsync();
    }

    private _getFormattedValue(): FormattedDateRange {
        return {
            start: this.start ? datepickerController.format(this.start, this.format, this.yearFormater) : "",
            end: this.end ? datepickerController.format(this.end, this.format, this.yearFormater) : ""
        };
    }
}