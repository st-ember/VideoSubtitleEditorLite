import DateRange from "models/DateRange";
import FormattedDateRange from "models/FormattedDateRange";
import NumberDateRange from "models/NumberDateRange";
import DateRangeElementOptions from "options/DateRangeElementOptions";
import datepickerController, { Datepicker } from "uform-datepicker";
import { FormElementGeneric } from "uform-form";
import Utility from "uform-utility";

export default class DateRangeElement extends FormElementGeneric<FormattedDateRange> implements DateRangeElementOptions {

    allowEmpty: boolean = true;
    mode: "date" | "week" | "weekend" = "date";
    format: string = "yyyy/MM/dd";
    textBetween: string = "到";
    startYear?: number | string;
    endYear?: number | string;
    yearFormater?: (year: number) => string;
    dateParser?: (text: string) => Date;

    element: HTMLInputElement = undefined!;
    startElement: HTMLInputElement = undefined!;
    endElement: HTMLInputElement = undefined!;

    startDatepicker?: Datepicker;
    endDatepicker?: Datepicker;
    
    constructor(options?: DateRangeElementOptions) {
        super(options);
        this.bindOptions(options);
    }

    static fromAsync(options: DateRangeElementOptions): Promise<DateRangeElement> {
        return <Promise<DateRangeElement>>(new DateRangeElement(options).buildAsync());
    }

    protected async buildElementAsync(): Promise<void> {
        this.container.classList.add("date-range-container");

        const startElement = document.createElement("input");
        startElement.name = this.name + "-start";
        startElement.id = this.id + "-start";
        startElement.type = "text";
        startElement.className = "datepicker";
        this.element = startElement;
        this.startElement = startElement;
        this.container.appendChild(startElement);

        if (this.label) {
            this.startElement.title = this.label;
        }

        this.messageAnchor = this.startElement;

        const startLabel = document.createElement("label");
        startLabel.className = "date-input-addon";
        startLabel.setAttribute("for", startElement.id);
        this.container.appendChild(startLabel);

        const textElement = document.createElement("span");
        textElement.className = "form-text";
        textElement.innerHTML = this.textBetween;
        this.container.appendChild(textElement);

        const endElement = document.createElement("input");
        endElement.name = this.name + "-end";
        endElement.id = this.id + "-end";
        endElement.type = "text";
        endElement.className = "datepicker";
        this.endElement = endElement;
        this.container.appendChild(endElement);

        if (this.label) {
            this.endElement.title = this.label;
        }

        const endLabel = document.createElement("label");
        endLabel.className = "date-input-addon";
        endLabel.setAttribute("for", endElement.id);
        this.container.appendChild(endLabel);
    }

    protected async buildDateInputsAsync(): Promise<void> {
        const range = await datepickerController.buildRangeAsync(
            this.startElement, this.endElement,
            {
                input: this.startElement,
                mode: this.mode,
                showTodayButton: true,
                allowEmpty: this.allowEmpty,
                showClearButton: this.allowEmpty,
                rangeEnd: "#" + this.id + "-end",
                startYear: this.startYear,
                endYear: this.endYear,
                yearFormater: this.yearFormater,
                dateParser: this.dateParser
            },
            {
                input: this.endElement,
                mode: this.mode,
                showTodayButton: true,
                allowEmpty: this.allowEmpty,
                showClearButton: this.allowEmpty,
                rangeStart: "#" + this.id + "-start",
                startYear: this.startYear,
                endYear: this.endYear,
                yearFormater: this.yearFormater,
                dateParser: this.dateParser
            });
            
        if (range) {
            this.startDatepicker = range.start;
            this.endDatepicker = range.end;
    
            this.startDatepicker.onChangeFuncs.push(async () => this.changeAsync());
            this.endDatepicker.onChangeFuncs.push(async () => this.changeAsync());
        } else {
            console.error("failed to create date range");
        }
    }

    async onAppendAsync(): Promise<void> {
        await this.buildDateInputsAsync();
    }

    async rebuildAsync(): Promise<void> {
        this.state = 1;

        if (this.startDatepicker) {
            await datepickerController.removeAsync(this.startDatepicker.id);
            this.startDatepicker = undefined;
        }

        if (this.endDatepicker) {
            await datepickerController.removeAsync(this.endDatepicker.id);
            this.endDatepicker = undefined;
        }
        
        this.startElement.value = "";
        this.endElement.value = "";
        await this.buildDateInputsAsync();
        await this.clearAsync();
        this.state = 2;
    }

    async deleteAsync(): Promise<void> {
        await this.removeMessageAsync();

        if (this.startDatepicker) {
            await datepickerController.removeAsync(this.startDatepicker.id);
            this.startDatepicker = undefined;
        }

        if (this.endDatepicker) {
            await datepickerController.removeAsync(this.endDatepicker.id);
            this.endDatepicker = undefined;
        }

        this.container.remove();
    }

    async validateAsync(): Promise<boolean> {
        this.validated = true;
        const valid = !this.needToCheckRequire() || !!this.startDatepicker?.get() && !!this.endDatepicker?.get();
        await this.showInvalidEffectAsync(!valid, "您必須指定日期區間！");
        return valid;
    }

    async setDisableAsync(disable?: boolean): Promise<void> {
        this.disabled = disable !== false;
        await this.startDatepicker?.setDisableAsync(this.disabled);
        await this.endDatepicker?.setDisableAsync(this.disabled);
    }

    async clearAsync(): Promise<void> {
        if (this.startDatepicker) {
            await this.startDatepicker.clearAsync();
        }
        
        if (this.endDatepicker) {
            await this.endDatepicker.clearAsync();
        }
    }

    async getValueAsync(): Promise<FormattedDateRange> {
        await Utility.queueUntil(this, () => this.state === 2);
        return {
            start: this.startDatepicker?.get(),
            end: this.endDatepicker?.get()
        };
    }

    async getDateValueAsync(): Promise<DateRange> {
        await Utility.queueUntil(this, () => this.state === 2);
        return {
            start: this.startDatepicker?.getDate(),
            end: this.endDatepicker?.getDate()
        };
    }

    async getNumberValueAsync(): Promise<NumberDateRange> {
        await Utility.queueUntil(this, () => this.state === 2);
        return {
            start: this.startDatepicker ? Number(this.startDatepicker.getDate()) : undefined,
            end: this.endDatepicker ? Number(this.endDatepicker.getDate()) : undefined
        };
    }

    async setValueAsync(value: NumberDateRange): Promise<void>;
    async setValueAsync(value: DateRange): Promise<void>;
    async setValueAsync(value: FormattedDateRange): Promise<void>;
    async setValueAsync(value: NumberDateRange | DateRange | FormattedDateRange | undefined): Promise<void> {
        // 如果在物件重建到一半時設定值會導致錯誤，所以需要透過佇列來延遲操作。
        await Utility.queueUntil(this, () => this.state === 2);

        await this.clearAsync();
        if (value && value.start && value.end && (typeof value.start === "number" || typeof value.end === "number")) {
            await this.startDatepicker?.setAsync(new Date(value.start!));
            await this.endDatepicker?.setAsync(new Date(value.end));
            return;
        }

        await this.startDatepicker?.setAsync(<any>value?.start);
        await this.endDatepicker?.setAsync(<any>value?.end);
    }
}