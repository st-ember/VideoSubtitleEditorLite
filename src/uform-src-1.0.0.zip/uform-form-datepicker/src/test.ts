import { Form, InputElement } from "uform-form";
import DateElement from "./DateElement";
import DateRangeElement from "./DateRangeElement";
import ReadonlyDateElement from "./ReadonlyDateElement";
import ReadonlyDateRangeElement from "./ReadonlyDateRangeElement"

async function testAsync(): Promise<void> {
    const target = document.getElementById("test-form-0");
    if (target) {
        const form = new TestForm(target);
        await form.buildAsync();
    }
}

class TestForm extends Form {
    
    async buildChildrenAsync(): Promise<void> {
        
        const dateInput = await DateElement.fromAsync({
            label: "日期",
            allowEmpty: false
        });
        await this.appendAsync(dateInput);

        const rangeInput = await DateRangeElement.fromAsync({
            label: "日期區間"
        });
        await this.appendAsync(rangeInput);

        const readonlyDateInput = await ReadonlyDateElement.fromAsync({
            label: "日期"
        });
        await this.appendAsync(readonlyDateInput);

        const readonlyRangeInput = await ReadonlyDateRangeElement.fromAsync({
            label: "日期區間"
        });
        await this.appendAsync(readonlyRangeInput);

        dateInput.addChangeFunc(async () => {
            const value = await dateInput.getValueAsync();
            await readonlyDateInput.setValueAsync(value);
        });

        rangeInput.addChangeFunc(async () => {
            const value = await rangeInput.getValueAsync();
            await readonlyRangeInput.setValueAsync(value);
        });
    }
}

testAsync();