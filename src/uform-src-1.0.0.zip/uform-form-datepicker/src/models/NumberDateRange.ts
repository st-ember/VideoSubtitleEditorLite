
export default interface NumberDateRange {
    start?: number;
    end?: number;
}