
export default interface FormattedDateRange {
    start?: string;
    end?: string;
}