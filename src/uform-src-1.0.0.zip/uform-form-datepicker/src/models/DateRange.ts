
export default interface DateRange {
    start?: Date;
    end?: Date;
}