import ReadonlyDateElementOptions from "options/ReadonlyDateElementOption";
import datepickerController from "uform-datepicker";
import { FormElementGeneric } from "uform-form";

export default class ReadonlyDateElement extends FormElementGeneric<string> implements ReadonlyDateElementOptions {

    element: HTMLDivElement = document.createElement("div");

    value?: Date;

    format: string = "yyyy/MM/dd";
    yearFormater?: (year: number) => string;
    dateParser?: (text: string) => Date;
    
    constructor(options?: ReadonlyDateElementOptions) {
        super(options);
        this.bindOptions(options);
    }

    static fromAsync(options: ReadonlyDateElementOptions): Promise<ReadonlyDateElement> {
        return <Promise<ReadonlyDateElement>>(new ReadonlyDateElement(options).buildAsync());
    }

    protected async buildElementAsync(): Promise<void> {
        this.element.className = "readonly-input";
        this.element.id = this.id;
        this.container.appendChild(this.element);

        this.messageAnchor = this.element;
    }

    async rebuildAsync(): Promise<void> {
        await this.clearAsync();
        this.element.remove();
        await this.buildElementAsync();
    }

    async deleteAsync(): Promise<void> {
        this.container.remove();
    }

    async validateAsync(): Promise<boolean> {
        this.validated = true;
        return true;
    }

    async setDisableAsync(disable?: boolean): Promise<void> {
        this.disabled = disable !== false;
    }

    async clearAsync(): Promise<void> {
        this.value = undefined;
        this.element.innerText = "";
    }

    async getValueAsync(): Promise<string> {
        return this._getFormattedValue();
    }

    async setValueAsync(value: string | number | Date | undefined): Promise<void> {
        let date: Date | undefined;
        if (typeof value === "string" && this.dateParser) {
            date = this.dateParser(value);
        } else {
            date = !value ? undefined : typeof value === "string" || typeof value === "number" ? new Date(value) : value;
        }
        
        this.value = date;
        this.element.innerText = this._getFormattedValue();
        
        await this.changeAsync();
    }

    private _getFormattedValue(): string {
        return this.value !== undefined ? datepickerController.format(this.value, this.format, this.yearFormater) : "";
    }
}