import ReadonlyDateElementOptions from "./ReadonlyDateElementOption";

export default interface ReadonlyDateRangeElementOptions extends ReadonlyDateElementOptions {
    textBetween?: string;
}
