import DateElementOptions from "./DateElementOptions";

export default interface DateRangeElementOptions extends DateElementOptions {
    textBetween?: string;
    startYear?: number | string;
    endYear?: number | string;
}
