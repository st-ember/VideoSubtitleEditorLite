import { FormElementOptions } from "uform-form";

export default interface ReadonlyDateElementOptions extends FormElementOptions {
    format?: string;
    yearFormater?: (year: number) => string;
    dateParser?: (text: string) => Date;
}