import { FormElementOptions } from "uform-form";

export default interface DateElementOptions extends FormElementOptions {
    allowEmpty?: boolean;
    mode?: "date" | "week" | "weekend";
    format?: string;
    yearFormater?: (year: number) => string;
    dateParser?: (text: string) => Date;
}
