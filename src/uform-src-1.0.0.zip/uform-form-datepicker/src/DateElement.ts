import DateElementOptions from "options/DateElementOptions";
import datepickerController, { Datepicker } from "uform-datepicker";
import { FormElementGeneric } from "uform-form";

export default class DateElement extends FormElementGeneric<string | undefined> implements DateElementOptions {

    allowEmpty: boolean = true;
    mode: "date" | "week" | "weekend" = "date";
    format: string = "yyyy/MM/dd";
    startYear?: number | string;
    endYear?: number | string;
    yearFormater?: (year: number) => string;
    dateParser?: (text: string) => Date;

    element: HTMLInputElement = document.createElement("input");

    datepicker?: Datepicker;
    
    constructor(options?: DateElementOptions) {
        super(options);
        this.bindOptions(options);
    }

    static fromAsync(options: DateElementOptions): Promise<DateElement> {
        return <Promise<DateElement>>(new DateElement(options).buildAsync());
    }

    protected async buildElementAsync(): Promise<void> {
        if (this.name) {
            this.element.name = this.name;
        }

        if (this.label) {
            this.element.title = this.label;
        }
        
        this.element.id = this.id;
        this.element.type = "text";
        this.element.autocomplete = "off";
        this.container.appendChild(this.element);

        this.messageAnchor = this.element;

        const addon = document.createElement("label");
        addon.setAttribute("for", this.id);
        addon.className = "date-input-addon";
        this.container.appendChild(addon);

        await this.buildDateInput();
    }

    protected async buildDateInput(): Promise<void> {
        const datepickers = await datepickerController.buildAsync({
            input: this.element,
            mode: this.mode,
            format: this.format,
            allowEmpty: this.allowEmpty,
            showClearButton: this.allowEmpty,
            showTodayButton: true,
            startYear: this.startYear,
            endYear: this.endYear,
            yearFormater: this.yearFormater,
            dateParser: this.dateParser
        });

        this.datepicker = datepickers[0];
        this.datepicker.onChangeFuncs.push(async () => this.changeAsync());
    }

    async rebuildAsync(): Promise<void> {
        if (this.datepicker) {
            await datepickerController.removeAsync(this.datepicker.id);
            this.datepicker = undefined;
        }
        
        await this.buildDateInput();
        await this.clearAsync();
    }

    async deleteAsync(): Promise<void> {
        await this.removeMessageAsync();

        if (this.datepicker) {
            await datepickerController.removeAsync(this.datepicker.id);
            this.datepicker = undefined;
        }
        
        this.container.remove();
    }

    async validateAsync(): Promise<boolean> {
        this.validated = true;
        const valid = !this.needToCheckRequire() || !!(await this.getValueAsync());
        await this.showInvalidEffectAsync(!valid, "此項目為必填！");
        return valid;
    }

    async setDisableAsync(disable?: boolean): Promise<void> {
        this.disabled = disable !== false;
        await this.datepicker?.setDisableAsync(this.disabled);
    }

    async clearAsync(): Promise<void> {
        await this.datepicker?.clearAsync();
    }

    async getValueAsync(): Promise<string | undefined> {
        return this.datepicker?.get();
    }

    async getDateValueAsync(): Promise<Date | undefined> {
        return this.datepicker?.getDate();
    }

    async getNumberValueAsync(): Promise<number> {
        return Number(this.datepicker?.getDate());
    }

    async setValueAsync(value: number): Promise<void>;
    async setValueAsync(value: Date): Promise<void>;
    async setValueAsync(value: string): Promise<void>;
    async setValueAsync(value: string | number | Date | undefined): Promise<void> {
        await (typeof value === "number" ? this.datepicker?.setAsync(new Date(value)) : this.datepicker?.setAsync(value));
    }
}